<?php
$ckFinderAbsoluteFilePath = '/Applications/MAMP/htdocs/roaweb';