-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 24, 2022 at 10:17 AM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nbscha`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `uid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`uid`, `fullname`, `username`, `password`, `salt`, `email`, `phone`, `role`, `status`, `created`) VALUES
(1, 'Super Administrator', 'superadmin', '15c362dc8fd059b0386008927bc4105673455d20', 'celiums', 'admin@celiums.com', '984698551', 1, 1, '2021-10-06 18:40:02'),
(2, 'Loai Jaouni', 'loai', 'dffa88b5bf8ee2cb56c053025e112196ac16128f', '3Xl0Jj', 'loai.jaouni@gmail.com', '123456789', 1, 1, '2022-03-03 05:41:40');

-- --------------------------------------------------------

--
-- Table structure for table `admins_login_history`
--

CREATE TABLE `admins_login_history` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins_login_history`
--

INSERT INTO `admins_login_history` (`id`, `uid`, `ipaddress`, `timestamp`) VALUES
(1, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(2, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(3, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(4, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(5, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(6, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(7, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(8, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(9, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(10, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(11, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(12, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(13, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(14, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(15, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(16, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(17, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(18, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(19, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(20, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(21, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(22, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(23, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(24, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(25, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(26, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(27, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(28, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(29, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(30, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(31, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(32, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(33, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(34, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(35, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(36, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(37, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(38, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(39, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(40, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(41, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(42, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(43, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(44, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(45, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(46, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(47, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(48, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(49, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(50, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(51, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(52, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(53, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(54, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(55, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(56, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(57, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(58, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(59, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(60, 1, '127.0.0.1', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admin_function`
--

CREATE TABLE `admin_function` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `controller` varchar(255) NOT NULL,
  `function` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_function_permission`
--

CREATE TABLE `admin_function_permission` (
  `function_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu`
--

CREATE TABLE `admin_menu` (
  `id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  `display` int(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_menu`
--

INSERT INTO `admin_menu` (`id`, `class`, `name`, `link`, `parent_id`, `status`, `display`, `sort_order`) VALUES
(1, 'fa-dashboard', 'Dashboard', '', 0, 'Y', 1, 0),
(2, 'fa-user', 'Manage Users', '', 0, 'Y', 1, 20),
(3, '', 'Users', 'users/overview', 2, 'Y', 1, 1),
(4, '', 'Add User', 'users/add', 2, 'Y', 1, 2),
(9, '', 'Settings', 'home/settings', 1, 'Y', 1, 1),
(10, '', 'Clear Cache', 'home/clearcache', 1, 'Y', 1, 2),
(11, '', 'Update Database', 'home/updatedb', 1, 'Y', 1, 3),
(25, '', 'Dashboard', 'home/dashboard', 1, 'Y', 1, 0),
(30, 'fa-file', 'Manage Pages', '', 0, 'Y', 1, 18),
(31, '', 'Pages', 'pages/overview', 30, 'Y', 1, 1),
(32, '', 'Add Page', 'pages/add', 30, 'Y', 1, 2),
(50, 'fa-bars', 'Manage Menu', '', 0, 'Y', 1, 16),
(51, '', 'Menus', 'menus/overview', 50, 'Y', 1, 1),
(52, '', 'Add Menu', 'menus/add', 50, 'Y', 1, 2),
(60, 'fa-cubes', 'Manage Widgets', '', 0, 'Y', 1, 19),
(61, '', 'Widgets', 'widgets/overview', 60, 'Y', 1, 1),
(70, 'fa-file-code-o', 'Manage Content', '', 0, 'Y', 1, 17),
(78, 'fa-wpforms', 'Manage Forms', '', 0, 'Y', 1, 15),
(79, '', 'Enquiries', 'enquiries/overview', 78, 'Y', 1, 5),
(83, '', 'Home Sliders', 'sliders/overview', 70, 'Y', 1, 1),
(84, '', 'Blocks', 'blocks/overview', 70, 'Y', 1, 2),
(85, '', 'Block Categories', 'blocks/categories', 70, 'Y', 1, 3),
(86, '', 'Languages', 'languages/overview', 1, 'Y', 1, 1),
(89, 'fa-users', 'Manage Memberships', '', 0, 'Y', 1, 2),
(90, '', 'Members', 'members', 89, 'Y', 1, 0),
(91, 'fa-file-text-o', 'Manage Masters', '', 0, 'Y', 1, 3),
(92, '', 'Packages(Beds)', 'packages', 91, 'Y', 1, 0),
(93, '', 'Localization', 'home/localization', 70, 'Y', 1, 1),
(94, '', 'Regions', 'regions', 91, 'Y', 1, 2),
(95, '', 'Level Of Care', 'carelevels', 91, 'Y', 1, 4),
(96, '', 'Facilities', 'facilities', 91, 'Y', 1, 3),
(97, '', 'Features', 'features', 91, 'Y', 1, 6),
(99, '', 'Certificate Templates', 'certificatetemplates', 91, 'Y', 1, 7),
(100, '', 'Sponsors', 'sponsors', 70, 'Y', 1, 0),
(101, '', 'Board Members', 'teams', 70, 'Y', 1, 0),
(102, '', 'Links', 'links', 70, 'Y', 1, 0),
(103, '', 'Forms', 'forms', 70, 'Y', 1, 0),
(104, '', 'Testimonials', 'testimonials', 70, 'Y', 1, 0),
(105, '', 'Statistics', 'statistics', 70, 'Y', 1, 0),
(106, '', 'Faqs', 'faqs', 70, 'Y', 1, 0),
(107, '', 'News', 'news', 70, 'Y', 1, 0),
(108, '', 'News Categories', 'news/categories', 70, 'Y', 1, 0),
(109, '', 'Requests', 'requests', 89, 'Y', 1, 1),
(110, '', 'Residences', 'residences', 89, 'Y', 1, 1),
(111, '', 'Renewals', 'renewals', 89, 'Y', 1, 4),
(112, '', 'Roles', 'users/roles', 2, 'Y', 1, 4),
(113, 'fa-file-text-o', 'Manage Manual', '', 0, 'Y', 1, 5),
(115, '', 'Policies', 'policies', 113, 'Y', 1, 1),
(116, '', 'Download Manual', 'manuals/download', 113, 'Y', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu_permission`
--

CREATE TABLE `admin_menu_permission` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_menu_permission`
--

INSERT INTO `admin_menu_permission` (`role_id`, `menu_id`) VALUES
(2, 1),
(2, 25),
(2, 9),
(2, 86),
(2, 89),
(2, 90),
(2, 109),
(2, 110),
(2, 111),
(2, 91),
(2, 92),
(2, 94),
(2, 96),
(2, 95),
(2, 97),
(2, 99),
(2, 78),
(2, 79),
(2, 70),
(2, 100),
(2, 101),
(2, 102),
(2, 103),
(2, 104),
(2, 105),
(2, 106),
(2, 107),
(2, 108),
(2, 83),
(2, 84),
(2, 85);

-- --------------------------------------------------------

--
-- Table structure for table `admin_reset`
--

CREATE TABLE `admin_reset` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_key` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `rid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`rid`, `name`, `status`) VALUES
(1, 'Super Administrator', 1),
(2, 'Admin', 1),
(3, 'Editor', 1),
(4, 'Member Coordinator', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `category` int(11) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `category`, `icon`, `image`, `sort_order`, `status`) VALUES
(1, 1, '', '', 0, 1),
(2, 1, '', '', 0, 1),
(3, 1, '', '', 0, 1),
(4, 1, '', '', 0, 1),
(5, 2, '', '', 0, 1),
(6, 2, '', '', 0, 1),
(7, 2, '', '', 0, 1),
(8, 2, '', '', 0, 1),
(9, 3, '', '', 0, 1),
(10, 3, '', '', 0, 1),
(11, 3, '', '', 0, 1),
(12, 3, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `blocks_desc`
--

CREATE TABLE `blocks_desc` (
  `desc_id` int(11) NOT NULL,
  `block_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `caption_title` varchar(255) NOT NULL,
  `caption_subtitle` varchar(255) NOT NULL,
  `icon_class` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks_desc`
--

INSERT INTO `blocks_desc` (`desc_id`, `block_id`, `title`, `summary`, `caption_title`, `caption_subtitle`, `icon_class`, `link_url`, `link_title`, `language`) VALUES
(1, 1, 'Membership', '', 'Owners/Operators join our network of special care homes', '', 'fa fa-user text-white font-64 pb-10', '/register', 'Join Us Now', 'en'),
(2, 2, 'Questions?', '', 'Considering a special care home? Here is a good place to start', '', 'fa fa-comments-o text-white font-64 pb-10', '/faq', 'Get help', 'en'),
(3, 3, 'Residences', '', 'Explore key information on our homes and available vacancies', '', 'fa fa-book fa-fw text-white font-64 pb-10', '/residences', 'Find Us Now', 'en'),
(4, 4, 'Member Login', '', 'Are you a member? Login to get your latest updates.', '', 'fa fa-mobile text-white font-64 pb-10', '/member/login', 'Find Us Now', 'en'),
(5, 5, 'Our Residences', '', 'Browse our residences for special care homes in your area.', '', 'fa fa-home', '/residences', '', 'en'),
(6, 6, 'Membership', '', 'Join our membership of special care homes in New Brunswick.', '', 'fa fa-user', '/register', '', 'en'),
(7, 7, 'Sponsors', '', 'We are so grateful to our sponsors. With their support we thrive.', '', 'fa fa-heartbeat', '/sponsors', '', 'en'),
(8, 8, 'Board Members', '', 'Meet our board members who aim to improve the lives of special care home workers.', '', 'fa fa-users', '/board', '', 'en'),
(9, 9, 'ADVOCATE', '', 'We are dedicated to protecting the rights of our workers and advocate for equitable wages and benefits for our workers.', '', 'fa fa-wheelchair text-white font-60', '#', '', 'en'),
(10, 10, 'EDUCATE', '', 'We aim to provide standardized education and training that is in line with the needs and demands of our industry.', '', 'fa fa-user text-white font-60', '#', '', 'en'),
(11, 11, 'IMPROVE', '', 'We work with the government and other stakeholders on special projects in order to improve the sector as a whole.', '', 'fa fa-money text-white font-60', '#', '', 'en'),
(12, 12, 'INFORM', '', 'We work with various government departments to ensure appropriate standards and regulations are implemented while communicating directly with the sector.', '', 'fa fa-pencil fa-fw text-white font-60', '#', '', 'en'),
(13, 1, 'Membership', '', 'Owners/Operators join our network of special care homes', '', 'fa fa-user text-white font-64 pb-10', '/register', 'Join Us Now', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `block_categories`
--

CREATE TABLE `block_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_categories`
--

INSERT INTO `block_categories` (`id`, `name`, `status`) VALUES
(1, 'Home Callouts', 1),
(2, 'Useful Links', 1),
(3, 'Why Chose Us', 1);

-- --------------------------------------------------------

--
-- Table structure for table `board_members`
--

CREATE TABLE `board_members` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `board_members`
--

INSERT INTO `board_members` (`id`, `slug`, `email`, `phone`, `photo`, `facebook`, `twitter`, `linkedin`, `skype`, `sort_order`, `status`) VALUES
(1, 'jan-seely', 'jan.seely@rogers.com', '(506) 639-4478', 'bm_jan_d.jpg', '#', '#', '#', '#', 0, 1),
(3, 'john-grass', 'jgrass1213@rogers.com', '506-872-3340', 'John_Grass.jpg', '', '', '', '', 0, 1),
(4, 'leonard-gervais', 'treasurer@nbscha.com', '(506) 447-1076', 'Leonard_Gervais.jpg', '', '', '', '', 0, 1),
(5, 'danielle-gallant', 'secretary@nbscha.ca', '(506) 650-8706', 'Danielle_Gallant.jpg', '', '', '', '', 0, 1),
(6, 'derek-green', 'dgreen@shannex.com', '506-381-3914', 'Derek_Green.jpg', '', '', '', '', 0, 1),
(7, 'crystal-powell', 'kathleen11251@gmail.com', '', 'Crystal_Powell.jpg', '', '', '', '', 0, 1),
(8, 'collette-doucette', 'collette.obs@rogers.com', '(506)533-8088', 'Collette_Doucette.jpg', '', '', '', '', 0, 1),
(9, 'jason-lee', 'ceo@peiseniorshomes.com', '902 626 7720', 'Jason_Lee.jpg', '', '', '', '', 0, 1),
(10, 'christine-saunders', 'paradisevilla.cs@gmail.com', '', 'Christine_Saunders.jpg', '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `board_members_desc`
--

CREATE TABLE `board_members_desc` (
  `desc_id` int(11) NOT NULL,
  `board_member_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `bio` text,
  `location` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `board_members_desc`
--

INSERT INTO `board_members_desc` (`desc_id`, `board_member_id`, `name`, `position`, `bio`, `location`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Jan Seely', 'President', '<p>\r\n	Jan has been the President of the NB Special Care Home Association for many years. She is a strong advocate for community based services. Jan works hard to forge productive relationships with government, and other community partners, to strengthen the sector overall. Her and her husband own and operate a small Special Care Home in Saint John. The past 25 years in this occupation has given her a comprehensive knowledge base of the challenges faced by operators and their employees as they strive to deliver quality services to clients.</p>\r\n', NULL, 'Jan Seely', NULL, NULL, 'en'),
(3, 3, 'John Grass', 'Vice President', 'John has been a resident of Riverview for the past 46 years and graduated Riverview High School in 1980. He then obtained his Bachelor of Science in 1984 and his Bachelor of Business in 1986 both from Mount Allison University, He spent 12 years with the Irving group of companies before buying his first Special Care Home in 1988. Buying a piece of vacant land in 1999 and built the Finish Line Car Wash in 2005. Finish Line has 2 touchless automatic bays and 2 self-serve bays and is located in Riverview. While still operating those businesses, John and his wife Lynn build their second home in 2019. Combined, they offer level 2 and 3G levels of care for 60 seniors.', 'Riverview, NB', NULL, NULL, NULL, 'en'),
(4, 4, 'Leonard Gervais', 'Treasurer', 'Leonard has been in the care home business since 1997 and has been a member with the New Brunswick Special Care Home Association since 1998. Leonard was first introduced to the board in 2008 and was re-elected in 2012.', 'Fredericton, NB', NULL, NULL, NULL, 'en'),
(5, 5, 'Danielle Gallant', 'Secretary', '<p>\r\n	My name is Danielle Gallant. I&rsquo;ve been operating our family business for that last 20 years and was a pharmacy technician for seven years. I&#39;ve been the Secretary of the New Brunswick Special Care Home Association for the last 6 years. In the late summer of 2019, I was also part of the working group that was created to restructure the Special Care home Standards and Regulations.</p>\r\n<p>\r\n	My passion is to advocate for excellent quality services be provided in all homes in New Brunswick. I believe change is needed in out sector and I&rsquo;m ecstatic to be part of it!</p>\r\n', 'Saint John, NB', NULL, NULL, NULL, 'en'),
(6, 6, 'Derek Green', 'Board Member', 'Derek joined Shannex in 2018 as Vice President, New Brunswick Operations where he supports our Parkland Retirement Living Campuses and Shannex Nursing Homes throughout NB. Derek’s focus is to support the company’s current and expanding operations in NB to ensure Residents continue to receive top quality accommodations and services from engaged employees. Originally from a small town on the Southwest Miramichi - Boiestown, Derek now resides in Riverview, NB. He and his wife Jill have been married for 25 years and they have 3 children. Prior to joining Shannex, Derek had a distinguished 23-year career as a senior leader with Medavie Blue Cross, accountable for implementation and management of their federal government contracts with Veterans Affairs Canada, CAF, RCMP and Immigration, Refugees and Citizenship Canada. Prior to that he served as an Artillery Officer with the Canadian Armed Forces for 8 years, stationed in Quebec, Ontario, and Chatham, NB. Derek holds a Bachelor of Commerce from the Royal Military College of Canada.', 'Riverview, NB', NULL, NULL, NULL, 'en'),
(7, 7, 'Crystal Powell', 'Board Member', 'Crystal has been a PSW certified by Compu College for 17 years now. She has also attended NBCC for one year where she took office administration and received her certification. She has a nursing home background of 9 years and has done homecare both privately and through a homecare company dealing mainly with seniors and palliative care clients. She has experience working with high functioning mental health clients from employment in a level 2 special care home, prior to owning and operating Maritime Manor Special Care home since 2014. Crystal finds it gratifying dealing in senior care, geriatric clients have taught her so much and she still has so much to learn from them! She love the outdoors, hunting ,fishing, camping and spending as much time as possible with her two children and her husband. Making time for friends and family is important to her. Crystal’s work is her passion and she is so grateful she took the opportunity when it arose to become a Special Care Home Owner, aside from her children it is one of her greatest accomplishments.', 'Saint John, NB', NULL, NULL, NULL, 'en'),
(8, 8, 'Collette Doucette', 'Board Member', 'At a very early age Collette developed a commitment to serving the elderly. From 1986 to 1994 she worked as a Nurse-Aid at Villa Providence in Shediac, a 198 beds Nursing Home. In 1994 her dream came true and became the Owner and Operator of a 45 beds Special Care Home for 17 years. After selling her home, she took on the role in 2017 of managing the day to day operation of a 130 beds Special Care Home Residence O Bons Soins in Shediac NB. Married with Donald Doucette in 1986, her high school sweetheart they have 2 boys and 2 grandchildren.', 'Shediac, NB', NULL, NULL, NULL, 'en'),
(9, 9, 'Jason Lee', 'Board Member', 'I am the CEO of the 435 member team with PEI Seniors Homes and Enhanced Living Special Care Homes, a group of nursing homes, community care facilities and specialized care homes across Prince Edward Island and New Brunswick, Canada. We provide care and homes for 385 of our countries seniors. Pleased to be a board and executive member with the Canadian Association for Long Term Care, the leading group in Canada for the support and growth of seniors care facilities across the country. Volunteer board member of the New Brunswick Special Care Home Association and a proud member of the Wallace McCain Institute through the University of New Brunswick. A lifelong resident of Prince Edward Island in Charlottetown, three-time graduate from UPEI and live on Spring Park Road with my amazing wife and two smart talented kids.', 'Charlottetown, PEI', NULL, NULL, NULL, 'en'),
(10, 10, 'Christine Saunders', 'Board Member', 'Christine Saunders is co-owner and CEO of Paradise Villa Inc. a 78-bed licensed Special Care Home that includes 18 Memory Care Beds in Fredericton NB. She is a Licensed Practical Nurse and has worked in long term care for a number of years. Also, she works in her other family-owned businesses in the Moncton area. When she is not working, she enjoys spending time with her family, especially her two kids.', 'Moncton, NB', NULL, NULL, NULL, 'en'),
(11, 1, 'Jan Seely', 'President', '<p>\r\n	Jan has been the President of the NB Special Care Home Association for many years. She is a strong advocate for community based services. Jan works hard to forge productive relationships with government, and other community partners, to strengthen the sector overall. Her and her husband own and operate a small Special Care Home in Saint John. The past 25 years in this occupation has given her a comprehensive knowledge base of the challenges faced by operators and their employees as they strive to deliver quality services to clients.</p>\r\n', NULL, NULL, NULL, NULL, 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `carelevels`
--

CREATE TABLE `carelevels` (
  `cid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `carelevels`
--

INSERT INTO `carelevels` (`cid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 1, 0),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0),
(5, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `carelevels_desc`
--

CREATE TABLE `carelevels_desc` (
  `desc_id` int(11) NOT NULL,
  `carelevel_id` int(11) NOT NULL,
  `carelevel_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `carelevels_desc`
--

INSERT INTO `carelevels_desc` (`desc_id`, `carelevel_id`, `carelevel_title`, `language`) VALUES
(3, 1, 'Level-2', 'en'),
(4, 2, 'Level-3', 'en'),
(5, 3, 'Level-3B', 'en'),
(6, 4, 'Level-3G', 'en'),
(7, 5, 'Level-4', 'en'),
(8, 1, 'Level-2', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_templates`
--

CREATE TABLE `certificate_templates` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `c_key` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `background` varchar(255) DEFAULT NULL,
  `wallet_bg` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificate_templates`
--

INSERT INTO `certificate_templates` (`id`, `title`, `c_key`, `image`, `background`, `wallet_bg`, `signature`, `status`, `sort_order`, `delete_status`) VALUES
(1, 'Test', 'test', '', '', '', '', 0, 0, 1),
(2, 'Test', 'Test', '', '', '', '', 0, 0, 1),
(3, 'Test ', 'Test', '', '', '', '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `certificate_templates_desc`
--

CREATE TABLE `certificate_templates_desc` (
  `desc_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `template` text NOT NULL,
  `wallet_template` text,
  `signatory` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL DEFAULT 'en'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificate_templates_desc`
--

INSERT INTO `certificate_templates_desc` (`desc_id`, `template_id`, `template`, `wallet_template`, `signatory`, `language`) VALUES
(1, 1, '<p>\r\n	This is Main template</p>\r\n', '<p>\r\n	This is wallet template</p>\r\n', 'Test User', 'en'),
(2, 1, '<p>\r\n	This is Main template</p>\r\n', '<p>\r\n	This is wallet template</p>\r\n', 'Test User', 'en'),
(3, 2, '', '', '', 'en'),
(4, 2, '', '', '', 'en'),
(5, 3, '', '', '', 'en'),
(6, 3, '', '', '', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `database_updates`
--

CREATE TABLE `database_updates` (
  `update_id` int(11) NOT NULL,
  `update_name` varchar(255) NOT NULL,
  `update_status` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `board_member_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `home_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `type`, `board_member_id`, `member_id`, `home_id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES
(1, 'contact', NULL, NULL, NULL, 'Varun Victor', 'Test@g.com', '07025430423', 'T', 't', '2022-03-24 13:21:17'),
(2, 'board_member', NULL, NULL, NULL, 'safas', 'dfadf@gsd.com', '', 'test', 'Test', '2022-03-24 13:37:26'),
(3, 'residence', NULL, NULL, NULL, 'TEst', 't@g.com', '241351', 'Test', 'dgsdgsd', '2022-03-24 20:44:58'),
(4, 'board_member', 1, 0, 0, 'Test', 'e@g.com', '', 'Test', 'Test', '2022-03-31 13:15:30'),
(5, 'residence', 0, 24, 24, 'Test', 't@g.com', '', 'Test', 'Test', '2022-03-31 13:15:59');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `fid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`fid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 1, 0),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `facilities_desc`
--

CREATE TABLE `facilities_desc` (
  `desc_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  `facility_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities_desc`
--

INSERT INTO `facilities_desc` (`desc_id`, `facility_id`, `facility_title`, `language`) VALUES
(1, 1, 'Seniors', 'en'),
(2, 2, 'Mental Health', 'en'),
(3, 3, 'Intellectual and Developmental', 'en'),
(4, 4, 'Blended Facility', 'en'),
(5, 1, 'Seniors', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `sort_order`, `status`) VALUES
(1, 0, 1),
(2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faqs_desc`
--

CREATE TABLE `faqs_desc` (
  `desc_id` int(11) NOT NULL,
  `faq_id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faqs_desc`
--

INSERT INTO `faqs_desc` (`desc_id`, `faq_id`, `question`, `answer`, `language`) VALUES
(1, 1, 'What questions should I ask operators when enquiring about a placement?', '<p class=\"mb-5\">\r\n	When enquiring about a placement, always make sure to ask essential questions before deciding. Here are some questions you should consider:</p>\r\n<p>\r\n	How will you help build life skills?</p>\r\n<p>\r\n	Do I have access to a telephone where I can speak in private?</p>\r\n<p>\r\n	Do I have access to the internet?</p>\r\n<p>\r\n	Are you able to provide me with a menu?</p>\r\n<p>\r\n	Will you be able to accommodate my special diet?</p>\r\n<p>\r\n	What time do you provide meals?</p>\r\n<p>\r\n	Do you have a bedtime or a quiet time?</p>\r\n<p>\r\n	What training does your staff have?</p>\r\n<p>\r\n	What activities do you offer?</p>\r\n<p>\r\n	When experiencing challenging behaviours from residents, how would operator/staff handle the situation?</p>\r\n<p>\r\n	How do you transport clients?</p>\r\n<p>\r\n	Is there local transportation handy to your home? Example: handi bus, transit buses or taxi</p>\r\n<p>\r\n	Will you transport to religious venues?</p>\r\n<p>\r\n	Do you have visiting hours or open door policy?</p>\r\n<p>\r\n	Can I visit my loved one privately in their room or only inn open common areas?</p>\r\n<p>\r\n	Will it be a single room or shared room?</p>\r\n<p>\r\n	Do you charge more than the government rate?</p>\r\n<p>\r\n	Do you provide cable in the bedrooms?</p>\r\n<p>\r\n	Do you have stairs in your building that I will have to use?</p>\r\n<p>\r\n	Can I bring my own personal belongings?</p>\r\n<p>\r\n	Can I put up my own pictures on the walls?</p>\r\n<p>\r\n	What furniture is provided in the bedroom?</p>\r\n<p>\r\n	Am i expected to purchase over the counter medications? Example: Tylenol for a headache?</p>\r\n', 'en'),
(2, 2, 'What are your next steps?', '<p class=\"mb-5\">\r\n	To access a full Long Term Care Assessment through Social Development, please gather your personal information together (address, medicare number, date of birth, etc.). Also, Call Social Development- 1-833-733-7835. Choose the option that says &quot;apply for long term care&quot;. Your information will be collected and the call will take approximately 10-15 minutes.</p>\r\n<p>\r\n	Within 5-10 days you should be contacted for an appointment and they will require additional financial information in order to complete your assessment and appoint you a Social Worker.</p>\r\n<p>\r\n	You will also be given a list of special care homes to call but our new website NBSCHA has a quick search method for the public. ( * PLEASE NOTE THESE HOMES ARE ALL MEMBERS OF OUR ASSOCIATION)</p>\r\n<p>\r\n	<b>Other Options:</b> You may already have an idea of which Special Care Home you would like to choose. If so, feel free to reach out to the operator for assistance with the assessment process. Our province also offers a <b>&quot;Private Pay&quot;</b> option for those persons who prefer not to access assistance through the Department of Social Development, but rather choose to pay for the care themselves. Additionally, your care needs may be temporary in nature, therefore you can reach out to your preferred facility and check the availability for a Relief/Respite and Convalescent Care bed. If you have a Social Worker already, this option can be as inexpensive as $10/day and you can stay for up to 30 days at a time or 90 days in a calendar year.</p>\r\n', 'en'),
(3, 1, 'What questions should I ask operators when enquiring about a placement?', '<p class=\"mb-5\">\r\n	When enquiring about a placement, always make sure to ask essential questions before deciding. Here are some questions you should consider:</p>\r\n<p>\r\n	How will you help build life skills?</p>\r\n<p>\r\n	Do I have access to a telephone where I can speak in private?</p>\r\n<p>\r\n	Do I have access to the internet?</p>\r\n<p>\r\n	Are you able to provide me with a menu?</p>\r\n<p>\r\n	Will you be able to accommodate my special diet?</p>\r\n<p>\r\n	What time do you provide meals?</p>\r\n<p>\r\n	Do you have a bedtime or a quiet time?</p>\r\n<p>\r\n	What training does your staff have?</p>\r\n<p>\r\n	What activities do you offer?</p>\r\n<p>\r\n	When experiencing challenging behaviours from residents, how would operator/staff handle the situation?</p>\r\n<p>\r\n	How do you transport clients?</p>\r\n<p>\r\n	Is there local transportation handy to your home? Example: handi bus, transit buses or taxi</p>\r\n<p>\r\n	Will you transport to religious venues?</p>\r\n<p>\r\n	Do you have visiting hours or open door policy?</p>\r\n<p>\r\n	Can I visit my loved one privately in their room or only inn open common areas?</p>\r\n<p>\r\n	Will it be a single room or shared room?</p>\r\n<p>\r\n	Do you charge more than the government rate?</p>\r\n<p>\r\n	Do you provide cable in the bedrooms?</p>\r\n<p>\r\n	Do you have stairs in your building that I will have to use?</p>\r\n<p>\r\n	Can I bring my own personal belongings?</p>\r\n<p>\r\n	Can I put up my own pictures on the walls?</p>\r\n<p>\r\n	What furniture is provided in the bedroom?</p>\r\n<p>\r\n	Am i expected to purchase over the counter medications? Example: Tylenol for a headache?</p>\r\n', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `fid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`fid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 10, 1, 0),
(2, 16, 1, 0),
(3, 12, 1, 0),
(4, 17, 1, 0),
(5, 40, 1, 0),
(6, 18, 1, 0),
(7, 4, 1, 0),
(8, 19, 1, 0),
(9, 5, 1, 0),
(10, 6, 1, 0),
(11, 7, 1, 0),
(12, 8, 1, 0),
(13, 9, 1, 0),
(14, 10, 1, 0),
(15, 11, 1, 0),
(16, 12, 1, 0),
(17, 13, 1, 0),
(18, 14, 1, 0),
(19, 15, 1, 0),
(20, 20, 1, 0),
(21, 21, 1, 0),
(22, 22, 1, 0),
(23, 23, 1, 0),
(24, 24, 1, 0),
(25, 25, 1, 0),
(26, 26, 1, 0),
(27, 27, 1, 0),
(28, 28, 1, 0),
(29, 29, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `features_desc`
--

CREATE TABLE `features_desc` (
  `desc_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `feature_title` varchar(400) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `features_desc`
--

INSERT INTO `features_desc` (`desc_id`, `feature_id`, `feature_title`, `language`) VALUES
(1, 1, 'Can a resident bring their pet to live with them?', 'en'),
(2, 2, 'Do you allow residents to bring their own furniture?', 'en'),
(3, 3, 'Do you look after managing their comfort and clothing money?', 'en'),
(4, 4, 'Do you have in home hairdressing?', 'en'),
(5, 5, 'Do you have in home foot care?', 'en'),
(6, 6, 'Do staff have training in Diabetes and insulin management?', 'en'),
(7, 7, 'Do staff have training in Oxygen Therapy?', 'en'),
(8, 8, 'Do staff have training in Colostomy Care?', 'en'),
(9, 9, 'Do staff have training in Wound Care?', 'en'),
(10, 10, 'Do you accept residents that are incontinent of urine and/or bowels?', 'en'),
(11, 11, 'Do you accept clients that are MRSA positive?', 'en'),
(12, 12, 'Can clients keep their own family physicians?', 'en'),
(13, 13, 'Do you have a working relationship with extra mural nursing?', 'en'),
(14, 14, 'Do you provide excursions for your residents?', 'en'),
(15, 15, 'Do any of your residents work in the community?', 'en'),
(16, 16, 'Do you have an accessible shower or tub for persons in a wheelchair?', 'en'),
(17, 17, 'Do you provide references from your existing clients and/or their families?', 'en'),
(18, 18, 'Do you provide transportation to and from medical visits?', 'en'),
(19, 19, 'Does staff administering medications have the required training?', 'en'),
(20, 20, 'Do staff have training in Dementia Care?', 'en'),
(21, 21, 'Do you have a monitoring system on the doors?', 'en'),
(22, 22, 'Do you have experience with clients suffering from addictions?', 'en'),
(23, 23, 'Do you have a doctor/nurse practitioner assigned to all residents?', 'en'),
(24, 24, 'Do you provide adaptive equipment for your residents?', 'en'),
(25, 25, 'Do any of your residents attend outreach programs?', 'en'),
(26, 26, 'Do you accommodate special diets i.e. gluten free, diabetic, etc.?', 'en'),
(27, 27, 'Do you have an outdoor area for sitting, walking, gardening, etc.?', 'en'),
(28, 28, 'Do You Accept Smokers And Provide A Designated Smoking Area?', 'en'),
(29, 29, 'Do you accept residents who are incontinent?', 'en'),
(30, 1, 'Can a resident bring their pet to live with them?', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `type`, `attachment`, `publish_date`, `status`) VALUES
(1, 'member', 'Ticket.pdf', '2022-06-08 18:30:00', 1),
(2, 'member', 'Ticket1.pdf', '2022-03-22 18:30:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `forms_desc`
--

CREATE TABLE `forms_desc` (
  `desc_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forms_desc`
--

INSERT INTO `forms_desc` (`desc_id`, `form_id`, `name`, `language`) VALUES
(1, 1, 'Social Development Check Form for Staff', 'en'),
(2, 2, 'Oath of Confidentiality', 'en'),
(3, 1, 'Social Development Check Form for Staff', 'fr'),
(4, 2, 'Oath of Confidentiality', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `home_languages`
--

CREATE TABLE `home_languages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `home_languages`
--

INSERT INTO `home_languages` (`id`, `name`, `status`) VALUES
(1, 'English', 1),
(2, 'French', 1),
(3, 'Bilingual', 1);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `label` varchar(100) NOT NULL,
  `class` varchar(300) NOT NULL,
  `code` varchar(10) NOT NULL,
  `default_language` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `label`, `class`, `code`, `default_language`, `status`) VALUES
(1, 'English', 'ENG', '', 'en', 1, 1),
(2, 'French', 'FRA', '', 'fr', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `type`, `image`, `sort_order`, `status`) VALUES
(1, 'public', '', 0, 1),
(2, 'public', '', 0, 1),
(3, 'public', '', 0, 1),
(4, 'public', 'index4.png', 0, 1),
(5, 'member', '', 0, 1),
(6, 'member', '', 0, 1),
(7, 'member', '', 0, 1),
(8, 'member', '', 0, 1),
(9, 'member', '', 0, 1),
(10, 'member', '', 0, 1),
(11, 'member', '', 0, 1),
(12, 'member', '', 0, 1),
(13, 'member', '', 0, 1),
(14, 'member', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `links_desc`
--

CREATE TABLE `links_desc` (
  `desc_id` int(11) NOT NULL,
  `link_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `summary` text,
  `link_url` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links_desc`
--

INSERT INTO `links_desc` (`desc_id`, `link_id`, `name`, `summary`, `link_url`, `language`) VALUES
(1, 1, 'Department of Social Development', 'Great resource for youth, families, seniors and persons w/disabilities. ', 'https://www.gnb.ca/socialdevelopment', 'en'),
(2, 2, 'Government of New Brunswick', 'Find out the latest news, information and links pertaining to the New Brunswick Government.', 'https://www.gnb.ca/', 'en'),
(3, 3, 'Workplace Health and Safety', 'A great resource for workers and employers from Workplace health &amp; Safety. As well as all the latest news and updates.', 'https://www.worksafenb.ca/', 'en'),
(4, 4, 'Pay Equity Act', 'Full Pay Equity Act publication posted by the Justice and Office of the Attorney General.', 'http://laws.gnb.ca/en/showfulldoc/cs/P-5.05//20210114', 'en'),
(5, 5, 'Infirm Persons Act', '<p>\r\n	Infirm Persons Act</p>\r\n', 'https://www.canlii.org/en/nb/laws/stat/rsnb-1973-c-i-8/latest/rsnb-1973-c-i-8.html', 'en'),
(6, 6, 'Family Income Security Act and Reg', '<p>\r\n	Family Income Security Act and Reg</p>\r\n', 'https://www.canlii.org/en/nb/laws/stat/snb-1994-c-f-2.01/latest/snb-1994-c-f-2.01.html', 'en'),
(7, 7, 'Smoke Free Places Act', '<p>\r\n	Smoke Free Places Act</p>\r\n', 'https://www.gnb.ca/legis/bill/editform-e.asp?ID=296&legi=55&num=1', 'en'),
(8, 8, 'Human Rights Act	', 'Human Rights Act', 'https://www2.gnb.ca/content/gnb/en/departments/nbhrc.html', 'en'),
(9, 9, 'Occupational Health and Safety Act and Regulation	', '<p>\r\n	Occupational Health and Safety Act and Regulation</p>\r\n', 'http://laws.gnb.ca/en/ShowPdf/cs/O-0.2.pdf', 'en'),
(10, 10, 'Employment standards Act', '<p>\r\n	Employment standards Act</p>\r\n', 'http://laws.gnb.ca/en/ShowTdm/cs/E-7.2//', 'en'),
(11, 11, 'Adult Residential Facility Standards', '<p>\r\n	Adult Residential Facility Standards</p>\r\n', 'https://www2.gnb.ca/content/dam/gnb/Departments/sd-ds/pdf/Standards/AdultResidential-e.pdf', 'en'),
(12, 12, 'Mental Health Act', '<p>\r\n	Mental Health Act</p>\r\n', 'https://https//www.canlii.org/en/nb/laws/stat/rsnb-1973-c-m-10/latest/rsnb-1973-c-m-10.html/en/nb/laws/stat/rsnb-1973-c-m-10/latest/rsnb-1973-c-m-10.html', 'en'),
(13, 13, 'Fire Prevention Act', '<p>\r\n	Fire Prevention Act</p>\r\n', 'https://www.canlii.org/en/nb/laws/regu/nb-reg-82-20/latest/nb-reg-82-20.html', 'en'),
(14, 14, 'Health Act', '<p>\r\n	Health Act</p>\r\n', 'https://www.canada.ca/en/health-canada/services/health-care-system/canada-health-care-system-medicare/canada-health-act.html', 'en'),
(15, 1, 'Department of Social Development', 'Great resource for youth, families, seniors and persons w/disabilities. ', 'https://www.gnb.ca/socialdevelopment', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `live_members`
--

CREATE TABLE `live_members` (
  `id` bigint(20) NOT NULL,
  `mem_first_name` varchar(50) DEFAULT NULL,
  `mem_last_name` varchar(50) DEFAULT NULL,
  `mem_phone` varchar(20) DEFAULT NULL,
  `mem_email` varchar(100) NOT NULL,
  `mem_password` varchar(200) NOT NULL,
  `is_approve` tinyint(1) NOT NULL DEFAULT '0',
  `pass_key` varchar(100) DEFAULT NULL,
  `is_new_member` int(11) NOT NULL DEFAULT '1',
  `expiry_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `live_members`
--

INSERT INTO `live_members` (`id`, `mem_first_name`, `mem_last_name`, `mem_phone`, `mem_email`, `mem_password`, `is_approve`, `pass_key`, `is_new_member`, `expiry_date`, `created_at`, `updated_at`) VALUES
(29, 'jan', 'seely', '5066394478', 'janseely@rogers.com', '#3Taylor', 1, NULL, 0, '2023-03-31', '2020-10-22 20:00:21', '2021-03-31 02:16:48'),
(32, 'Georgina', 'Hubbard', '506-961-4397', 'gmhubb1@gmail.com', 'Children22!', 1, 'WmUsED7CdrAz6NL02iPRZHgFpqtkOj', 0, '2023-03-31', '2020-11-13 21:59:45', '2021-04-22 04:26:08'),
(33, 'Jennifer', 'Eagan', '5062739394', 'jen@eagan.ca', 'Dusty123!', 1, NULL, 0, '2023-03-31', '2020-11-13 22:03:12', '2021-04-07 09:57:56'),
(34, 'Miluska', 'Hessen Walton', '(506)444-1166', 'miluskahwalton@gmail.com', 'Mike1996', 1, 'F9mAfv1dgqIGoe5wuPSlZs8iRaCEHL', 0, '2023-03-31', '2020-11-13 22:22:26', '2021-04-07 23:24:50'),
(35, 'Elizabeth', 'McLay', '5068579200', 'administration@alouetteresidence.ca', 'Friends1', 1, NULL, 0, '2023-03-31', '2020-11-13 22:29:50', '2020-12-04 23:48:47'),
(36, 'Kim', 'Davis', '15066477953', 'kdavis@shannex.com', 'Winter$2020', 1, NULL, 0, '2023-03-31', '2020-11-13 22:50:06', '2021-03-18 20:35:03'),
(37, 'Mary', 'Phillips', '15068719326', 'maryjane-ox@hotmail.com', 'brycennorman1', 1, 'Y8NJU94T1ReaztWXymZdgrbQAGlnc7', 0, '2023-03-31', '2020-11-13 23:03:05', '2022-03-19 06:29:48'),
(38, 'Christa', 'Matheson', '5066437174', 'cmatheson@lochlomondvilla.com', 'LLVSCH2020', 1, NULL, 0, '2023-03-31', '2020-11-13 23:22:37', '2020-12-04 23:43:33'),
(39, 'Christine', 'Saunders', '506-443-8000', 'paradisevilla.cs1@gmail.com', 'Carter3106', 1, NULL, 0, '2023-03-31', '2020-11-14 00:01:15', '2020-12-04 23:44:27'),
(40, 'Darlene', 'Mazerolle', '5068690624', 'd_mazerolle96@hotmail.com', 'casey448', 1, NULL, 0, '2023-03-31', '2020-11-14 00:33:53', '2020-12-04 23:44:14'),
(42, 'Krissy', 'Travis', '5063337507', 'Krissy5646@gmail.com', 'tristen5646', 1, NULL, 0, '2023-03-31', '2020-11-14 03:22:13', '2020-12-04 23:44:08'),
(43, 'Jennifer', 'Paul Armstrong', '5066392424', 'jennlynnpaul@hotmail.com', 'Jbuddy2008', 1, NULL, 0, '2023-03-31', '2020-11-15 03:39:27', '2020-12-04 23:31:34'),
(44, 'Sara', 'Williston', '506-352-0137', 'riverbendresidence@hotmail.com', 'NormasPlace1!', 1, NULL, 0, '2023-03-31', '2020-11-16 06:02:20', '2020-12-04 23:31:56'),
(45, 'Fran', 'Cooke', '5068325935', 'agapehome@bellaliant.com', 'Denali1', 1, NULL, 0, '2023-03-31', '2020-11-16 23:48:55', '2020-12-04 23:32:02'),
(47, 'Pamela', 'Bowen', '5064557275', 'pbowen@shannex.com', 'Shannex$22', 1, 'NpJkswHKmUxhqDVnMFfSIgcvOjYEbo', 0, '2023-03-31', '2020-11-17 02:00:04', '2021-06-01 17:36:54'),
(48, 'Lucie', 'Boudreau', '506-850-8851', 'balancedwellnesscenter@gmail.com', 'Celine0809', 1, NULL, 0, '2023-03-31', '2020-11-17 19:36:03', '2020-12-04 23:31:50'),
(50, 'Katrina', 'Drost', '506 977 4286', 'katrina.4.boys@hotmail.com', 'Raynard@1969', 1, NULL, 0, '2023-03-31', '2020-11-18 10:23:28', '2022-01-27 08:03:20'),
(51, 'Cristie', 'Dykeman', '5064400654', 'slowcurrentspecialcarehome@gmail.com', 'Winter!6', 1, NULL, 0, '2023-03-31', '2020-11-19 06:49:57', '2020-12-04 23:33:02'),
(52, 'Mary', 'Cormier', '5065482534', 'cottage.53@hotmail.ca', 'caramel1', 1, NULL, 0, '2023-03-31', '2020-11-19 20:51:03', '2020-12-04 23:42:28'),
(55, 'Sarah', 'Jenkins', '5064719400', 'sarah.jenkins1@nbed.nb.ca', 'Ryansgirl123!', 1, NULL, 0, '2023-03-31', '2020-11-22 04:05:59', '2020-12-04 23:34:10'),
(56, 'Crystal', 'Powell', '15066474087', 'kathleen11251@gmail.com', 'Shania2011', 1, NULL, 0, '2023-03-31', '2020-11-26 00:20:39', '2020-12-04 23:32:25'),
(57, 'Susan', 'VanWart', '506 476-7879', 'susanmvanwart@gmail.com', 'susan3456', 1, NULL, 0, '2023-03-31', '2020-11-27 23:58:39', '2020-12-04 23:47:18'),
(58, 'Danielle', 'DeAgazio', '5068749652', 'info@protem.ca', 'ProTem', 1, 'g5Hajt6ehEAFNz83RYTr0742JqwlIy', 0, '2023-03-31', '2020-11-28 00:40:38', '2021-04-21 20:12:48'),
(59, 'John', 'Grass', '15068723340', 'jgrass1213@rogers.com', 'Grasshome#54', 1, NULL, 0, '2023-03-31', '2020-11-28 01:26:27', '2020-12-04 23:33:39'),
(60, 'Janice', 'Corey', '506-387-0506', 'jcorey@shannex.com', 'RivPark2', 1, NULL, 0, '2023-03-31', '2020-11-28 02:02:39', '2021-03-18 20:36:42'),
(61, 'Charlene', 'Noye', '5067592773', 'charlenenoye@outlook.com', 'Rickey.1984', 1, NULL, 0, '2023-03-31', '2020-11-28 04:10:32', '2020-12-04 23:44:55'),
(62, 'Lisa', 'Melanson', '506-650-3807', 'jklm2k2@hotmail.com', 'Melanson1', 1, NULL, 0, '2023-03-31', '2020-11-28 04:35:26', '2020-12-04 23:35:26'),
(63, 'Kelly', 'Briggs', '5063275041', 'Kellybriggs12@live.ca', 'Brandonb1', 1, NULL, 0, '2023-03-31', '2020-11-28 05:26:01', '2021-04-03 00:35:17'),
(64, 'Amy', 'Cook', '5066426058', 'rideout_amy@hotmail.com', 'Rielly02$', 1, NULL, 0, '2023-03-31', '2020-11-28 20:16:23', '2020-12-04 23:40:25'),
(65, 'Lori', 'McGrath', '5066523083', 'lorrainelynnmc@gmail.com', 'prIncess_69', 1, NULL, 0, '2023-03-31', '2020-11-28 20:17:05', '2020-12-04 23:37:43'),
(66, 'Steve', 'Mclay', '5064666611', 'mclaysbayhaven@gmail.com', '2766', 1, NULL, 0, '2023-03-31', '2020-11-28 21:16:53', '2021-03-18 20:35:23'),
(68, 'Collette', 'Doucette', '5063123301', 'collette.obs@rogers.com', '330pascal', 1, NULL, 0, '2023-03-31', '2020-11-29 13:06:53', '2021-04-22 03:01:35'),
(69, 'Lillian', 'Drapeau', '+15065464587', 'lillian.drapeau@gmail.com', 'Pompier14!', 1, 'bZDJ4Bw32XolxQfRkudaT5eWziNj9A', 0, '2023-03-31', '2020-11-30 05:26:06', '2021-04-01 21:10:31'),
(70, 'Jeffrey', 'Hunter', '5063874518', 'jefhunter@rogers.com', 'mittens1', 1, NULL, 0, '2023-03-31', '2020-11-30 17:53:20', '2021-04-03 00:35:22'),
(71, 'Mercy', 'Burge', '15065122189', 'ilovemyjobcanada@gmail.com', 'Blaze2018', 1, 'Lh5H2CkBcv68nIebuN3q1YtXVEDW0g', 0, '2023-03-31', '2020-12-01 05:07:18', '2021-04-10 07:44:44'),
(72, 'Rhonda', 'Reid', '5063576835', 'rhonda@yourathomeretreat.ca', 'Swanie11!!', 1, NULL, 0, '2023-03-31', '2020-12-02 21:21:00', '2020-12-04 23:45:43'),
(73, 'Lisa', 'Levesque', '530-0082', 'lislev10@gmail.com', 'Mercedes2019', 1, NULL, 0, '2023-03-31', '2020-12-04 22:58:29', '2021-04-03 00:35:27'),
(74, 'Ruth', 'Sawler', '5063759193', 'ruan@nbnet.nb.ca', 'Skaarup', 1, NULL, 0, '2023-03-31', '2020-12-05 19:55:37', '2020-12-11 19:06:44'),
(75, 'Tammy', 'Long', '5068392715', 'tammylong@hotmail.com', 'Brooklynn1', 1, NULL, 0, '2023-03-31', '2020-12-09 05:57:34', '2021-03-18 20:35:28'),
(76, 'Cary', 'MacDonald', '5068668725', 'carymac63@gmail.com', 'cebxih-kipgex-5Jifge', 1, NULL, 0, '2023-03-31', '2020-12-09 21:44:38', '2021-03-18 20:37:55'),
(78, 'Susan', 'Dixson', '5063811550', 'serenacare@bellaliant.com', 'Susan2070$', 1, NULL, 0, '2023-03-31', '2020-12-13 22:44:37', '2021-03-18 20:35:33'),
(81, 'Jennifer', 'Burns', '5068635245', 'jenburnsmanor@gmail.com', '!RedStar478', 1, NULL, 0, '2023-03-31', '2020-12-17 21:17:37', '2021-04-03 00:35:32'),
(85, 'Chris', 'Smith', '506-434-1099', 'chris.smith1@ambienthealth.ca', '4525', 1, NULL, 0, '2023-03-31', '2021-01-08 22:38:19', '2021-03-18 20:35:38'),
(86, 'Charline', 'Johnson', '506-874-5667', 'thebriarlea1@gmail.com', '123parent', 1, NULL, 0, '2023-03-31', '2021-01-18 18:57:25', '2021-04-02 02:06:24'),
(87, 'Jody', 'Munn', '5062603354', 'jodymunnster@gmail.com', '13Vocabulary$', 1, NULL, 0, '2023-03-31', '2021-01-23 21:59:33', '2021-03-18 20:35:49'),
(88, 'Colleen', 'Paynter', '15062271478', 'colleenpaynter1@hotmail.com', 'Bloyce12', 1, 'ykC36g2Y5uXawARBeFfpKrzdVSI4GH', 0, '2023-03-31', '2021-02-10 23:23:21', '2021-07-20 15:48:14'),
(101, 'Danielle', 'Gallant', '5066508706', 'lauramanor86@gmail.com', 'booboo2021!', 1, NULL, 0, '2023-03-31', '2021-04-01 22:39:56', '2021-04-06 14:21:18'),
(111, 'Ann', 'Waddell', '506-333-1286', 'waddell@levesqueonline.com', 'Ann2021!!', 1, NULL, 0, '2023-03-31', '2021-04-07 15:28:37', '2021-05-19 19:31:16'),
(115, 'Wilma', 'Ledin', '5062292170', 'buchananwilma@gmail.com', 'Pass##123', 1, NULL, 0, '2023-03-31', '2021-04-12 22:37:42', '2021-04-14 16:00:57'),
(116, 'Heather', 'Perrin', '5066448100', 'hseely86@hotmail.com', '#3Taylor', 1, NULL, 0, '2023-03-31', '2021-04-14 09:18:53', '2021-04-14 16:00:51'),
(117, 'vanessa', 'harris', '15062141690', 'metcalfmanor1@gmail.com', '7889', 1, NULL, 0, '2023-03-31', '2021-04-19 18:30:58', '2021-04-20 00:09:24'),
(118, 'Julie', 'Steeves', '506-939-2233', 'thecedarsarf@gmail.com', 'wurangian', 1, NULL, 0, '2023-03-31', '2021-04-21 19:09:11', '2021-04-21 20:09:41'),
(119, 'Wendy', 'Symonds', '902 664. 4089', 'bartlettgardenscarehome@gmail.com', 'kricketeer7*', 1, NULL, 0, '2023-03-31', '2021-04-22 00:36:21', '2021-06-25 17:24:31'),
(120, 'Sandra', 'Ferris', '(506)6531615', 'marion.macdougall@outlook.com', 'Fancyis#1', 1, NULL, 0, '2023-03-31', '2021-04-22 01:42:11', '2021-09-11 00:17:59'),
(121, 'Tom', 'Knox', '5064675117', 'knoxtom@rocketmail.com', 'Tcalc5tcalc5', 1, NULL, 0, '2023-03-31', '2021-04-23 00:33:57', '2021-04-23 00:41:56'),
(122, 'PAULA', 'FASQUEL', '506-327-9000', 'mail@northmintoresidence.ca', 'alliegirl', 1, NULL, 0, '2023-03-31', '2021-04-23 00:34:40', '2021-04-23 00:41:43'),
(123, 'Lynn', 'Wallace', '5064341869', 'lpearle@hotmail.com', 'Molly2007', 1, NULL, 0, '2023-03-31', '2021-04-25 23:23:43', '2021-05-14 08:25:09'),
(134, 'Crystal', 'Snowdon', '506538-2968', 'crystallynnsnowdon1973@gmail.com', 'Samantha20', 1, NULL, 0, '2023-03-31', '2021-05-01 23:27:48', '2021-05-03 19:40:15'),
(138, 'Steven', 'Wen', '5066321888', 'stevenwen@yahoo.com', 'steven1487', 1, NULL, 0, '2023-03-31', '2021-05-03 19:17:00', '2021-05-03 19:38:47'),
(140, 'Leonard', 'Gervais', '506-458-8968', 'parkviewgardens203@outlook.com', 'Lydia#2018', 1, NULL, 0, '2023-03-31', '2021-05-05 20:46:56', '2021-05-06 18:18:40'),
(144, 'Alison', 'Baxter', '5063870533', 'abaxter@shannex.com', 'Parkland2021', 1, NULL, 0, '2023-03-31', '2021-05-11 18:50:09', '2021-05-11 23:57:06'),
(146, 'Erynn', 'Bailey', '506-422-8600 ext 5', 'erynn@enhancedliving.ca', 'ELB1985!', 1, NULL, 0, '2023-03-31', '2021-05-18 20:44:19', '2021-05-19 03:16:18'),
(155, 'Wendy', 'Maillet', '506-343-4068', 'wmaillet@shannex.com', 'HOWEHALL1234!', 1, 'rpyHmoLKSUtCg0NwcVRdinYG8WhleO', 0, '2023-03-31', '2021-06-07 19:33:00', '2021-06-15 20:40:00'),
(157, 'Jessica', 'Power', '5066082558', 'jessiepower_97@hotmail.com', '#7Coalition', 1, NULL, 0, '2023-03-31', '2021-06-14 18:37:20', '2021-06-15 17:59:25'),
(159, 'Emily', 'Swim', '506-328-5471', 'gdswim@xplornet.com', 'Lyndsay1977', 1, NULL, 0, '2023-03-31', '2021-06-16 21:08:37', '2021-06-16 21:49:53'),
(161, 'Alvina', 'Allain', '5065483229', 'allainalvina@hotmail.com', '123Password', 1, NULL, 0, '2023-03-31', '2021-06-22 21:18:42', '2021-06-22 21:59:49'),
(162, 'Darlene', 'Forgrave', '(506) 214-2983', 'darleneforgrave2007@hotmail.com', '#8Association', 1, NULL, 0, '2023-03-31', '2021-06-23 20:39:50', '2021-06-23 20:53:20'),
(163, 'Tammy', 'Brown', '5067217985', 'breelizz@live.com', '#7Coalition', 1, NULL, 0, '2023-03-31', '2021-06-24 20:18:24', '2021-06-24 20:57:43'),
(164, 'Minsoo', 'Clhang', '5063756687', 'clarklinda59@gmail.com', '$99Coalition', 1, NULL, 0, '2023-03-31', '2021-06-24 21:08:58', '2021-06-24 21:42:39'),
(165, 'Jackie', 'Pendelton', '(506) 755 3997', 'lambertscove@gmail.com', '#4Lambert', 1, NULL, 0, '2023-03-31', '2021-06-24 21:31:06', '2021-06-24 21:42:28'),
(166, 'Odessa', 'Arseneau', '506 696 0857', 'seastreetmanor@gmail.com', '123Pass!', 1, NULL, 0, '2023-03-31', '2021-06-24 21:53:07', '2021-06-24 22:07:18'),
(168, 'Jody', 'Munn', '506-260-3354', 'jody@jodymunn.ca', '#7Coalition', 1, NULL, 0, '2023-03-31', '2021-06-28 23:19:34', '2021-06-28 23:23:14'),
(169, 'Amy', 'McNair', '5068515852', 'info1@mcnairmanor.com', '11Beechwood', 1, NULL, 0, '2023-03-31', '2021-07-05 20:42:43', '2022-05-19 02:19:53'),
(170, 'Karen', 'Dougherty-Seamans', '506-755-2221', 'fundybaymanor@nb.aibn.com', 'Password52!', 1, NULL, 0, '2023-03-31', '2021-07-06 20:01:18', '2021-07-06 20:35:30'),
(171, 'Alishia', 'Perry', '1(506)3816922', 'alisha.perry@accesshomecare.ca', 'Password123!!', 1, NULL, 0, '2023-03-31', '2021-07-06 21:38:46', '2021-07-06 21:46:23'),
(172, 'Joel', 'McCarthy', '5066580991', '59pitt@nbnet.nb.ca', 'germain', 1, NULL, 0, '2023-03-31', '2021-07-08 21:34:08', '2021-07-12 19:16:29'),
(173, 'Lorna', 'Hyde', '5066522030', 'lornahydekingston@gmail.com', '$99Coalition', 1, NULL, 0, '2023-03-31', '2021-07-13 22:15:02', '2021-07-19 05:27:14'),
(174, 'June', 'Shaw', '5063759113', 'rdls@bellaliant.net', '354093bd', 1, NULL, 0, '2023-03-31', '2021-07-21 00:29:48', '2021-07-21 03:21:18'),
(175, 'Melinda', 'Smith', '506- 450-0909', 'abcmelindasmith@yahoo.com', '6969', 1, NULL, 0, '2023-03-31', '2021-08-13 01:58:11', '2021-08-13 14:15:28'),
(176, 'Karla', 'Roberts', '5064519814', 'kroberts@nb.aibn.com', '4GetmenoT', 1, NULL, 0, '2023-03-31', '2021-08-18 18:04:28', '2021-08-19 21:02:57'),
(177, 'Martin', 'Fullerton', '5068637832', 'perfectionpropertycare@outlook.com', 'AutumnLee2021', 1, NULL, 0, '2023-03-31', '2021-08-18 21:50:02', '2021-08-19 21:07:22'),
(179, 'Ian', 'Chatham', '866-2799', 'ian.chatham1@Accesshomecare.ca', 'Bignetjaz500', 1, NULL, 0, '2023-03-31', '2021-09-20 19:42:13', '2021-09-20 20:04:27'),
(180, 'Ya Mu', 'Liu', '5066398006', 'yueyangenglish@live.com', 'Starfire@123', 1, NULL, 0, '2023-03-31', '2021-12-14 22:24:55', '2021-12-15 00:20:44'),
(184, 'Eric', 'Walls', '15066253334', 'ericwalls2015@hotmail.com', 'Walls-1978', 1, NULL, 0, '2023-03-31', '2022-01-06 06:48:40', '2022-01-10 00:25:59'),
(185, 'KennethVor', 'KennethVor', '87618886364', 'yuriymuravyov1985899zfp0@mail.ru', 'Fj6b^5bn8tK', 0, NULL, 0, '2023-03-31', '2022-01-27 11:16:53', '2022-01-28 02:41:13'),
(189, 'Jamie', 'Dobbelsteyn', '5066513470', 'jpdobbelsteyn@gmail.com', 'ctd364666', 1, NULL, 0, '2023-03-31', '2022-02-24 23:39:24', '2022-03-06 03:55:31'),
(190, 'Leonard', 'Foster', '15063254536', 'crlb1@nb.aibn.com', 'Billdad284+', 1, NULL, 0, '2023-03-31', '2022-03-16 17:42:26', '2022-03-25 19:06:27'),
(191, 'Jason', 'Wilson', '5062278061', 'jason1@silverfoxretirementliving.com', 'SilverFox', 1, NULL, 0, '2023-03-31', '2022-04-01 23:27:22', '2022-05-10 17:31:15'),
(192, 'sasa', 'asa', '5256366565', 'siroq9988@gmail.com', 'sasa000000', 0, NULL, 0, NULL, '2022-04-11 11:50:00', '2022-04-29 00:09:16'),
(193, 'Jackie', 'Jaillet', '5069614795', 'jackiejaillet@gmail.com', 'Jackielenny2010', 1, NULL, 0, '2023-03-31', '2022-04-11 17:48:25', '2022-05-12 17:27:53'),
(194, 'Tasha', 'Laroche', '5068547229', 'info@arainc.org', 'Ara@1144', 1, NULL, 0, '2023-03-31', '2022-05-03 18:26:51', '2022-05-04 00:39:42'),
(195, 'Charline', 'Johnson', '506-874-5667', 'thebriarlea2@gmail.com', '123parent', 1, NULL, 0, '2023-03-31', '2021-01-18 18:57:25', '2021-04-02 02:06:24'),
(196, 'Charline', 'Johnson', '506-874-5667', 'thebriarlea3@gmail.com', '123parent', 1, NULL, 0, '2023-03-31', '2021-01-18 18:57:25', '2021-04-02 02:06:24'),
(197, 'Charline', 'Johnson', '506-874-5667', 'thebriarlea4@gmail.com', '123parent', 1, NULL, 0, '2023-03-31', '2021-01-18 18:57:25', '2021-04-02 02:06:24'),
(198, 'Charline', 'Johnson', '506-874-5667', 'thebriarlea5@gmail.com', '123parent', 1, NULL, 0, '2023-03-31', '2021-01-18 18:57:25', '2021-04-02 02:06:24'),
(199, 'Ian', 'Chatham', '866-2799', 'ian.chatham2@Accesshomecare.ca', 'Bignetjaz500', 1, NULL, 0, '2023-03-31', '2021-09-20 19:42:13', '2021-09-20 20:04:27'),
(200, 'Ian', 'Chatham', '866-2799', 'ian.chatham3@Accesshomecare.ca', 'Bignetjaz500', 1, NULL, 0, '2023-03-31', '2021-09-20 19:42:13', '2021-09-20 20:04:27'),
(201, 'Ian', 'Chatham', '866-2799', 'ian.chatham4@Accesshomecare.ca', 'Bignetjaz500', 1, NULL, 0, '2023-03-31', '2021-09-20 19:42:13', '2021-09-20 20:04:27'),
(202, 'Leonard', 'Foster', '15063254536', 'crlb2@nb.aibn.com', 'Billdad284+', 1, NULL, 0, '2023-03-31', '2022-03-16 17:42:26', '2022-03-25 19:06:27'),
(203, 'Leonard', 'Foster', '15063254536', 'crlb3@nb.aibn.com', 'Billdad284+', 1, NULL, 0, '2023-03-31', '2022-03-16 17:42:26', '2022-03-25 19:06:27'),
(204, 'Leonard', 'Foster', '15063254536', 'crlb4@nb.aibn.com', 'Billdad284+', 1, NULL, 0, '2023-03-31', '2022-03-16 17:42:26', '2022-03-25 19:06:27'),
(205, 'Sarah', 'Jenkins', '5064719400', 'sarah.jenkins2@nbed.nb.ca', 'Ryansgirl123!', 1, NULL, 0, '2023-03-31', '2020-11-22 04:05:59', '2020-12-04 23:34:10'),
(206, 'Sarah', 'Jenkins', '5064719400', 'sarah.jenkins3@nbed.nb.ca', 'Ryansgirl123!', 1, NULL, 0, '2023-03-31', '2020-11-22 04:05:59', '2020-12-04 23:34:10'),
(207, 'Sarah', 'Jenkins', '5064719400', 'sarah.jenkins4@nbed.nb.ca', 'Ryansgirl123!', 1, NULL, 0, '2023-03-31', '2020-11-22 04:05:59', '2020-12-04 23:34:10'),
(208, 'Colleen', 'Paynter', '15062271478', 'colleenpaynter2@hotmail.com', 'Bloyce12', 1, 'ykC36g2Y5uXawARBeFfpKrzdVSI4GH', 0, '2023-03-31', '2021-02-10 23:23:21', '2021-07-20 15:48:14'),
(209, 'Colleen', 'Paynter', '15062271478', 'colleenpaynter3@hotmail.com', 'Bloyce12', 1, 'ykC36g2Y5uXawARBeFfpKrzdVSI4GH', 0, '2023-03-31', '2021-02-10 23:23:21', '2021-07-20 15:48:14'),
(210, 'Amy', 'McNair', '5068515852', 'info2@mcnairmanor.com', '11Beechwood', 1, NULL, 0, '2023-03-31', '2021-07-05 20:42:43', '2022-05-19 02:19:53'),
(211, 'Amy', 'McNair', '5068515852', 'info3@mcnairmanor.com', '11Beechwood', 1, NULL, 0, '2023-03-31', '2021-07-05 20:42:43', '2022-05-19 02:19:53'),
(212, 'Chris', 'Smith', '506-434-1099', 'chris.smith2@ambienthealth.ca', '4525', 1, NULL, 0, '2023-03-31', '2021-01-08 22:38:19', '2021-03-18 20:35:38'),
(213, 'Chris', 'Smith', '506-434-1099', 'chris.smith3@ambienthealth.ca', '4525', 1, NULL, 0, '2023-03-31', '2021-01-08 22:38:19', '2021-03-18 20:35:38'),
(214, 'Georgina', 'Hubbard', '506-961-4397', 'gmhubb2@gmail.com', 'Children22!', 1, 'WmUsED7CdrAz6NL02iPRZHgFpqtkOj', 0, '2023-03-31', '2020-11-13 21:59:45', '2021-04-22 04:26:08'),
(215, 'Jason', 'Wilson', '5062278061', 'jason2@silverfoxretirementliving.com', 'SilverFox', 1, NULL, 0, '2023-03-31', '2022-04-01 23:27:22', '2022-05-10 17:31:15'),
(216, 'Christine', 'Saunders', '506-443-8000', 'paradisevilla.cs2@gmail.com', 'Carter3106', 1, NULL, 0, '2023-03-31', '2020-11-14 00:01:15', '2020-12-04 23:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `localization`
--

CREATE TABLE `localization` (
  `id` int(11) NOT NULL,
  `lang_key` text NOT NULL,
  `lang_value` text NOT NULL,
  `language` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `localization`
--

INSERT INTO `localization` (`id`, `lang_key`, `lang_value`, `language`) VALUES
(1, 'HEADER_CALLUS', 'Call Us at', 'en'),
(2, 'HEADER_CALLUS', 'Call Us at', 'fr'),
(3, 'LATEST_NEWS', 'Latest News', 'en'),
(4, 'LATEST_NEWS', 'Latest News', 'fr'),
(5, 'RESOURCES', 'Resources', 'en'),
(6, 'QUICK_CONTACT', 'Quick Contact', 'en'),
(7, 'WANT_TO_HEAR', 'Want To Hear From Us?', 'en'),
(8, 'COPYRIGHT', 'Copyright', 'en'),
(9, 'RIGHTS_RESERVED', 'All Rights Reserved', 'en'),
(10, 'PAGE_NOT_FOUND_TITLE', 'Oops! Page Not Found', 'en'),
(11, 'PAGE_NOT_FOUND_BODY', 'The page you were looking for could not be found.', 'en'),
(12, 'PAGE_NOT_FOUND_BUTTON', 'Return Home page', 'en'),
(13, 'RESOURCES', 'Resources', 'fr'),
(14, 'QUICK_CONTACT', 'Quick Contact', 'fr'),
(15, 'WANT_TO_HEAR', 'Want To Hear From Us?', 'fr'),
(16, 'COPYRIGHT', 'Copyright', 'fr'),
(17, 'RIGHTS_RESERVED', 'All Rights Reserved', 'fr'),
(18, 'PAGE_NOT_FOUND_TITLE', 'Oops! Page Not Found', 'fr'),
(19, 'PAGE_NOT_FOUND_BODY', 'The page you were looking for could not be found.', 'fr'),
(20, 'PAGE_NOT_FOUND_BUTTON', 'Return Home page', 'fr'),
(21, 'ABOUT_ME', 'About Me', 'en'),
(22, 'CONTACT', 'Contact', 'en'),
(23, 'PHONE', 'Phone', 'en'),
(24, 'EMAIL', 'Email', 'en'),
(25, 'ENTER_NAME', 'Enter Name', 'en'),
(26, 'ENTER_EMAIL', 'Enter Email', 'en'),
(27, 'ENTER_SUBJECT', 'Enter Subject', 'en'),
(28, 'ENTER_MESSAGE', 'Enter Message', 'en'),
(29, 'PLEASE_WAIT', 'Please wait...', 'en'),
(30, 'SEND_YOUR_MESSAGE', 'Send your message', 'en'),
(31, 'ABOUT_ME', 'About Me', 'fr'),
(32, 'CONTACT', 'Contact', 'fr'),
(33, 'PHONE', 'Phone', 'fr'),
(34, 'EMAIL', 'Email', 'fr'),
(35, 'ENTER_NAME', 'Enter Name', 'fr'),
(36, 'ENTER_EMAIL', 'Enter Email', 'fr'),
(37, 'ENTER_SUBJECT', 'Enter Subject', 'fr'),
(38, 'ENTER_MESSAGE', 'Enter Message', 'fr'),
(39, 'PLEASE_WAIT', 'Please wait...', 'fr'),
(40, 'SEND_YOUR_MESSAGE', 'Send your message', 'fr'),
(41, 'POST_HOME_MESSAGE', 'Post Your Special Care Home with NBSCHA <span style=\"color:#CD291D;font-family: PermanentMarker;\"><b style=\"font-weight: 800;\">Today!</b></span>', 'fr'),
(42, 'POST_HOME_BODY', '<p class=\"text-2 mb-0 appear-animation animated maskUp appear-animation-visible\" data-appear-animation=\"maskUp\" data-appear-animation-delay=\"1000\" style=\"animation-delay: 1000ms; font-size: 17px!important; color: #000;\"> Would you like to be added to the New Brunswick Special Care Home Directory?</p><br>\r\n                  <p style=\"margin-bottom: 0px; font-size: 17px; color: #000;\">\r\n                      *<b>Please fill out the fields below, especially all fields that have a (*) as these are mandatory fields and you will not be fully registered without these mandatory items.</b></p>\r\n                  <p style=\"font-size: 17px; color: #000;\">Once you have clicked the <b style=\"font-weight: 800; color: red\">“SUBMIT”</b> button we will send you a confirmation email as soon as payment has been received and your facility was officially added to our website.\r\n                  </p>', 'fr'),
(43, 'FILL FORM', 'FILL IN FORM BELOW', 'fr'),
(44, 'FILL_FORM_TAGLINE', 'BE PART OF OUR ONLINE COMMUNITY!', 'fr'),
(45, 'FIRST_NAME', 'First Name', 'fr'),
(46, 'LAST_NAME', 'Last Name', 'fr'),
(47, 'EMAIL_ADDRESS', 'Email', 'fr'),
(48, 'PHONE_NUMBER', 'Phone Number', 'fr'),
(49, 'PASSWORD', 'Password', 'fr'),
(50, 'CONFIRM_PASSWORD', 'Confirm Password', 'fr'),
(51, 'FILL_FORM', 'FILL IN FORM BELOW', 'fr'),
(52, 'ADD_CARE_HOME', 'Add Special Care Home Details!', 'fr'),
(53, 'HOME_NAME', 'Special Care Home Name', 'fr'),
(54, 'HOME_ADDRESS', 'Special Care Home Address', 'fr'),
(55, 'HOME_POST', 'Special Care Home Postal Code', 'fr'),
(56, 'HOME_CONTACT_PERSON', 'Special Care Home Contact Person', 'fr'),
(57, 'HOME_CONTACT_EMAIL', 'Special Care Home Email', 'fr'),
(58, 'HOME_CONTACT_PHONE', 'Special Care Home Phone', 'fr'),
(59, 'HOME_CONTACT_FAX', 'First Name', 'fr'),
(60, 'HOME_SELECT_BED', 'Select Number of Beds', 'fr'),
(61, 'HOME_MAXIMUM_BED', 'Maximum Licensed Beds', 'fr'),
(62, 'HOME_SELECT_CARELEVEL', 'Select Level of Care', 'fr'),
(63, 'HOME_SELECT_LANGUAGE', 'Select Language(s)', 'fr'),
(64, 'HOME_SELECT_REGION', 'Select Region', 'fr'),
(65, 'HOME_PHARMACY', 'Special Care Home Pharmacy Name', 'fr'),
(66, 'HOME_DESCRIPTION', 'Description of Home and Services to the Public', 'fr'),
(67, 'NOTES_ADMIN', 'Notes/Comments for Admin', 'fr'),
(68, 'UPLOAD_IMAGE', 'Upload Main Image', 'fr'),
(69, 'UPLOAD_IMAGE2', 'Upload 2nd Image', 'fr'),
(70, 'UPLOAD_IMAGE3', 'Upload 3rd Image', 'fr'),
(71, 'UPLOAD_IMAGE4', 'Upload 4th Image', 'fr'),
(72, 'UPLOAD_IMAGE5', 'Upload 5th Image', 'fr'),
(73, 'UPLOAD_IMAGE6', 'Upload 6th Image', 'fr'),
(74, 'VIRTUAL_TOUR', 'Virtual Tour (Youtube Link)', 'fr'),
(75, 'FB_LINK', 'Facebook link', 'fr'),
(76, 'INSTA_LINK', 'Instagram link', 'fr'),
(77, 'TW_LINK', 'Twitter link', 'fr'),
(78, 'YT_LINK', 'YouTube link', 'fr'),
(79, 'LI_LINK', 'LinkedIn link', 'fr'),
(80, 'WEB_LINK', 'Website link', 'fr'),
(81, 'BOXES_INSTRUCTION', '<h4>Please check the boxes if you answer <b><u>YES</u></b> to any of the following questions:</h4>', 'fr'),
(82, 'YEARLY_FEES', 'Yearly Membership Fees', 'fr'),
(83, 'CHOSE_PAYMENT', 'Please chose your Preferred payment option', 'fr'),
(84, 'SELECT', 'Select', 'fr'),
(85, 'PAYMENT_INFO', 'Payment Info', 'fr'),
(86, 'FINISHED_SUBMIT', 'Finished/Submit', 'fr'),
(87, 'POST_HOME_MESSAGE', 'Post Your Special Care Home with NBSCHA <span style=\"color:#CD291D;font-family: PermanentMarker;\"><b style=\"font-weight: 800;\">Today!</b></span>', 'en'),
(88, 'POST_HOME_BODY', '<p class=\"text-2 mb-0 appear-animation animated maskUp appear-animation-visible\" data-appear-animation=\"maskUp\" data-appear-animation-delay=\"1000\" style=\"animation-delay: 1000ms; font-size: 17px!important; color: #000;\"> Would you like to be added to the New Brunswick Special Care Home Directory?</p><br>\r\n                  <p style=\"margin-bottom: 0px; font-size: 17px; color: #000;\">\r\n                      *<b>Please fill out the fields below, especially all fields that have a (*) as these are mandatory fields and you will not be fully registered without these mandatory items.</b></p>\r\n                  <p style=\"font-size: 17px; color: #000;\">Once you have clicked the <b style=\"font-weight: 800; color: red\">“SUBMIT”</b> button we will send you a confirmation email as soon as payment has been received and your facility was officially added to our website.\r\n                  </p>', 'en'),
(89, 'FILL FORM', 'FILL IN FORM BELOW', 'en'),
(90, 'FILL_FORM_TAGLINE', 'BE PART OF OUR ONLINE COMMUNITY!', 'en'),
(91, 'FIRST_NAME', 'First Name', 'en'),
(92, 'LAST_NAME', 'Last Name', 'en'),
(93, 'EMAIL_ADDRESS', 'Email', 'en'),
(94, 'PHONE_NUMBER', 'Phone Number', 'en'),
(95, 'PASSWORD', 'Password', 'en'),
(96, 'CONFIRM_PASSWORD', 'Confirm Password', 'en'),
(97, 'FILL_FORM', 'FILL IN FORM BELOW', 'en'),
(98, 'ADD_CARE_HOME', 'Add Special Care Home Details!', 'en'),
(99, 'HOME_NAME', 'Special Care Home Name', 'en'),
(100, 'HOME_ADDRESS', 'Special Care Home Address', 'en'),
(101, 'HOME_POST', 'Special Care Home Postal Code', 'en'),
(102, 'HOME_CONTACT_PERSON', 'Special Care Home Contact Person', 'en'),
(103, 'HOME_CONTACT_EMAIL', 'Special Care Home Email', 'en'),
(104, 'HOME_CONTACT_PHONE', 'Special Care Home Phone', 'en'),
(105, 'HOME_CONTACT_FAX', 'First Name', 'en'),
(106, 'HOME_SELECT_BED', 'Select Number of Beds', 'en'),
(107, 'HOME_MAXIMUM_BED', 'Maximum Licensed Beds', 'en'),
(108, 'HOME_SELECT_CARELEVEL', 'Select Level of Care', 'en'),
(109, 'HOME_SELECT_LANGUAGE', 'Select Language(s)', 'en'),
(110, 'HOME_SELECT_REGION', 'Select Region', 'en'),
(111, 'HOME_PHARMACY', 'Special Care Home Pharmacy Name', 'en'),
(112, 'HOME_DESCRIPTION', 'Description of Home and Services to the Public', 'en'),
(113, 'NOTES_ADMIN', 'Notes/Comments for Admin', 'en'),
(114, 'UPLOAD_IMAGE', 'Upload Main Image', 'en'),
(115, 'UPLOAD_IMAGE2', 'Upload 2nd Image', 'en'),
(116, 'UPLOAD_IMAGE3', 'Upload 3rd Image', 'en'),
(117, 'UPLOAD_IMAGE4', 'Upload 4th Image', 'en'),
(118, 'UPLOAD_IMAGE5', 'Upload 5th Image', 'en'),
(119, 'UPLOAD_IMAGE6', 'Upload 6th Image', 'en'),
(120, 'VIRTUAL_TOUR', 'Virtual Tour (Youtube Link)', 'en'),
(121, 'FB_LINK', 'Facebook link', 'en'),
(122, 'INSTA_LINK', 'Instagram link', 'en'),
(123, 'TW_LINK', 'Twitter link', 'en'),
(124, 'YT_LINK', 'YouTube link', 'en'),
(125, 'LI_LINK', 'LinkedIn link', 'en'),
(126, 'WEB_LINK', 'Website link', 'en'),
(127, 'BOXES_INSTRUCTION', '<h4>Please check the boxes if you answer <b><u>YES</u></b> to any of the following questions:</h4>', 'en'),
(128, 'YEARLY_FEES', 'Yearly Membership Fees', 'en'),
(129, 'CHOSE_PAYMENT', 'Please chose your Preferred payment option', 'en'),
(130, 'SELECT', 'Select', 'en'),
(131, 'PAYMENT_INFO', 'Payment Info', 'en'),
(132, 'FINISHED_SUBMIT', 'Finished/Submit', 'en'),
(133, 'READ_MORE', 'Read More', 'en'),
(134, 'POSTED_BY', 'posted by', 'en'),
(135, 'CATEGORIES', 'Categories', 'en'),
(136, 'NO_NEWS', 'No news items to display', 'en'),
(137, 'C_NAME', 'Contact Name', 'en'),
(138, 'C_EMAIL', 'Email', 'en'),
(139, 'C_PHONE', 'Phone', 'en'),
(140, 'C_LANGUAGE', 'Language(s)', 'en'),
(141, 'C_REGION', 'Region', 'en'),
(142, 'C_POST', 'Postal Code', 'en'),
(143, 'C_LEVEL', 'Level of Care', 'en'),
(144, 'C_BED', 'Bed', 'en'),
(145, 'C_PHARMACY', 'Pharmacy', 'en'),
(146, 'C_FACILITY', 'Facility', 'en'),
(147, 'C_FEATURES', 'Features of Services', 'en'),
(148, 'C_CAPACITY', 'Capacity', 'en'),
(149, 'C_LICBED', 'Licensed Beds', 'en'),
(150, 'C_VACANCY', 'Current Vacancy', 'en'),
(151, 'C_ASK', 'Ask a question?', 'en'),
(152, 'ENTER_PHONE', 'Enter Phone', 'en'),
(153, 'SEND_MESSAGE', 'Send your message', 'en'),
(154, 'RESET', 'Reset', 'en'),
(155, 'SOCIAL_NETWORK', 'Social Network', 'en'),
(156, 'C_FAX', 'Fax', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `manuals`
--

CREATE TABLE `manuals` (
  `id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manuals_desc`
--

CREATE TABLE `manuals_desc` (
  `desc_id` int(11) NOT NULL,
  `manuals_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manual_policies`
--

CREATE TABLE `manual_policies` (
  `id` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `policy_issue_date` date DEFAULT NULL,
  `policy_update_date` date DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manual_policies_desc`
--

CREATE TABLE `manual_policies_desc` (
  `desc_id` int(11) NOT NULL,
  `manual_policies_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manual_policy_categories`
--

CREATE TABLE `manual_policy_categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manual_sections`
--

CREATE TABLE `manual_sections` (
  `id` int(11) NOT NULL,
  `categorized` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `manual_section_categories`
--

CREATE TABLE `manual_section_categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `mid` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`mid`, `first_name`, `last_name`, `password`, `salt`, `email`, `phone`, `status`, `created`, `delete_status`) VALUES
(1, 'jan', 'seely', '2e3d23c280a2a46f65b07cf2ef9e6f4eae96b0e5', 'RbgCzG', 'janseely@rogers.com', '5066394478', 1, '2020-10-22 20:00:21', 0),
(2, 'Georgina', 'Hubbard', 'd9187b00c845b25ba00927e2824e27e231379730', 'buRBji', 'gmhubb1@gmail.com', '506-961-4397', 1, '2020-11-13 21:59:45', 0),
(3, 'Jennifer', 'Eagan', '407c629a001b43f779fbd164f27575b2ca658aa3', 'aypKNP', 'jen@eagan.ca', '5062739394', 1, '2020-11-13 22:03:12', 0),
(4, 'Miluska', 'Hessen Walton', '7fc586bab43b91be18ff7eac87c804e6734a2edf', 'O3JkTy', 'miluskahwalton@gmail.com', '(506)444-1166', 1, '2020-11-13 22:22:26', 0),
(5, 'Elizabeth', 'McLay', '3b8a10a2e0690ed73413b5e1aac2622ebd0784a8', '40ZnSo', 'administration@alouetteresidence.ca', '5068579200', 1, '2020-11-13 22:29:50', 0),
(6, 'Kim', 'Davis', '69451ae975a80814f2a842d811d9db97d6000d80', 'D3hd5Q', 'kdavis@shannex.com', '15066477953', 1, '2020-11-13 22:50:06', 0),
(7, 'Mary', 'Phillips', '8a6393cd42ee3960537954eff92f55c311d96e52', 'tCUpA6', 'maryjane-ox@hotmail.com', '15068719326', 1, '2020-11-13 23:03:05', 0),
(8, 'Christa', 'Matheson', '5100428e73bd087da08207043e6b0c8a68b66a79', 'WslFZA', 'cmatheson@lochlomondvilla.com', '5066437174', 1, '2020-11-13 23:22:37', 0),
(9, 'Christine', 'Saunders', '5ce3237987beaaf6892b18cdd98be86dee81fffe', 'etla3B', 'paradisevilla.cs1@gmail.com', '506-443-8000', 1, '2020-11-14 00:01:15', 0),
(10, 'Darlene', 'Mazerolle', 'e8cc0a2caddb60d1508c3729803935d732ac4058', 'kqHbE2', 'd_mazerolle96@hotmail.com', '5068690624', 1, '2020-11-14 00:33:53', 0),
(11, 'Krissy', 'Travis', '9866addc1c7fb1d69cef357d164d4a6ba859eefa', 'JaZHFR', 'Krissy5646@gmail.com', '5063337507', 1, '2020-11-14 03:22:13', 0),
(12, 'Jennifer', 'Paul Armstrong', '121dd29735ac865ab8203084b523f08d34324845', '3lEcS9', 'jennlynnpaul@hotmail.com', '5066392424', 1, '2020-11-15 03:39:27', 0),
(13, 'Sara', 'Williston', '9eb965a80a92784f349b308d15fd35d7f0953070', '7ZMHUa', 'riverbendresidence@hotmail.com', '506-352-0137', 1, '2020-11-16 06:02:20', 0),
(14, 'Fran', 'Cooke', '2c9d2afa75614881e52e7802f056a49f9ebf4880', 'orvgK2', 'agapehome@bellaliant.com', '5068325935', 1, '2020-11-16 23:48:55', 0),
(15, 'Pamela', 'Bowen', '901f9e09dcdf226cef6a9ec2ac33b797840e6007', 'ACy09J', 'pbowen@shannex.com', '5064557275', 1, '2020-11-17 02:00:04', 0),
(16, 'Lucie', 'Boudreau', '4373371d27b2cd2fda15dbef62c4d1c0ee509f6c', 'YKrSAb', 'balancedwellnesscenter@gmail.com', '506-850-8851', 1, '2020-11-17 19:36:03', 0),
(17, 'Katrina', 'Drost', 'ce49a90d30d23530577bc3fd6f3aa33abcabbe7a', 'wsYGB5', 'katrina.4.boys@hotmail.com', '506 977 4286', 1, '2020-11-18 10:23:28', 0),
(18, 'Cristie', 'Dykeman', '68646c8a724b83c5f8d21be79663d71d1552f9c6', '60EkCS', 'slowcurrentspecialcarehome@gmail.com', '5064400654', 1, '2020-11-19 06:49:57', 0),
(19, 'Mary', 'Cormier', 'a6ddbeab1624bc8b1f076a98d14dd81d5e0b0163', 'XPFwT9', 'cottage.53@hotmail.ca', '5065482534', 1, '2020-11-19 20:51:03', 0),
(20, 'Sarah', 'Jenkins', '0cbb15b97b9f11f21a17624975686301a6377d2d', '4umcpZ', 'sarah.jenkins1@nbed.nb.ca', '5064719400', 1, '2020-11-22 04:05:59', 0),
(21, 'Crystal', 'Powell', '843232ece71129e432aa137601484691e44aa116', 'HF5tVs', 'kathleen11251@gmail.com', '15066474087', 1, '2020-11-26 00:20:39', 0),
(22, 'Susan', 'VanWart', '072a94741cbd12f7afcdda3ff51dd7093bcc51cc', 'FMxXv2', 'susanmvanwart@gmail.com', '506 476-7879', 1, '2020-11-27 23:58:39', 0),
(23, 'Danielle', 'DeAgazio', '85c1532c99d005cf5f67b9006685a958233f11c6', 'Ir6bCL', 'info@protem.ca', '5068749652', 1, '2020-11-28 00:40:38', 0),
(24, 'John', 'Grass', 'ef03db7ab39436fce97f5c7eda5d6b7b88254c11', 'otUOZW', 'jgrass1213@rogers.com', '15068723340', 1, '2020-11-28 01:26:27', 0),
(25, 'Charlene', 'Noye', '4aa2a0cce2285d2dac23468043f91237d732d111', 'SEVlxF', 'charlenenoye@outlook.com', '5067592773', 1, '2020-11-28 04:10:32', 0),
(26, 'Lisa', 'Melanson', '01c854d9c023fbe54fa20ea95d66a8f402e98829', 'VKlyDX', 'jklm2k2@hotmail.com', '506-650-3807', 1, '2020-11-28 04:35:26', 0),
(27, 'Kelly', 'Briggs', '7e1a9fdcbc1509eb9b5d91cc5f8174b61cfcee15', '8fdBoP', 'Kellybriggs12@live.ca', '5063275041', 1, '2020-11-28 05:26:01', 0),
(28, 'Amy', 'Cook', '54e9eb272e7e00ae81d768096d3fb0dda14a5f69', 'ncIa95', 'rideout_amy@hotmail.com', '5066426058', 1, '2020-11-28 20:16:23', 0),
(29, 'Lori', 'McGrath', '0e682a62226c390706c8df34ab7168f06a5d327d', 'GON0cq', 'lorrainelynnmc@gmail.com', '5066523083', 1, '2020-11-28 20:17:05', 0),
(30, 'Steve', 'Mclay', 'bf1ccda1bcce97920eab547bd221a1f640162dc0', 'vwqsbm', 'mclaysbayhaven@gmail.com', '5064666611', 1, '2020-11-28 21:16:53', 0),
(31, 'Collette', 'Doucette', '97e796418083be2b84e1d745d3c2e0d3c85da3bd', 'eQ2VUY', 'collette.obs@rogers.com', '5063123301', 1, '2020-11-29 13:06:53', 0),
(32, 'Lillian', 'Drapeau', '3a09a916bddaaf326fcc2ac3d11787d43fcd0054', 'NZjLof', 'lillian.drapeau@gmail.com', '+15065464587', 1, '2020-11-30 05:26:06', 0),
(33, 'Jeffrey', 'Hunter', '26fab1b789ea9daf5f313baf23fb8521bbc3cfde', 'nDCazQ', 'jefhunter@rogers.com', '5063874518', 1, '2020-11-30 17:53:20', 0),
(34, 'Mercy', 'Burge', 'c0dca8f1e7a145716850dc2848e2871b8b12bb49', 'Uevx9O', 'ilovemyjobcanada@gmail.com', '15065122189', 1, '2020-12-01 05:07:18', 0),
(35, 'Lisa', 'Levesque', '403c252c5d4164fae90ebde968de28d0e1673b33', 'a6TE5Y', 'lislev10@gmail.com', '530-0082', 1, '2020-12-04 22:58:29', 0),
(36, 'Ruth', 'Sawler', '88b1b0c2989a066dcbe76959c902993ced2a4ef6', 's7bQZR', 'ruan@nbnet.nb.ca', '5063759193', 1, '2020-12-05 19:55:37', 0),
(37, 'Tammy', 'Long', 'a8fe0885abfa6de4666b1360ac5de63dfeb071c5', 'W4dB6m', 'tammylong@hotmail.com', '5068392715', 1, '2020-12-09 05:57:34', 0),
(38, 'Cary', 'MacDonald', '019faf40fdd2586b5b52adb41ecac66d6e670c4c', 'qtoFp1', 'carymac63@gmail.com', '5068668725', 1, '2020-12-09 21:44:38', 0),
(39, 'Susan', 'Dixson', 'd487d8f91495e2c0a6d385e4d0f5ac4413635e25', '4oAh8F', 'serenacare@bellaliant.com', '5063811550', 1, '2020-12-13 22:44:37', 0),
(40, 'Jennifer', 'Burns', 'c5ba734620ed5fafdcd2b3e11de1890e24bd1793', 'RWXnAZ', 'jenburnsmanor@gmail.com', '5068635245', 1, '2020-12-17 21:17:37', 0),
(41, 'Chris', 'Smith', '07a9e4249386ac7d30e2272cdbae4dfc43fc5399', 'UGKHjF', 'chris.smith1@ambienthealth.ca', '506-434-1099', 1, '2021-01-08 22:38:19', 0),
(42, 'Charline', 'Johnson', '97d2a8a04fa2ac9d889138dae22e777b4f2e9a37', 'Q39VtZ', 'thebriarlea1@gmail.com', '506-874-5667', 1, '2021-01-18 18:57:25', 0),
(43, 'Jody', 'Munn', '7e705a898400f48a2ee856b61a86cb07b0ef1d32', 'AZoptb', 'jodymunnster@gmail.com', '5062603354', 1, '2021-01-23 21:59:33', 0),
(44, 'Colleen', 'Paynter', '0e6eb6da480fb2b5dedaa241882f391c1078f29d', 'NVD60H', 'colleenpaynter1@hotmail.com', '15062271478', 1, '2021-02-10 23:23:21', 0),
(45, 'Danielle', 'Gallant', '13363f707bbe36ab1edacbb05de2f276c8a638d1', 'n0rWAg', 'lauramanor86@gmail.com', '5066508706', 1, '2021-04-01 22:39:56', 0),
(46, 'Ann', 'Waddell', '9aa62b71b02013b8c24f70f530eb93b124ed4f0f', 'CGUN2f', 'waddell@levesqueonline.com', '506-333-1286', 1, '2021-04-07 15:28:37', 0),
(47, 'Wilma', 'Ledin', 'f408a66dce007f03f9bed725a5375680fb856815', '203DcA', 'buchananwilma@gmail.com', '5062292170', 1, '2021-04-12 22:37:42', 0),
(48, 'Heather', 'Perrin', '73839a51d35c207c78db882e26a651c99cc6f2fd', 'yQSdJw', 'hseely86@hotmail.com', '5066448100', 1, '2021-04-14 09:18:53', 0),
(49, 'vanessa', 'harris', '2cc0d7289b33db99435bb7d7f46ae6ee412b066e', 'hfvlYB', 'metcalfmanor1@gmail.com', '15062141690', 1, '2021-04-19 18:30:58', 0),
(50, 'Julie', 'Steeves', '83caedbb8f62135250c154d443b57e9f2f79e047', 'ADXTY1', 'thecedarsarf@gmail.com', '506-939-2233', 1, '2021-04-21 19:09:11', 0),
(51, 'Wendy', 'Symonds', '2ca317404616cb39587b86da346996f7c436b6fb', 'iqB9t5', 'bartlettgardenscarehome@gmail.com', '902 664. 4089', 1, '2021-04-22 00:36:21', 0),
(52, 'Sandra', 'Ferris', '3e5d5aa9de1c60ea35b7d3744d0eeee2e63c7d21', 'o9Snq6', 'marion.macdougall@outlook.com', '(506)6531615', 1, '2021-04-22 01:42:11', 0),
(53, 'Tom', 'Knox', '90e61400e4ddd65913d4d8bc100353aac6d93530', 'AtEjwN', 'knoxtom@rocketmail.com', '5064675117', 1, '2021-04-23 00:33:57', 0),
(54, 'PAULA', 'FASQUEL', '6eec6e75d74359b006c66b0d72500d13abc3e268', 'xFXTGN', 'mail@northmintoresidence.ca', '506-327-9000', 1, '2021-04-23 00:34:40', 0),
(55, 'Lynn', 'Wallace', '300415477f23b0ac710b359c9bbd9ce4c162e588', 'uXIfWg', 'lpearle@hotmail.com', '5064341869', 1, '2021-04-25 23:23:43', 0),
(56, 'Crystal', 'Snowdon', 'fe0a101ff94fe2544ae4ec9882a49f688f7fb3f1', 'rKjIQT', 'crystallynnsnowdon1973@gmail.com', '506538-2968', 1, '2021-05-01 23:27:48', 0),
(57, 'Steven', 'Wen', '0056fc2c97323a77ada64687803f3d3098df9592', '2SB8wR', 'stevenwen@yahoo.com', '5066321888', 1, '2021-05-03 19:17:00', 0),
(58, 'Leonard', 'Gervais', '85b6c2bcaf7c24ffff8b925e70e301ec60f5be2e', '87vf6j', 'parkviewgardens203@outlook.com', '506-458-8968', 1, '2021-05-05 20:46:56', 0),
(59, 'Alison', 'Baxter', 'f67a73837aafa86a129fa71b346dc3eb6e4c727b', '2iCRVJ', 'abaxter@shannex.com', '5063870533', 1, '2021-05-11 18:50:09', 0),
(60, 'Erynn', 'Bailey', 'adb164fe77842fd474c9975583f109e5f3f5f44a', '0g9d3G', 'erynn@enhancedliving.ca', '506-422-8600 ext 5', 1, '2021-05-18 20:44:19', 0),
(61, 'Wendy', 'Maillet', 'd5dc1556bc0ded22eff3d78c59f22f494697693b', 'FYITcZ', 'wmaillet@shannex.com', '506-343-4068', 1, '2021-06-07 19:33:00', 0),
(62, 'Emily', 'Swim', '8c1e0ed562447af61b630fea37885f98ffab2c0d', 'iNh290', 'gdswim@xplornet.com', '506-328-5471', 1, '2021-06-16 21:08:37', 0),
(63, 'Alvina', 'Allain', 'e5cb7f8ac39d11b61648516c3cc91b13e1e2f53c', '4XQ8cC', 'allainalvina@hotmail.com', '5065483229', 1, '2021-06-22 21:18:42', 0),
(64, 'Darlene', 'Forgrave', '16a118028951d5c92c8da33ca2c016997832ebfa', 'bO9tWo', 'darleneforgrave2007@hotmail.com', '(506) 214-2983', 1, '2021-06-23 20:39:50', 0),
(65, 'Tammy', 'Brown', 'ef63562f8c435ef5e16099178fb66f886e74f6b0', 'gwty05', 'breelizz@live.com', '5067217985', 1, '2021-06-24 20:18:24', 0),
(66, 'Minsoo', 'Clhang', '117beb4f0ae38818fa42adfe969012fd94d0dc61', '7q1pvi', 'clarklinda59@gmail.com', '5063756687', 1, '2021-06-24 21:08:58', 0),
(67, 'Jackie', 'Pendelton', '14c212b3eae26bdcaf549bb9814044a252fcff3b', 'kVtmbZ', 'lambertscove@gmail.com', '(506) 755 3997', 1, '2021-06-24 21:31:06', 0),
(68, 'Odessa', 'Arseneau', 'a9c15e0d1a0944523c1db591cd444e8b003e8e9d', 'e7qwkR', 'seastreetmanor@gmail.com', '506 696 0857', 1, '2021-06-24 21:53:07', 0),
(69, 'Jody', 'Munn', 'deed7dfe852c1ad29cd1c8f7de05e957b78f7bb4', 'KNz8pT', 'jody@jodymunn.ca', '506-260-3354', 1, '2021-06-28 23:19:34', 0),
(70, 'Amy', 'McNair', 'b6aa0153b9ce7c99b35bc4c563eb4f843c983074', '8eGWsH', 'info1@mcnairmanor.com', '5068515852', 1, '2021-07-05 20:42:43', 0),
(71, 'Karen', 'Dougherty-Seamans', '0f8ade5ee5c3a8a35e46145cafa9080bb28c8e32', 'aTzfxk', 'fundybaymanor@nb.aibn.com', '506-755-2221', 1, '2021-07-06 20:01:18', 0),
(72, 'Alishia', 'Perry', '985a756432cd52ac83e85b406a67cb95ca2d22cb', '9xrLUI', 'alisha.perry@accesshomecare.ca', '1(506)3816922', 1, '2021-07-06 21:38:46', 0),
(73, 'Joel', 'McCarthy', 'ce10f5622acfd27b42ec002bd2e0394b98661f33', 'mihMdk', '59pitt@nbnet.nb.ca', '5066580991', 1, '2021-07-08 21:34:08', 0),
(74, 'Lorna', 'Hyde', 'a5a6d732c96840b29876ed5833879181035f56e1', 'DoW0Sa', 'lornahydekingston@gmail.com', '5066522030', 1, '2021-07-13 22:15:02', 0),
(75, 'June', 'Shaw', 'f60db0d5c143e65b5fef69f8eff01059b0da20b8', 't4dV2K', 'rdls@bellaliant.net', '5063759113', 1, '2021-07-21 00:29:48', 0),
(76, 'Melinda', 'Smith', '83208d2fbc59e795021ceab4d327a85aed26bf03', '1XqMwT', 'abcmelindasmith@yahoo.com', '506- 450-0909', 1, '2021-08-13 01:58:11', 0),
(77, 'Karla', 'Roberts', 'f8fca1910ff5c970cd92d31172dc810634055562', 'SIcKOm', 'kroberts@nb.aibn.com', '5064519814', 1, '2021-08-18 18:04:28', 0),
(78, 'Martin', 'Fullerton', '066dca9e896c0d9ddd6940e6ba718af62166f332', 'mqyJQp', 'perfectionpropertycare@outlook.com', '5068637832', 1, '2021-08-18 21:50:02', 0),
(79, 'Ian', 'Chatham', '5ef4c636fc7050a5aab0dfca92af66819901398d', '4zOUZo', 'ian.chatham1@Accesshomecare.ca', '866-2799', 1, '2021-09-20 19:42:13', 0),
(80, 'Eric', 'Walls', '107071d7d640205e7029f88363a66574badec4b7', 'VJets3', 'ericwalls2015@hotmail.com', '15066253334', 1, '2022-01-06 06:48:40', 0),
(81, 'Jamie', 'Dobbelsteyn', '64e8d6b3d6c957153731bbfbeb63c8ae7ae34e8b', 'MijUmX', 'jpdobbelsteyn@gmail.com', '5066513470', 1, '2022-02-24 23:39:24', 0),
(82, 'Leonard', 'Foster', '44f220c1ebe205d485488bd455835b6897f88267', 'Sb3uBO', 'crlb1@nb.aibn.com', '15063254536', 1, '2022-03-16 17:42:26', 0),
(83, 'Jason', 'Wilson', 'fd2c79c6e9be918f89adac161fe333a0df798be8', '9YkceZ', 'jason1@silverfoxretirementliving.com', '5062278061', 1, '2022-04-01 23:27:22', 0),
(84, 'Jackie', 'Jaillet', '07b8b9ddaf47c413c47554e83b08d52037896162', '12zjK4', 'jackiejaillet@gmail.com', '5069614795', 1, '2022-04-11 17:48:25', 0),
(85, 'Tasha', 'Laroche', 'ff52999be82241276d9c893785d9b3473dd9c545', 'oKe47H', 'info@arainc.org', '5068547229', 1, '2022-05-03 18:26:51', 0),
(86, 'Charline', 'Johnson', '8695f178f13142a5af9490d4e8620979a29c80dd', 'K9wP8o', 'thebriarlea2@gmail.com', '506-874-5667', 1, '2021-01-18 18:57:25', 0),
(87, 'Charline', 'Johnson', 'b2d21be6d84dc46910f1625aadbf68dd1aa5a741', '3jywU7', 'thebriarlea3@gmail.com', '506-874-5667', 1, '2021-01-18 18:57:25', 0),
(88, 'Charline', 'Johnson', 'cdbb8adff684575128169bc057fdfe26e0444fa4', 'fqhWeE', 'thebriarlea4@gmail.com', '506-874-5667', 1, '2021-01-18 18:57:25', 0),
(89, 'Charline', 'Johnson', '22b9a01a18f280217f33d6ae8136a12a66b8dc2a', '4DdpKX', 'thebriarlea5@gmail.com', '506-874-5667', 1, '2021-01-18 18:57:25', 0),
(90, 'Ian', 'Chatham', '8b3131362f991c1feb5661fa0b89308eb49314d5', 'OaSlos', 'ian.chatham2@Accesshomecare.ca', '866-2799', 1, '2021-09-20 19:42:13', 0),
(91, 'Ian', 'Chatham', 'e31518e660596d95bcdea06a324890820d97e6db', 'R9OUwK', 'ian.chatham3@Accesshomecare.ca', '866-2799', 1, '2021-09-20 19:42:13', 0),
(92, 'Ian', 'Chatham', 'd66ea08a4e6b378b86d5fce2a3c0b58343499b43', '4PHjKX', 'ian.chatham4@Accesshomecare.ca', '866-2799', 1, '2021-09-20 19:42:13', 0),
(93, 'Leonard', 'Foster', '41460b874098c566a786d0835af6d499044a4cc7', 'ghbC5P', 'crlb2@nb.aibn.com', '15063254536', 1, '2022-03-16 17:42:26', 0),
(94, 'Leonard', 'Foster', 'ca4b51b7e16a95afe1eb9b2502c076e6a02bc6ba', 'KO6pGc', 'crlb3@nb.aibn.com', '15063254536', 1, '2022-03-16 17:42:26', 0),
(95, 'Leonard', 'Foster', 'f83a9441bbd8044d4771c02e0c47e86c3a9f8993', 'ohyeLx', 'crlb4@nb.aibn.com', '15063254536', 1, '2022-03-16 17:42:26', 0),
(96, 'Sarah', 'Jenkins', '03eff623d10c6a35ed2a66e69e6e74677b887171', 'TCKV6G', 'sarah.jenkins2@nbed.nb.ca', '5064719400', 1, '2020-11-22 04:05:59', 0),
(97, 'Sarah', 'Jenkins', 'a081b70ce6eb24daf416c970dac0b033793cc829', 'yLOQBv', 'sarah.jenkins3@nbed.nb.ca', '5064719400', 1, '2020-11-22 04:05:59', 0),
(98, 'Sarah', 'Jenkins', '7627ca6a7ae07cfc335978f9023885819bafe84e', 'eDK7Qs', 'sarah.jenkins4@nbed.nb.ca', '5064719400', 1, '2020-11-22 04:05:59', 0),
(99, 'Colleen', 'Paynter', '2f324fa92f3145cf8f8fe2d2c3baff1a40588b23', 'FM5Vg8', 'colleenpaynter2@hotmail.com', '15062271478', 1, '2021-02-10 23:23:21', 0),
(100, 'Colleen', 'Paynter', 'a00d2b8c356ae9f535d76993f96350b9f1bdce07', 'frGlXD', 'colleenpaynter3@hotmail.com', '15062271478', 1, '2021-02-10 23:23:21', 0),
(101, 'Amy', 'McNair', 'a76afbf885532550f2abf5fcc621e02cdde444bf', 'FXm1lD', 'info2@mcnairmanor.com', '5068515852', 1, '2021-07-05 20:42:43', 0),
(102, 'Amy', 'McNair', 'f1d3fd1b325cecb4b0f846cfb23a3d0f32d1bac1', 'RDnuNc', 'info3@mcnairmanor.com', '5068515852', 1, '2021-07-05 20:42:43', 0),
(103, 'Chris', 'Smith', '870d3773b1e043f11e0b6efe42fd9add4f648576', 'OjWPyo', 'chris.smith2@ambienthealth.ca', '506-434-1099', 1, '2021-01-08 22:38:19', 0),
(104, 'Chris', 'Smith', '47cd1bff4f4953729a82e2259ce5423c5bd21fdc', 'C8aRIv', 'chris.smith3@ambienthealth.ca', '506-434-1099', 1, '2021-01-08 22:38:19', 0),
(105, 'Georgina', 'Hubbard', '5fd6be9a3255c9448c37e89bf96cd0f7b996fd32', 'vFiQoz', 'gmhubb2@gmail.com', '506-961-4397', 1, '2020-11-13 21:59:45', 0),
(106, 'Jason', 'Wilson', '2cc6bd7002f3720e63271c5289a6c3c199d7b186', 'nlHe9k', 'jason2@silverfoxretirementliving.com', '5062278061', 1, '2022-04-01 23:27:22', 0),
(107, 'Christine', 'Saunders', '2c7fe464e53b1e047dea5bb81ba2bfac6edced7b', 'qMfI3g', 'paradisevilla.cs2@gmail.com', '506-443-8000', 1, '2020-11-14 00:01:15', 0);

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `residence_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `certificate` text,
  `wallet_certificate` text,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `identifier`, `member_id`, `residence_id`, `package_id`, `issue_date`, `expiry_date`, `certificate`, `wallet_certificate`, `status`) VALUES
(1, '2205210001', 1, 1, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(2, '2205210002', 2, 2, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(3, '2205210003', 3, 3, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(4, '2205210004', 4, 4, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(5, '2205210005', 5, 5, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(6, '2205210006', 6, 6, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(7, '2205210007', 7, 7, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(8, '2205210008', 8, 8, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(9, '2205210009', 9, 9, 4, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(10, '2205210010', 10, 10, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(11, '2205210011', 11, 11, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(12, '2205210012', 12, 12, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(13, '2205210013', 13, 13, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(14, '2205210014', 14, 14, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(15, '2205210015', 15, 15, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(16, '2205210016', 16, 16, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(17, '2205210017', 17, 17, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(18, '2205210018', 18, 18, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(19, '2205210019', 19, 19, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(20, '2205210020', 20, 20, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(21, '2205210021', 21, 21, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(22, '2205210022', 22, 22, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(23, '2205210023', 23, 23, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(24, '2205210024', 24, 24, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(25, '2205210025', 25, 25, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(26, '2205210026', 26, 26, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(27, '2205210027', 27, 27, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(28, '2205210028', 28, 28, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(29, '2205210029', 29, 29, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(30, '2205210030', 30, 30, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(31, '2205210031', 31, 31, 4, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(32, '2205210032', 32, 32, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(33, '2205210033', 33, 33, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(34, '2205210034', 34, 34, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(35, '2205210035', 35, 35, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(36, '2205210036', 36, 36, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(37, '2205210037', 37, 37, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(38, '2205210038', 38, 38, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(39, '2205210039', 39, 39, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(40, '2205210040', 40, 40, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(41, '2205210041', 41, 41, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(42, '2205210042', 42, 42, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(43, '2205210043', 43, 43, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(44, '2205210044', 44, 44, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(45, '2205210045', 45, 45, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(46, '2205210046', 46, 46, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(47, '2205210047', 47, 47, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(48, '2205210048', 48, 48, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(49, '2205210049', 49, 49, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(50, '2205210050', 50, 50, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(51, '2205210051', 51, 51, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(52, '2205210052', 52, 52, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(53, '2205210053', 53, 53, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(54, '2205210054', 54, 54, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(55, '2205210055', 55, 55, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(56, '2205210056', 56, 56, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(57, '2205210057', 57, 57, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(58, '2205210058', 58, 58, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(59, '2205210059', 59, 59, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(60, '2205210060', 60, 60, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(61, '2205210061', 61, 61, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(62, '2205210062', 62, 62, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(63, '2205210063', 63, 63, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(64, '2205210064', 64, 64, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(65, '2205210065', 65, 65, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(66, '2205210066', 66, 66, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(67, '2205210067', 67, 67, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(68, '2205210068', 68, 68, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(69, '2205210069', 69, 69, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(70, '2205210070', 70, 70, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(71, '2205210071', 71, 71, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(72, '2205210072', 72, 72, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(73, '2205210073', 73, 73, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(74, '2205210074', 74, 74, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(75, '2205210075', 75, 75, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(76, '2205210076', 76, 76, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(77, '2205210077', 77, 77, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(78, '2205210078', 78, 78, 3, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(79, '2205210079', 79, 79, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(80, '2205210080', 80, 80, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(81, '2205210081', 81, 81, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(82, '2205210082', 82, 82, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(83, '2205210083', 83, 83, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(84, '2205210084', 84, 84, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(85, '2205210085', 85, 85, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(86, '2205210086', 86, 86, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(87, '2205210087', 87, 87, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(88, '2205210088', 88, 88, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(89, '2205210089', 89, 89, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(90, '2205210090', 90, 90, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(91, '2205210091', 91, 91, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(92, '2205210092', 92, 92, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(93, '2205210093', 93, 93, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(94, '2205210094', 94, 94, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(95, '2205210095', 95, 95, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(96, '2205210096', 96, 96, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(97, '2205210097', 97, 97, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(98, '2205210098', 98, 98, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(99, '2205210099', 99, 99, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(100, '2205210100', 100, 100, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(101, '2205210101', 101, 101, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(102, '2205210102', 102, 102, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(103, '2205210103', 103, 103, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(104, '2205210104', 104, 104, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(105, '2205210105', 105, 105, 1, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(106, '2205210106', 106, 106, 2, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1),
(107, '2205210107', 107, 107, 4, '2022-05-21', '2023-03-31', 'a:2:{s:11:\"certificate\";s:33:\"<p>\r\n	This is Main template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:35:\"<p>\r\n	This is wallet template</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `membership_packages`
--

CREATE TABLE `membership_packages` (
  `pid` int(11) NOT NULL,
  `bed_count` int(11) NOT NULL DEFAULT '0',
  `bed_unlimited` tinyint(1) NOT NULL DEFAULT '0',
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `certificate_template` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_packages`
--

INSERT INTO `membership_packages` (`pid`, `bed_count`, `bed_unlimited`, `price`, `certificate_template`, `sort_order`, `status`, `delete_status`) VALUES
(1, 20, 0, 100.00, 1, 0, 1, 0),
(2, 40, 0, 400.00, 1, 0, 1, 0),
(3, 60, 0, 500.00, 1, 0, 1, 0),
(4, 0, 1, 850.00, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_packages_desc`
--

CREATE TABLE `membership_packages_desc` (
  `desc_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_packages_desc`
--

INSERT INTO `membership_packages_desc` (`desc_id`, `package_id`, `title`, `description`, `language`) VALUES
(1, 1, '1-20', '', 'en'),
(2, 2, '20-40', '', 'en'),
(3, 3, '40-60', '', 'en'),
(4, 4, '60+', '', 'en'),
(5, 1, '1-20', '', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `membership_requests`
--

CREATE TABLE `membership_requests` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `home_name` varchar(255) NOT NULL,
  `home_address` varchar(255) NOT NULL,
  `home_postalcode` varchar(255) NOT NULL,
  `home_contact_name` varchar(255) NOT NULL,
  `home_email` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `home_fax` varchar(255) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `max_beds_count` int(11) NOT NULL DEFAULT '0',
  `home_language` int(11) NOT NULL,
  `home_level` int(11) NOT NULL,
  `pharmacy_name` varchar(255) NOT NULL,
  `facilities` varchar(255) NOT NULL,
  `region_id` int(11) NOT NULL,
  `description` text,
  `comments` text,
  `mainimage` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `image4` varchar(255) DEFAULT NULL,
  `image5` varchar(255) DEFAULT NULL,
  `image6` varchar(255) DEFAULT NULL,
  `virtual_tour` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `features` text NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(255) NOT NULL,
  `payment_response` text NOT NULL,
  `payment_info` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `members_login_history`
--

CREATE TABLE `members_login_history` (
  `id` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members_login_history`
--

INSERT INTO `members_login_history` (`id`, `mid`, `ipaddress`, `timestamp`) VALUES
(1, 1, '127.0.0.1', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `member_homes`
--

CREATE TABLE `member_homes` (
  `id` bigint(20) NOT NULL,
  `spch_name` varchar(100) DEFAULT NULL,
  `spch_address` varchar(200) DEFAULT NULL,
  `spch_contact_name` varchar(100) DEFAULT NULL,
  `spch_email` varchar(100) DEFAULT NULL,
  `spch_phone` varchar(20) DEFAULT NULL,
  `spch_fax` varchar(20) DEFAULT NULL,
  `spch_dept_name` varchar(50) DEFAULT NULL,
  `spch_postal_code` varchar(30) DEFAULT NULL,
  `spch_num_bed` varchar(11) DEFAULT NULL,
  `spch_level_care` varchar(100) DEFAULT NULL,
  `spch_pharmacy_name` varchar(100) DEFAULT NULL,
  `spch_notes` text,
  `spch_member_id` bigint(20) DEFAULT NULL,
  `photo_url` varchar(200) DEFAULT NULL,
  `photo_url_two` varchar(100) DEFAULT NULL,
  `photo_url_three` varchar(100) DEFAULT NULL,
  `photo_url_four` varchar(100) DEFAULT NULL,
  `photo_url_five` varchar(100) DEFAULT NULL,
  `photo_url_six` varchar(100) DEFAULT NULL,
  `fb_url` varchar(100) DEFAULT NULL,
  `inst_url` varchar(100) DEFAULT NULL,
  `twi_url` varchar(100) DEFAULT NULL,
  `youtube_url` varchar(100) DEFAULT NULL,
  `linkdin_url` varchar(100) DEFAULT NULL,
  `website_url` varchar(100) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `spch_facility` varchar(200) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `charge_above_government` tinyint(1) NOT NULL DEFAULT '0',
  `provide_transport` tinyint(1) NOT NULL DEFAULT '0',
  `allow_pet` tinyint(1) NOT NULL DEFAULT '0',
  `allow_furniture` tinyint(1) NOT NULL DEFAULT '0',
  `comfort_clothing_money` tinyint(1) NOT NULL DEFAULT '0',
  `transport_medical_appointment` tinyint(1) NOT NULL DEFAULT '0',
  `home_hairdressing` tinyint(1) NOT NULL DEFAULT '0',
  `have_foot_care` tinyint(1) NOT NULL DEFAULT '0',
  `staf_diabetes_insulin_train` tinyint(1) NOT NULL DEFAULT '0',
  `staf_oxygen_thrapy_train` tinyint(1) NOT NULL DEFAULT '0',
  `staf_colostomy_care_train` tinyint(1) NOT NULL DEFAULT '0',
  `staf_wound_care_train` tinyint(1) NOT NULL DEFAULT '0',
  `staf_dementia_care_train` tinyint(1) NOT NULL DEFAULT '0',
  `accept_incontinent_urine` tinyint(1) NOT NULL DEFAULT '0',
  `monitoring_sys_door` tinyint(1) NOT NULL DEFAULT '0',
  `accept_mrsa_positve_client` tinyint(1) NOT NULL DEFAULT '0',
  `have_experience_client_suffering_addictions` tinyint(1) NOT NULL DEFAULT '0',
  `client_keep_physicians` tinyint(1) NOT NULL DEFAULT '0',
  `have_practitioner_doc_nurse` tinyint(1) NOT NULL DEFAULT '0',
  `relationship_extra_menual_nursing` tinyint(1) NOT NULL DEFAULT '0',
  `client_extra_mural_care` tinyint(1) NOT NULL DEFAULT '0',
  `provide_adaptive_equipment` tinyint(1) NOT NULL DEFAULT '0',
  `how_to_acquire` tinyint(1) NOT NULL DEFAULT '0',
  `provide_house_excursions` tinyint(1) NOT NULL DEFAULT '0',
  `resident_outreach_attend_program` tinyint(1) NOT NULL DEFAULT '0',
  `resident_work_community` tinyint(1) NOT NULL DEFAULT '0',
  `staf_medication_administartion_traing` tinyint(1) NOT NULL DEFAULT '0',
  `accommodate_special_diet` tinyint(1) NOT NULL DEFAULT '0',
  `accessible_shower_wheelchair_person` tinyint(1) NOT NULL DEFAULT '0',
  `have_outdoor_area` tinyint(1) NOT NULL DEFAULT '0',
  `specific_visting_hour` tinyint(1) NOT NULL DEFAULT '0',
  `provide_reference_existing_client` tinyint(1) NOT NULL DEFAULT '0',
  `accept_resident_incontinent` tinyint(1) DEFAULT '0',
  `administering_medication_training_required` tinyint(1) DEFAULT '0',
  `free_vacancy` int(11) DEFAULT '0',
  `num_open_beds` int(11) DEFAULT '0',
  `is_free_vocancy` tinyint(1) NOT NULL DEFAULT '1',
  `is_new` int(11) NOT NULL DEFAULT '1',
  `public_description` text,
  `open_day` varchar(20) DEFAULT NULL,
  `close_day` varchar(20) DEFAULT NULL,
  `open_time` varchar(20) DEFAULT NULL,
  `close_time` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member_homes`
--

INSERT INTO `member_homes` (`id`, `spch_name`, `spch_address`, `spch_contact_name`, `spch_email`, `spch_phone`, `spch_fax`, `spch_dept_name`, `spch_postal_code`, `spch_num_bed`, `spch_level_care`, `spch_pharmacy_name`, `spch_notes`, `spch_member_id`, `photo_url`, `photo_url_two`, `photo_url_three`, `photo_url_four`, `photo_url_five`, `photo_url_six`, `fb_url`, `inst_url`, `twi_url`, `youtube_url`, `linkdin_url`, `website_url`, `status`, `spch_facility`, `region`, `charge_above_government`, `provide_transport`, `allow_pet`, `allow_furniture`, `comfort_clothing_money`, `transport_medical_appointment`, `home_hairdressing`, `have_foot_care`, `staf_diabetes_insulin_train`, `staf_oxygen_thrapy_train`, `staf_colostomy_care_train`, `staf_wound_care_train`, `staf_dementia_care_train`, `accept_incontinent_urine`, `monitoring_sys_door`, `accept_mrsa_positve_client`, `have_experience_client_suffering_addictions`, `client_keep_physicians`, `have_practitioner_doc_nurse`, `relationship_extra_menual_nursing`, `client_extra_mural_care`, `provide_adaptive_equipment`, `how_to_acquire`, `provide_house_excursions`, `resident_outreach_attend_program`, `resident_work_community`, `staf_medication_administartion_traing`, `accommodate_special_diet`, `accessible_shower_wheelchair_person`, `have_outdoor_area`, `specific_visting_hour`, `provide_reference_existing_client`, `accept_resident_incontinent`, `administering_medication_training_required`, `free_vacancy`, `num_open_beds`, `is_free_vocancy`, `is_new`, `public_description`, `open_day`, `close_day`, `open_time`, `close_time`, `created_at`, `updated_at`) VALUES
(45, 'Birchmount Lodge', '144 Birchmount Drive, Moncton by', 'Joanne Allen', 'openarmscare@hotmail.com', '506-384-7573', '506-384-7523', NULL, 'E1C8E7', '21-40', 'Level-2', 'Medicine Shoppe 294', NULL, 32, '1612457219-1601c2503cca45.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Moncton', 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 32, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-13 16:59:45', '2021-06-23 21:00:23'),
(46, 'Open Arms Special Care Home', '98 Glengrove Road, Moncton', 'Joanne Allen', 'openarmscare@hotmail.com', '506-204-8409', NULL, NULL, 'E1A5X5', '1-20', 'Level-2', 'Medicine Shoppe 294', NULL, 214, '1605286785-15faebb818e60d.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 8, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-13 16:59:45', '2021-06-23 21:00:14'),
(47, 'All Needs Special Care Home Inc.', '152 Douglas Avenue, Fredericton NB E3A 2N9', 'Miluska H Walton', 'miluskahwalton@gmail.com', '(506)459-2186', '(506)459-0120', NULL, 'E3A 2N9', '1-20', 'Level-2', 'Fredericton Sobeys Northside', NULL, 34, '1605288146-15faec0d25a22c.jpeg', '1605288146-15faec0d25a72e.jpeg', '1617801340-1606db07c94989.JPG', '1618950129-1607f37f133707.JPG', '1619292804-160847284db800.JPG', '1618950129-1607f37f13a92a.JPG', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 8, 1, 0, 'Residents may be driven to appointments when necessary. We ask that families pitch in with family members appointments for their own good, as long as permitted.', NULL, NULL, NULL, NULL, '2020-11-13 17:22:26', '2021-06-24 22:22:51'),
(48, 'Alouette Special Care Home', '2100 Amirault Street, Dieppe, NB E1A 7K4', 'Elizabeth McLay', 'administration@alouetteresidence.ca', '5068579200', '5068579201', NULL, 'E1A 7K4', '41-60', 'Level-2', 'Dieppe Pharmacy', NULL, 35, '1605288590-15faec28ee8951.png', '1605288590-15faec28ee8ac7.png', '1605288590-15faec28eeb590.jpg', '1605288590-15faec28eec3df.JPG', '1605288590-15faec28eecc60.JPG', '1605288590-15faec28eed133.JPG', NULL, NULL, NULL, NULL, NULL, 'alouettespecialcarehome.com', 1, 'Mental Health', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 8, 55, 1, 0, 'n', NULL, NULL, NULL, NULL, '2020-11-13 17:29:50', '2021-06-15 23:54:57'),
(49, 'Concorde Hall', '15 Shannex Drive', 'Kim Davis', 'kdavis@shannex.com', '506-848-3194', '848-3201', NULL, 'E2E 0M5', '41-60', 'Level-2', 'Lawton\'s', NULL, 36, '1623024369-160bd62f1b28e3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://experienceparkland.com/en/lifestyle-options/supportive-lifestyle/', 1, 'Seniors', 'Saint John', 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 9, 60, 1, 0, 'Licensed 60 bed special care home located in Quispamsis, NB. Welcome to Parkland In The Valley.', NULL, NULL, NULL, NULL, '2020-11-13 17:50:06', '2022-05-20 20:30:10'),
(50, 'Hillside View Special Care Home', '560 Front Mountain Road, Moncton NB E1G 3H3', 'Mary Phillips', 'hillsideview13@gmail.com', '5063883018', '5063883018', NULL, 'E1G3H3', '1-20', 'Level-3G', 'Jean Coutu', NULL, 37, '1605290585-15faeca5903702.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'j', NULL, NULL, NULL, NULL, '2020-11-13 18:03:05', '2021-04-03 00:36:10'),
(51, 'Loch Lomond Villa Special Care Home', '185 Loch Lomond Rd, Saint John, NB E2J 3S3', 'Christa', 'cmatheson@lochlomondvilla.com', '5066438497', '5066438283', NULL, 'E2J 3S3', '1-20', 'Level-2', 'Lawton\'s Pharmacy', NULL, 38, '1605291757-15faeceed322de.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, '.', NULL, NULL, NULL, NULL, '2020-11-13 18:22:37', '2021-04-03 00:36:11'),
(52, 'Paradise Villa Inc.', '665 Clements Drive, Fredericton', 'Monique Corbett', 'directorofcare@paradise-villa.ca', '506-443-8000', '506-454-3413', NULL, 'E1G 7J2', '60+', 'Level-2', 'Lawtons', 'We have 60 Level 2 Beds and 18 Level 3B Beds', 39, '1617719585-1606c7121811e1.jpg', '1617719585-1606c712181768.jpg', '1617719585-1606c712183436.JPG', '1617719585-1606c712186606.JPG', '1617719585-1606c712189620.JPG', '1617719585-1606c71218c67c.JPG', 'https://www.facebook.com/paradisevillainc/', NULL, NULL, NULL, NULL, 'https://paradise-villa.ca/', 1, 'Seniors', 'Fredericton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping,\r\nchurches, bus route, and a short drive to downtown Fredericton.  Our new state of the art\r\nassisted living Senior Residence Complex truly defines what seniors living should\r\nbe.  Thoughtfully designed and beautifully executed, this well-appointed residence offers 78\r\nsingle first-class suites, and 4 of the 78 can be converted into suites for couples or\r\nsiblings.  This complex cares for level 2 and 3b residents.  This property is very well-managed\r\nwith experienced and committed staff.', NULL, NULL, NULL, NULL, '2020-11-13 19:01:15', '2021-04-02 22:26:41'),
(53, 'Mazerolle special care home LTD', '448 Gauvin Rd, Dieppe NB E1A 1M1', 'Darlene Mazerolle', 'd_mazerolle96@hotmail.com', '506.869.0624', '506.855.5911', NULL, 'E1A1M1', '21-40', 'Level-2', 'Familiprix', 'residents have there own gmail ...     mazerolle.residents@gmail.com', 40, '1619054772-16080d0b43d88a.jpg', '1619047615-16080b4bf025e3.jpg', '1619047615-16080b4bf03ec3.jpg', '1619047615-16080b4bf05da3.jpg', '1619047615-16080b4bf08182.jpg', '1619047615-16080b4bf08f37.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 3, 26, 1, 0, 'Mazerolle Special care home is a licensed 26 bed level 2 home established in 1995.\r\nOur home is located in the beautiful city of Dieppe which offers there residents a shared cost for accessible transportation to and from medical appointments and outings. We are located on the city bus route and walking distance to corner store, church, mall and bowling alley.\r\nOur home is a ground floor facility with wheel chair accessibility inside and out with large patios, outdoor green space for lots of flowers and veggie gardens and a beautiful breeze off the cool marsh.\r\nThe home offers homestyle meals and snacks that adhere to Canada\'s food guide along with special diets including diabetic, cardiac, nephrology.\r\nThe facility has lots of safety features with sturdy grip poles and transfer benches in all bathrooms along with a sprinkler system in place and monitored fire alarms with security cameras. We are inspected yearly by fire marshal office, public health and social development.\r\nOur cozy living room has lots of windows, big screen TV and leather lazy boy chairs. There is an activity room with internet café set up for virtual visits and access to our house Gmail account. We have a full service hair and nail salon and a lazy house cat named \"Bonnie\".\r\nWe offer personal care, laundry services, medication and diabetic management, support from Extra-Mural and updating any new physicians orders as needed with lots of activities both inside and out. Staff are dedicated, love their job and have met or exceeded all social developments hiring requirements.. \r\nCome join our family!', NULL, NULL, NULL, NULL, '2020-11-13 19:33:53', '2021-06-10 18:45:21'),
(55, 'Riverdale Manor', '3 Riverdale Dr, Hampton', 'Krissy travis', 'Krissy5646@gmail.com', '5068324051', '5068328989', NULL, 'E5N 5k2', '1-20', 'Level-2', 'Lawton sussex', 'NA', 42, '1631037989-16137aa25c2ee5.jpg', '1631037989-16137aa25c84dd.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Country style home, located in Hampton. Home away from home!', NULL, NULL, NULL, NULL, '2020-11-13 22:22:13', '2020-12-04 23:15:21'),
(56, 'Serenity Cove Special Care Home', '9919 Rte 102, Woodmans Point, NB E5K 4P5', 'Jennifer Paul Armstrong', 'jennlynnpaul@hotmail.com', '5067578155', '5062170265', NULL, 'E5K 4P5', '1-20', 'Level-2', 'Guardian Drugs GrandBay', NULL, 43, '1605393567-15fb05c9fbfca9.jpeg', '1648505766-1624233a663ba5.jpg', '1605393567-15fb05c9fc2bf3.jpeg', '1648505766-1624233a66683b.jpg', '1648505766-1624233a6684c7.jpg', '1648505766-1624233a669479.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Blended Facility', 'Saint John', 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 9, 1, 0, 'Our home is in the country and has a huge back deck with a waterfall which makes it so relaxing for the residents to enjoy the nice summer days.  Our residents also enjoy their own private rooms.  Our residents also love that our home use to be a rectory.  We are only 1 minute from Grandbay-Westfield and 15 Minutes to get into town.', NULL, NULL, NULL, NULL, '2020-11-14 22:39:27', '2021-09-07 21:12:54'),
(58, 'Riverbend residence', '158 Wellington St., Miramichi, NB E1N 1L9', 'Sara Williston', 'riverbendresidence@hotmail.com', '506-352-0137', '506-352-3035', NULL, 'E1N1L9', '1-20', 'Level-2', 'Shoppers drug mart Douglastown', NULL, 44, '1605488540-15fb1cf9cf419c.jpeg', '1605488541-15fb1cf9d0025c.jpeg', '1605488541-15fb1cf9d013ae.jpeg', '1605488541-15fb1cf9d021a8.jpeg', '1605488541-15fb1cf9d03fb2.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Miramichi', 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 20, 1, 0, 'Questions you may have about living in our Special Care Home: \r\nRiverbend Residence @ Norma’s Place\r\n\r\n\r\nWho owns and operates Riverbend Residence? Local Miramichiers, Colin and Sara Williston, own and operate Riverbend Residence@ NormasPlace.  Colin has his degree in Business from Dalhousie University and is a proprietor for over 25 years and Sara is a Registered Nurse of over 25 years\r\n\r\nWhen did Riverbend Residence @ Normas Place open? We opened May 1st, 2020\r\nWhere did Riverbend Residence get its name? We wished to incorporate our beautiful river system while commemorating Colin’s Mother, Norma.  Each resident room is named after a tributary river which feeds into the Great Miramichi River\r\n\r\nWhere are you located?  We are centrally located at 158 Wellington Street, Downtown Chatham, Miramichi, NB \r\n\r\nWhat level of care do you offer at Riverbend Residence? We specialize in Level 1 and Level 2 adult care.  We help with assistance in personal hygiene, medication administration, and activities of daily living.  \r\n\r\nWho pays for what? – The cost to stay at Riverbend is the same for everyone. Social Development carries out a financial assessment which will determine the amount that you will pay Riverbend Residence for your stay and what Social Development will contribute.  Depending on your income amount, a combination of your income and a subsidized amount provided by Social Development will cover the cost of rent at Riverbend Residence @ Norma’s Place. Once again, this is dependent on your individual income. \r\n\r\nWhat is included in the rent at Riverbend? Riverbend provides you a comfortable single room equipped with furnishings, 3 nutritious meals, snacks, entertainment, heat, lights, wifi, and 24 hour professional personal care.\r\n\r\nDo I receive any personal money to do with as I wish? – Each month, everyone will receive a comfort allowance as per Social Development. This allowance helps cover the costs of your medications and any personal items you may require.\r\n\r\nWhat is in each room?  In each room, there is a single bed, bed linens including a duvet, individual sinks, a chest of drawers, a bedside table and lamp, an armoire, a chair, a television, and a telephone. (cable service and personal phone line is provided at a reduced rate of $50/mth)\r\n\r\nCan couples live together? -  Riverbend Residence will do their best to accommodate the request to have side-by-side rooms however; there are no double rooms in our home.\r\n\r\nDoes Riverbend make and take me to any medical appointments?  We ask that you and your family maintain your medical management with respect to doctor’s appointments, and any other healthcare appointments. In the event that your family is not able to assist, we can help make arrangements with you to meet those needs.  \r\n\r\nAre there items I am not allowed to bring? – You are not permitted to have any appliance with an element in your rooms (i.e coffee maker, toaster, kettle etc.). Also, anything with an open flame is not permitted as per fire regulations and the safety to our home.\r\n\r\nAre pets allowed?  Riverbend Residence @ Norma’s Place welcomes visits from pets with permission from the operator.  \r\n\r\nWhat is your smoking policy? – Smoking is not permitted in or around Riverbend Residence @ Norma’s Place within 9 meters of an entrance; however, there is a designated smoking area on the grounds of our home.\r\n\r\nHow many residents does your home accommodate? We can accommodate 20 people with individual care needs at Riverbend Residence @ Norma’s Place.  \r\n\r\nWhat is the meal service like? – We take pride in saying that each day there are 3 home cooked meals served along with snacks in the afternoon and evening if desired by the residents. Meals are served at approximately: 8am, 12pm, and 4:30pm with the largest meal of the day being lunchtime. \r\n\r\nAre families welcome to visit? – Families and friends are always encouraged and certainly welcome. Sometimes there are rules and regulations that we are required to follow as per Social Development.\r\n\r\nAre there specific visiting hours? There are no designated visiting hours at Riverbend Residence @ Norma’s Place however due to some Social Development regulations during health outbreaks, restrictions may be in place with restricted or limited visiting.  It is best to call us to find out if there are such rules in place.\r\n\r\nAm I allowed to give gifts to employees? – Riverbend Residence @ Norma’s Place kindly asks that the public and residents do not give gifts of significant monetary value to employees. Small gifts, however, of insignificant monetary value are permitted, for example cookies that can be enjoyed by all staff.\r\n\r\nDo I bring my medications? Upon arrival, you are asked to bring all of you medications.  Your medications will be placed in a locked medication room and administered by staff only. You are not permitted to keep any medications on hand or in your room as per Social Development guidelines except for rescue medications such as rescue inhaler or epi pens.\r\n\r\nAre there social activities at Riverbend Residence?  We have had several different social activities at Riverbend including- Movie nights, music entertainers, crafts, weekly bingo, daily card games, campfire outings, washer toss, etc…\r\n\r\nIs alcohol or recreational drugs permitted at Riverbend?  We do not permit the use of alcohol or recreational drugs in our home unless directed and monitored by their primary heath care provider.\r\nCan I leave Riverbend to visit friends and family? What about overnight stays?  We encourage you to maintain and foster personal and/or family relationships, which includes your family and friends visiting you in your home and you visiting them in theirs.\r\n\r\nWho do I contact if I have any other questions?  You can call Sara at 625-3998 or Colin at 623-8608 \r\nWe would like to thank you for your interest in Riverbend Residence@ Norma’s Place\r\nColin and Sara', NULL, NULL, NULL, NULL, '2020-11-16 01:02:21', '2021-07-04 00:15:45'),
(59, 'Agape Home', '690 Route 121, Bloomfield Norton, NB E5N 4V3', 'Hazen and Fran Cooke', 'agapehome@bellaliant.com', '5068325935', '506 832-8815', NULL, 'E5N4V3', '1-20', 'Level-2', 'Lawtons', NULL, 45, '1605552535-15fb2c9977c0fa.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, '.', NULL, NULL, NULL, NULL, '2020-11-16 18:48:55', '2020-12-04 23:17:49'),
(60, 'Brunswick Hall', '35 Patience Lane, Fredericton, NB E3B 0K4', 'Robyn Hutchison', 'rhutchison@shannex.com', '506-447-6450', '506-447-6451', NULL, 'E3B 0K4', '41-60', 'Level-2', 'Lawtons', 'n/a', 47, '1623081032-160be4048e66fb.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Fredericton', 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 2, 60, 1, 0, 'Services designed to meet specialized care needs. Assisted Living allows you to enjoy the lifestyle you want, while providing a helping hand to support you in your daily activities.', NULL, NULL, NULL, NULL, '2020-11-16 21:00:04', '2022-04-04 21:58:32'),
(61, 'B&B Balanced Wellness Center Inc/Centre du mieux-être équilibré B&B Inc.', '49 Bulman Drive Moncton NB', 'Lucie Boudreau', 'balancedwellnesscenter@gmail.com', '506-387-8456', '506-387-7060', NULL, 'E1G1G9', '1-20', 'Level-4', 'Lawtons', NULL, 48, '1605623763-15fb3dfd31048f.PNG', NULL, NULL, NULL, NULL, NULL, 'https://m.facebook.com/communityresidence/?ref=bookmarks', NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental Disabilities', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-17 14:36:03', '2020-12-04 23:18:24'),
(62, 'Always Here Care Home', '32 Baxter Rd. Saint John NB', 'Katrina Drost', 'katrina.4.boys@hotmail.com', '506 696 6750', '506 693 6932', NULL, 'E2H2V5', '1-20', 'Level-2', 'Lawton’s McAllister', 'na', 50, '1605677008-15fb4afd0aabe3.jpeg', '1643319836-161f3121c5052e.jpg', '1643319836-161f3121c51c89.jpg', '1643319836-161f3121c52c74.jpg', '1643319836-161f3121c53873.jpg', '1643319836-161f3121c543c9.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 6, 1, 0, 'Welcome to our Home nestled on a beautiful property at 32 Baxter Rd.\r\n\r\nI would like to list a few items of interest:\r\n\r\n~ Owner lives on site with her family, 2 pups and a cat.\r\n~ Owner has operated this Care Home for 27 years.\r\n~ All one level.\r\n~ Wheelchair accessible.\r\n~ Designated Smoking area.\r\n~ 24 hr. supervision.\r\n~ Medications administered by qualified staff.\r\n~ Home cooked meals prepared by qualified staff.\r\n~ Transportation provided to and from Drs. appts.\r\n~ No upcharge.\r\n~ Foot Care provided for eligible residents.\r\n~ Mobile hairdresser.\r\n~ Established ongoing relationship with Extra Mural.\r\n~ All private rooms.\r\n~ 2 full baths.\r\n\r\nIf there’s further info./questions, please feel free to reach out.', NULL, NULL, NULL, NULL, '2020-11-18 05:23:28', '2022-01-28 02:46:39'),
(63, 'Slow Current Special Care Home', '1126 Route 148, Nashwaak Village', 'Cristie Dykeman', 'slowcurrentspecialcarehome@gmail.com', '5064597494', NULL, NULL, 'E6C1N2', '1-20', 'Level-2', 'Ross Drugs', 'N/A', 51, '1605750597-15fb5cf459a1f8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Slowcurrentspecialcarehome.com', 1, 'Seniors', 'Fredericton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'N/A', NULL, NULL, NULL, NULL, '2020-11-19 01:49:57', '2021-04-07 10:11:11'),
(64, 'Melansons special care home', '215 st Patrick st bathurst nb', 'Tammy dunn', 'cottage.53@hotmail.ca', '5065482534', '5065465502', NULL, 'E2a4c9', '1-20', 'Level-2', 'Sobeys', NULL, 52, '1619979059-1608eeb3341301.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Chaleur', 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 3, 14, 1, 0, 'Residential care house operating since 1985. Offer full suite of services including medical transport, medication management, outings, meal prep and special diets, laundry,  personal hygiene, central location,', NULL, NULL, NULL, NULL, '2020-11-19 15:51:03', '2021-04-23 18:55:21'),
(67, 'Hillside Lodge Inc', '155 Tilley Drive, Fredericton NB E3B 5L2', 'Sarah Jenkins', 'sarah.jenkins@nbed.nb.ca', '5064507600', NULL, NULL, 'E3B 5L2', '1-20', 'Level-2', 'Medicine Shop on King Street', NULL, 55, '1605999959-15fb99d578f2e1.JPG', '1605999959-15fb99d578f50a.JPG', '1605999959-15fb99d578f6c0.jpg', '1605999959-15fb99d578fc57.JPG', '1605999959-15fb99d57901d2.jpg', '1605999959-15fb99d57906f4.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 9, 1, 0, 'We are a level 2 home located in the heart of Fredeicton. We provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', NULL, NULL, NULL, NULL, '2020-11-21 23:05:59', '2021-05-05 04:19:36'),
(68, 'MacLeods Too Inc', '6437 Route 105, Lower Brighton, NB E7P 3J5', 'Heather Allison', 'kitt1yg@gmail.com', '5063758395', NULL, NULL, 'E7P 3J5', '1-20', 'Level-4', 'Medicine Shop - Woodstock', NULL, 205, '1605999959-15fb99d57946ce.jpg', '1619831069-1608ca91d00584.jpg', '1619831069-1608ca91d01dc1.jpg', '1619831069-1608ca91d034a9.jpg', '1619831069-1608ca91d0478c.jpg', '1619831069-1608ca91d05ca1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Fredericton', 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 12, 1, 0, 'We are a level 4 home located in the heart of Hartland.  We provide ourselves on the level of care we provide to our residents.  Please reach out to us if you are looking for a placement for your loved one.  We would be happy to hear from you.', NULL, NULL, NULL, NULL, '2020-11-21 23:05:59', '2021-05-05 04:19:06'),
(69, 'Maritime Manor Special Care Home', '299 GOLDEN GROVE ROAD', 'Crystal Powell', 'kathleen11251@gmail.com', '15066474087', NULL, NULL, 'E2H 2V5', '1-20', 'Level-2', 'Sobeys East Point', NULL, 56, '1651935092-162768774b3149.jpg', '1606332039-15fbeae8731084.jpg', '1606332039-15fbeae8732431.jpg', '1606332039-15fbeae873352b.jpg', '1606332039-15fbeae8734465.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 9, 1, 0, 'We are a level 2 special care home. We strive on making our clients feel like they are at home in our small 9 bed facility, with a cozy home like feeling. We have qualified staff and 15plus years experience in geriatric care.', NULL, NULL, NULL, NULL, '2020-11-25 19:20:39', '2022-05-07 00:49:20'),
(70, 'Carlisle Special Care Home', '173 Carlisle Road, Douglas E3G 7M7', 'Susan VanWart', 'susanmvanwart@gmail.com', '450-3957', '506-206-1287', NULL, 'E3G 7M7', '1-20', 'Level-2', 'Keswick Pharmacy', NULL, 57, '1606503519-15fc14c5f3e909.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'm', NULL, NULL, NULL, NULL, '2020-11-27 18:58:39', '2021-04-03 00:33:36'),
(72, 'Grass Home Ltd', '774 Coverdale Rd', 'Lynn Grass', 'jgrass1213@rogers.com', '506-386-1740', '506-386-7040', NULL, 'E1B 3L5', '21-40', 'Level-3G', 'Ford\'s Jean Coutu', 'We have 6 level 2 and 18 level 3G beds at this home', 59, '1606508787-15fc160f3bb8c5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 24, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-27 20:26:27', '2021-04-21 03:36:15'),
(74, 'Charlene’s Special Care Home', '44 Boucher St., Campbellton, NB E3N 2P4', 'Charlene Noye', 'charlenenoye@outlook.com', '5067592773', NULL, NULL, 'E3N 2P4', '1-20', 'Level-2', 'Different Pharmacies', NULL, 61, '1608529851-15fe037bb0bde6.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Restigouche', 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, '.', NULL, NULL, NULL, NULL, '2020-11-27 23:10:32', '2021-04-03 00:36:23'),
(75, 'West Side Manor', '646 George Street', 'Lisa Melanson', 'jklm2k2@hotmail.com', '506-672-1534', NULL, NULL, 'E2M3T3', '1-20', 'Level-2', 'Lawtons Catherwood', NULL, 62, '1606520126-15fc18d3e88b1a.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-27 23:35:26', '2021-04-02 21:38:32'),
(76, '3 Brooks Villa', '2587 Rte109 Three Brooks , N.B.', 'Kelly Briggs', 'Kellybriggs12@live.ca', '506-356-8327', '506-356-2319', NULL, 'E7G2W6', '1-20', 'Level-2', 'Superstore pharmacy', NULL, 63, '1606523161-15fc19919c0890.png', '1606523161-15fc19919c23dd.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 2, 19, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-28 00:26:01', '2021-06-23 21:57:56'),
(77, 'Elizabeth House Special Care Home Inc.', '178 Bridge Street Saint John', 'Amy Cook', 'rideout_amy@hotmail.com', '5066426058', NULL, NULL, 'E2K 1S5', '1-20', 'Level-2', 'Jean Coutu', NULL, 64, '1606576583-15fc269c79bd85.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-28 15:16:23', '2021-04-03 00:33:48'),
(78, 'McGrath Special Care Home', '267 Rockland Road', 'Lori McGrath', 'lorrainelynnmc@gmail.com', '5066523083', NULL, NULL, 'E2K3K3', '1-20', 'Level-2', 'Lawton\'s', NULL, 65, '1606576625-15fc269f1acbf8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Saint John', 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 10, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-28 15:17:05', '2021-05-03 18:19:05'),
(79, 'McLay’s Oak Bay Haven Inc', '12 Giddens lane Oak Bay NB', 'Steve McLay', 'mclaysbayhaven@gmail.com', '5064666611', '5064662533', NULL, 'E3L 4K2', '1-20', 'Level-2', 'Gaurdian Drug', NULL, 66, '1606580213-15fc277f562f8b.jpeg', '1606580213-15fc277f56437f.jpeg', '1606580213-15fc277f5658ea.jpeg', '1606580213-15fc277f566a8d.jpeg', '1606580213-15fc277f56753e.jpeg', NULL, 'https://m.facebook.com/mclaysoakbayhaven/', NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-28 16:16:53', '2021-04-02 22:27:49'),
(81, 'Residence O Bons Soins', '330 Rue Pascal-Poirier, Shediac, NB E4P 2K9', 'Collette Doucette', 'collette.obs@rogers.com', '(506) 312-3301', '(506) 532-5459', NULL, 'E4P 2K9', '60+', 'Level-2', 'Jean-Coutu', 'N/A', 68, '1606637213-15fc3569db5a9b.jpg', '1606637213-15fc3569dbfc67.jpg', '1606637213-15fc3569dbfd45.jpg', '1606637213-15fc3569dbfdda.jpg', '1619046636-16080b0ec5fb70.jpg', '1619046636-16080b0ec6009b.jpg', NULL, NULL, NULL, NULL, NULL, 'https://www.shediacseniors.com/', 1, 'Seniors,Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 98, 1, 0, 'Residence O Bons Soins is located in the beautiful Shediac NB area and we are always available to talk with you about our facility and your needs.\r\n\r\nWe have 98 License subsidies beds and 33 Private independent beds\r\n\r\nCall Collette anytime at 506-312-3301to include your name on a waiting list.', NULL, NULL, NULL, NULL, '2020-11-29 08:06:53', '2021-06-15 20:45:57'),
(83, 'Southern Comfort Villa', '1394 King Avenue, Bathurst, NB E2A 1S8', 'Lillian Drapeau', 'drapeaulillian14@gmail.com', '15063509000', '15063508000', NULL, 'E2A1S8', '41-60', 'Level-2', 'Jean Coutu', 'Currently adding additional 30 beds,', 69, '1606695966-15fc43c1e89fc6.jpg', '1606695966-15fc43c1e8b1f5.JPG', '1606695966-15fc43c1e8b8e2.jpg', '1606695966-15fc43c1e8b9eb.JPG', '1606695966-15fc43c1e8c881.JPG', '1606695966-15fc43c1e8d2f2.JPG', 'Southern Comfort Villa', NULL, NULL, NULL, NULL, 'southerncomfortvilla.com', 1, 'Seniors,Intellectual and Developmental', 'Chaleur', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 60, 1, 0, 's', NULL, NULL, NULL, NULL, '2020-11-30 00:26:06', '2021-06-18 02:27:07'),
(84, 'Emery House', '88 Emery St', 'Jeff Hunter', 'jefhunter@rogers.com', '5063874518', '5063877854', NULL, 'E1B 1B1', '1-20', 'Level-2', 'Medicine Shoppe (West Main)', NULL, 70, '1606740800-15fc4eb40b58fb.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 9, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-11-30 12:53:20', '2021-06-23 23:23:41'),
(85, 'Scenic View Special Care Home', '3481 Eoute 121', 'Mercy Burge', 'ilovemyjobcanada@gmail.com', '15064334538', '15067991881', NULL, 'E5P 1B2', '1-20', 'Level-2', 'Lawtons', 'All ladies', 71, '1606781238-15fc58936ee80d.jpg', NULL, NULL, NULL, NULL, NULL, '@scenicViewCares', NULL, NULL, NULL, NULL, 'www.scenicviewcares.com', 1, 'Seniors', 'Saint John', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-12-01 00:07:19', '2020-12-04 23:28:32'),
(86, 'Résidence Ti Bons Soins', '60 Rue Gallagher, Shediac, NB E4P 1S5', 'Nicole Leblanc', 'tibonssoins@rogers.com', '351-0478', '351-0498', NULL, 'E4P 1S5', '1-20', 'Level-3B', 'Lawtons Drugstore', NULL, 73, '1607104709-15fca78c5d0342.jpeg', '1607104709-15fca78c5d0fb7.jpeg', '1607104709-15fca78c5d1b63.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'm', NULL, NULL, NULL, NULL, '2020-12-04 17:58:29', '2020-12-04 23:28:59'),
(87, 'Ruth Sawler', '37  CLARK STREET, HARTLAND, NB, E7P 1L3', 'Ruth Sawler', 'ruan@nbnet.nb.ca', '5063759193', '506-375-9193', NULL, 'E7P 1L3', '1-20', 'Level-2', 'Nevers & Pharmacy for Life', NULL, 74, '1607180137-15fcb9f693e6a8.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'g', NULL, NULL, NULL, NULL, '2020-12-05 14:55:37', '2021-04-03 00:34:53'),
(88, 'Topaz Special care home', '219 route 124 Norton NB', 'Tammy Long', 'tammylong@hotmail.com', '5068392715', '5065700062', NULL, 'E5T1B7', '1-20', 'Level-2', 'Lawtons', NULL, 75, '1607475454-15fd020fe2793a.jpeg', '1607475454-15fd020fe2e595.jpeg', '1607475454-15fd020fe2f700.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 10, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-12-09 00:57:34', '2021-05-25 06:27:25'),
(89, 'Trueman House', '265-267 Church Street Moncton NB', 'Cary MacDonald', 'carymac63@gmail.com', '506-389-3138', NULL, NULL, 'e1c-5a7', '1-20', 'Level-2', 'Lawtons long term', NULL, 76, '1607532278-15fd0fef6ec79e.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-12-09 16:44:39', '2021-01-12 22:53:21'),
(92, 'Serenacare', '15 Lady Russell St, Moncton, NB E1G 2E9', 'Susan Dixson', 'serenacare@bellaliant.com', '5063811550', '5062049156', NULL, 'E1E 0C3', '1-20', 'Level-3G', 'Lawton\'s', 'N/A', 78, '1628788136-1611555a883db4.JPG', '1628788136-1611555a88b33a.JPG', '1628788136-1611555a88fcab.JPG', '1628788136-1611555a893fdd.jpg', '1628788136-1611555a896c82.jpg', '1628788136-1611555a8995d9.jpg', NULL, NULL, NULL, NULL, NULL, 'www.serenacare.ca', 1, 'Seniors', 'Moncton', 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'N/A', NULL, NULL, NULL, NULL, '2020-12-13 17:44:37', '2021-05-14 08:44:56'),
(95, 'Burns Manor', '26 Bromley Ave', 'Mike Sewell', 'jenburnsmanor@gmail.com', '(506)852-3554', NULL, NULL, 'E1C5T9', '1-20', 'Level-2', 'Atlantic Superstore Trinity', 'We deal with Mental Health and Intellectual and Developmental Disabilities', 81, '1608221857-15fdb84a10500a.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-12-17 16:17:37', '2021-04-03 00:34:58'),
(97, 'Green Meadows Special Care Home - Millstream', '374 Route 880', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-433-2502', '506-808-0028', NULL, 'E5P3K4', '1-20', 'Level-2', 'Lawton\'s', NULL, 85, '1642077155-161e01be33b426.jpeg', '1642077155-161e01be3403ff.JPG', '1642077155-161e01be3472ec.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Saint John', 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'When it comes to mental health, our Lower Millstream location is committed to providing lasting care to the people you love.', NULL, NULL, NULL, NULL, '2021-01-08 17:38:19', '2021-01-12 22:54:20'),
(98, 'Green Meadows Special Care Home - Berwick', '1063 Route 880', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-433-1364', '506-808-0028', NULL, 'E5P3A9', '1-20', 'Level-2', 'Lawton\'s', NULL, 212, '1642077238-161e01c36d058c.jpeg', '1642077238-161e01c36d0de8.JPG', '1642077238-161e01c36d8f58.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Relaxing country living close to town. Berwick offers our residents raised garden beds, a pond to relax by and the efficiency of being close to town.', NULL, NULL, NULL, NULL, '2021-01-08 17:38:19', '2021-01-12 22:54:23'),
(99, 'Green Meadows Special Care Home - Belleisle', '1199 East Scotch Settlement Road', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-485-5890', '506-808-0028', NULL, 'E5P1N7', '1-20', 'Level-2', 'Lawton\'s', NULL, 213, '1642077560-161e01d782d0e9.jpeg', '1642077560-161e01d782da61.JPG', '1642077560-161e01d78327fd.JPG', '1642077560-161e01d7837fbe.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 'Scenic and spacious, Belleisle is a beautiful place to call home. With large rooms, a gazebo and front garden, Belleisle has much to offer you or your loved ones.', NULL, NULL, NULL, NULL, '2021-01-08 17:38:19', '2021-04-22 22:29:23'),
(100, 'The Briarlea on Ryan 3G', '599 Ryan St., Moncton, NB E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, NULL, 'E1G 2W2', '21-40', 'Level-3G', 'Jean Coutu / Medicine Shoppe', 'The Briarlea offers progressive care levels out of two homes; both homes are owned by Dr. Pierre Beaulieu and Sean Doucet. The Briarlea off Gorge offers 8 assisted-living apartments, 24 level 2 care rooms, 12 level 3B rooms, and Palliative care services.   The Briarlea on Ryan offers 10 level 2 rooms, 6 level 3B rooms, 18 level 3G rooms, and Palliative care services.  Our compassionate team of highly skill individuals include an LPN, Certified Chefs, an Activity Coordinator, Resident Care Managers and more; our team supports amazing Personal Support Workers, who tend to your loved ones daily task of living, while ensuring the best possible quality of life.', 86, '1610978245-1600593c56e200.jpg', '1623424648-160c37e88c877c.jpg', '1623424648-160c37e88caab0.jpg', '1623424648-160c37e88cc73c.jpg', '1623424648-160c37e88cdb52.jpg', '1623424648-160c37e88ced49.jpg', 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 1, 'Seniors', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', NULL, NULL, NULL, NULL, '2021-01-18 13:57:25', '2021-04-02 00:44:03'),
(101, 'Victory House', '30 Victory Ave', 'Jody Munn', 'jodymunnster@gmail.com', '506-260-3354', NULL, NULL, 'E3A 3V5', '1-20', 'Level-2', 'Medicine Shoppe', 'na', 87, '1611421173-1600c55f534d73.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Fredericton', 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 7, 1, 0, 'N/A', NULL, NULL, NULL, NULL, '2021-01-23 16:59:33', '2021-06-15 23:45:19'),
(102, 'Goguen Residence 678780 NB INC.', '76 John st, Moncton NB,', 'Colleen Paynter', 'colleenpaynter@hotmail.com', '506 855-3549', '506 855-7257', NULL, 'E1C 2G9', '1-20', 'Level-4', 'Lawtons', '-', 88, '1612981401-1602424992f0ab.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental', 'Moncton', 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, '-', NULL, NULL, NULL, NULL, '2021-02-10 18:23:21', '2021-11-17 01:01:37'),
(103, 'Goguen Residence 621090NB INC', '15 Norwood Ave', 'Star Whalen', 'starwhalen76@hotmail.com', '506 381-4841', '506 3887964', NULL, 'E1C 6L7', '1-20', 'Level-4', 'Lawtons', '-', 208, '1612981401-16024249938c2b.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental', 'Moncton', 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, '-', NULL, NULL, NULL, NULL, '2021-02-10 18:23:21', '2021-10-26 13:40:04'),
(104, 'Goguen Residence Inc', '34 Bromley Ave', 'Colleen Paynter', 'colleen@goguenresidences.ca', '506 204-8448', '506 389-8139', NULL, 'E1C 5T9', '1-20', 'Level-4', 'Lawtons', '-', 209, '1612981401-1602424993afd5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental', 'Moncton', 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, '-', NULL, NULL, NULL, NULL, '2021-02-10 18:23:21', '2021-12-13 18:28:04'),
(119, 'Laura Manor Special Care Home', '86 Mecklenburg street, Saint John, NB E2L 1R3', 'Danielle Gallant', 'lauramanor86@gmail.com', '5066508706', NULL, NULL, 'E2L 1R3', '1-20', 'Level-2', 'Lawtons Pharmacy Catherwood', 'n/a', 101, '1617302396-16066137c562d9.jpeg', '1622040670-160ae605e7cb07.jpeg', '1622040670-160ae605e7dcb6.jpeg', '1622040670-160ae605e7ecc6.jpeg', '1622040670-160ae605e7ff3d.jpeg', '1622040670-160ae605e803e2.jpg', 'https://www.facebook.com/search/top?q=Laura%20Manor%20Care%20Home', NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Saint John', 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 16, 1, 0, 'Laura Manor Special Care Home has been operating since 1992. Located in the heart of uptown Saint John. On bus route, walking distance to Key Industries, Mental Health Recovery services on Duke street and Mercantile. We accommodate your needs!', NULL, NULL, NULL, NULL, '2021-04-01 18:39:56', '2021-06-15 22:37:35'),
(120, 'Seely Lodge', '3277 Westfield, Saint John, NB E2M 7B5', 'Jan Seely', 'janseely@rogers.com', '506-639-4478', '506-217-1700', NULL, 'E2M7B5', '1-20', 'Level-2', 'Lawtons Catherwood st. Saint John', 'N/A', 29, '1617303527-1606617e76d231.jpeg', '1617303527-1606617e76ed98.jpeg', '1650200112-1625c0e30e8771.jpg', '1650200112-1625c0e30ea612.jpg', '1650200112-1625c0e30ebf6b.jpg', '1650200112-1625c0e30ed97f.jpg', 'https://www.facebook.com/seely.lodge.9', NULL, NULL, NULL, NULL, 'www.murraystseelylodgesch.com', 1, 'Seniors,Mental Health,Blended Facility', 'Saint John', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 12, 1, 0, 'Welcome to Seely Lodge Special Care Home, where your comfort and well-being are our number one priority.   For over 25 years we have remained dedicated to providing the highest level of care possible for our residents.    Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help!\r\n\r\nDescription of Services: \r\n\r\nOur home is located in Martinon, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices.\r\nWe provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc.\r\n\r\nProgramming:\r\n\r\nResidents are encouraged to be active and stay involved in community programs and events. We also employ a recreation director and utilize dedicated volunteers to enhance our weekly activities.  Eligible residents also attend weekly Outreach program offered by Loch Lomond Villa and we provide transportation to and from. \r\n\r\nLevel of Care:\r\n\r\nOur areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. \r\n\r\nWe are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies.\r\n\r\nCredentials:\r\n\r\nJan Seely has owned and operated this home for 25 years.  Our home is licensed and inspected, by the Department of Social Development.  Our personnel are fully qualified according to provincial standards and regulations.  We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', NULL, NULL, NULL, NULL, '2021-04-01 18:58:47', '2022-05-03 17:53:22'),
(123, 'Victoria Villa Inc.', '566 East Riverside Dr., Perth-Andover', 'Jennifer Eagan', 'victoriavillainc@outlook.com', '506-273-9394', '506-273-9797', NULL, 'E7H 1Z4', '21-40', 'Level-2', 'Johnson\'s Guardian', 'N/A', 33, '1617623143-1606af86734e41.jpg', '1621246016-160a24040d8d0f.JPG', '1621246016-160a24040db562.JPG', '1621246016-160a24040ddccd.JPG', '1621246016-160a24040e051a.JPG', '1621246016-160a24040e2faf.JPG', 'https://www.facebook.com/Victoria-Villa-Inc-Special-Care-Home-187805967969814', NULL, NULL, NULL, NULL, 'www.victoriavilla.ca', 1, 'Seniors', 'Fredericton', 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 24, 1, 0, 'N/A', NULL, NULL, NULL, NULL, '2021-04-05 11:45:43', '2022-03-11 20:04:53'),
(126, 'Waddell Residence/hobby farm', '1077 Route 845 , Kingston, NB E5N 1K7', 'Ann Waddell', 'waddell@levesqueonline.com', '(506) 763-2257', '506-763-2257', NULL, 'E5N 1K7', '1-20', 'Level-2', 'Sobeys Rothesay', 'N/A', 111, '1617903094-1606f3df6e9f61.jpg', '1617795369-1606d99298a8ff.jpg', '1619049000-16080ba28bbfa4.jpg', '1619049000-16080ba28bca34.jpg', '1619049000-16080ba28bdbe9.JPG', '1619049000-16080ba28be4ce.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Saint John', 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Waddell Residence is situated on the Kingston Peninsula. Just off the Gondola Point Ferry turn right and 1 ½ km’s.\r\nIt is also a hobby farm. We have alpaca’s, goats, sheep, rabbits, chickens cats and dogs the residents help with the care and help look after the yard also..\r\n\r\nIt is close to a local store, school and churches.  Also 5 minutes to Quispamsis. Our clients are accepted by our small community. \r\nWe are registered for 6 clients, everyone has their own room, TV and loads of movies.  Home made meals of course.  I also take them to their appointments and their shopping.', NULL, NULL, NULL, NULL, '2021-04-07 11:36:09', '2021-04-14 16:07:56'),
(130, 'Living Hope Special Care Home', '467 Picadilly Road, Piccadilly, Saint John NB E4E 5J7', 'Wilma Ledin', 'buchananwilma@gmail.com', '506 229 2170', '506 432 6322', NULL, 'E4E 5J7', '1-20', 'Level-2', 'Lawtons', NULL, 115, '1618252662-160749376e9f1e.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 8, 1, 0, 'Living Hope Special Care Home an 8 bed facility located in beautiful Picadilly NB, just 10 minutes outside of Sussex. We strive to be a home where residents want to live and staff choose to work.  We are an 8 bed level 2 care home.   At Living Hope Special Care Home we are committed to providing you and your family with the same care that we would expect for ourselves and our own families.', NULL, NULL, NULL, NULL, '2021-04-12 18:37:42', '2021-05-19 16:45:44');
INSERT INTO `member_homes` (`id`, `spch_name`, `spch_address`, `spch_contact_name`, `spch_email`, `spch_phone`, `spch_fax`, `spch_dept_name`, `spch_postal_code`, `spch_num_bed`, `spch_level_care`, `spch_pharmacy_name`, `spch_notes`, `spch_member_id`, `photo_url`, `photo_url_two`, `photo_url_three`, `photo_url_four`, `photo_url_five`, `photo_url_six`, `fb_url`, `inst_url`, `twi_url`, `youtube_url`, `linkdin_url`, `website_url`, `status`, `spch_facility`, `region`, `charge_above_government`, `provide_transport`, `allow_pet`, `allow_furniture`, `comfort_clothing_money`, `transport_medical_appointment`, `home_hairdressing`, `have_foot_care`, `staf_diabetes_insulin_train`, `staf_oxygen_thrapy_train`, `staf_colostomy_care_train`, `staf_wound_care_train`, `staf_dementia_care_train`, `accept_incontinent_urine`, `monitoring_sys_door`, `accept_mrsa_positve_client`, `have_experience_client_suffering_addictions`, `client_keep_physicians`, `have_practitioner_doc_nurse`, `relationship_extra_menual_nursing`, `client_extra_mural_care`, `provide_adaptive_equipment`, `how_to_acquire`, `provide_house_excursions`, `resident_outreach_attend_program`, `resident_work_community`, `staf_medication_administartion_traing`, `accommodate_special_diet`, `accessible_shower_wheelchair_person`, `have_outdoor_area`, `specific_visting_hour`, `provide_reference_existing_client`, `accept_resident_incontinent`, `administering_medication_training_required`, `free_vacancy`, `num_open_beds`, `is_free_vocancy`, `is_new`, `public_description`, `open_day`, `close_day`, `open_time`, `close_time`, `created_at`, `updated_at`) VALUES
(131, 'Murray Street Lodge', '35 Murray Street, Grand Bay-Westfield, NB E1C5C7', 'Heather Perrin', 'hseely86@hotmail.com', '5067383500', '5062171700', NULL, 'E1C5C7', '1-20', 'Level-2', 'Lawtons', NULL, 116, '1618377533-160767b3d7fcf1.JPG', '1618377533-160767b3d835cf.JPG', '1618377533-160767b3d84004.JPG', '1618377533-160767b3d84a3a.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'www.murraystseelylodgesch.com', 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Saint John', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 13, 1, 0, 'Welcome to Murray Street Lodge Special Care Home, where your comfort and well-being are our number one priority. For over 10 years we have remained dedicated to providing the highest level of care possible for our residents. Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help! Description of Services: Our home is located in Grand Bay-Westfield, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices. We provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc. Programming: Residents are encouraged to be active and stay involved in community programs and events.We utilize dedicated volunteers to enhance our weekly activities. Level of Care: Our areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. We are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies. Credentials: Heather Perrin has operated this home for 10 years. Our home is licensed and inspected, by the Department of Social Development. Our personnel are fully qualified according to provincial standards and regulations. We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', NULL, NULL, NULL, NULL, '2021-04-14 05:18:53', '2021-07-01 06:44:00'),
(132, 'ProTem Memory Care', '71 Gorge Rd, Moncton, NB E1G 1E5', 'Danielle DeAgazio', 'info@protem.ca', '506-874-9652', '506-854-3519', NULL, 'E1G 1E5', '41-60', 'Level-3B', 'Guardian', NULL, 58, '1618583937-16079a1815f5c0.JPG', '1618583937-16079a18163b87.JPG', '1618583937-16079a1816703a.JPG', '1618583937-16079a1816c036.jpg', '1618583937-16079a1816ea1f.jpg', '1618948551-1607f31c793945.jpg', 'https://www.facebook.com/ProTemMemoryCare', 'https://www.instagram.com/protemmemorycare/', NULL, NULL, NULL, 'www.protem.ca', 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 50, 1, 0, 'ProTem Memory Care provides care exclusively to those who are living with a dementia diagnosis (3B).\r\nOur community is made up of 5 small homes that include a secured backyard area with gardens and walking paths. To the best of our ability we schedule the same care team in the same home with no more than 10 residents. We want our residents to build a meaningful and trusting relationship with those who are caring for them. There is 1 caregiver for every 3 residents. Our structural layout, customized care packages, daily activities, and trained team members is how ProTem offers true resident centred care to our residents and their families.', NULL, NULL, NULL, NULL, '2021-04-15 20:09:55', '2021-08-25 00:31:21'),
(133, 'METCALF MANOR', '133 Metcalf Street, Saint John, NB E2K 1K2', 'VANESSA HARRIS OR BRYAN GALLANT', 'metcalfmanor1@gmail.com', '15062141690', NULL, NULL, 'e2k1k2', '1-20', 'Level-2', 'SOBEY\'S NORTH', NULL, 117, '1618842658-1607d94222ac9d.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 6, 1, 0, 'WE ARE HERE TO HELP THOSE WHO NEED DIRECTION WITH LIFE SKILLS, MEDICATION REMINDERS, ASSISTING WITH PERSONAL CARE, ORGANIZING AND GETTING TO APPOINTMENTS, MEALS AND COMPANIONSHIP.', NULL, NULL, NULL, NULL, '2021-04-19 14:30:58', '2022-01-14 06:43:03'),
(134, 'The Cedars', '28 Milton Lane, Sackville, NB E4L3B7', 'Julie Steeves', 'thecedarsarf@gmail.com', '506-939-2233', '506-939-2233', NULL, 'E4L3B7', '1-20', 'Level-2', 'Lawtons', NULL, 118, '1619017751-160804017c89fe.jpg', '1619017751-160804017cb094.jpg', '1621758095-160aa108f50d42.jpg', '1619017751-160804017cbf2b.jpg', NULL, '1619017751-160804017cc15f.jpg', 'https://www.facebook.com/thecedarsarf/', 'https://instagram.com/thecedarsarf?igshid=1cfdu2yj2dspk', NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 10, 1, 0, 'In floor heating, home cooked meals, country living on a large 2 acres secluded property within walking distance to all major restaurants, sprinkler and alarm system for safety, ongoing update for your comfort and convenience and last but definitely not least, staff that really care. Private and semi-private rooms, please contact us for availability!', NULL, NULL, NULL, NULL, '2021-04-21 15:09:11', '2021-04-21 20:11:56'),
(135, 'Bartlett Gardens Care Home', '15  Craig St', 'Wendy Symonds', 'bartlettgardenscarehome@gmail.com', '9026644089', NULL, NULL, 'E3A6S9', '1-20', 'Level-2', 'St. Mary’s', 'persons needs a description in public notes', 119, '1619037381-160808cc598df6.jpeg', '1619037381-160808cc598fab.jpeg', '1619037381-160808cc599122.jpeg', '1619037381-160808cc5992af.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 8, 1, 0, 'Bartlett Gardens Care Home welcomes you to contact the home.', NULL, NULL, NULL, NULL, '2021-04-21 20:36:21', '2021-08-08 03:50:09'),
(136, 'Coultons Special Care Home', '251Loch Lomond Rd.', 'Marion MacDougall', 'coultonsspecialcarehome@live.com', '(506)214-1664', '(506)214-0142', NULL, 'E2J1Y6', '1-20', 'Level-2', 'Sandra Ferris', 'na', 120, '1619041331-160809c33ee75f.jpeg', '1619041331-160809c33eeaae.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health', 'Saint John', 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 2, 14, 1, 0, 'We currently have 2 beds available (ladies only)', NULL, NULL, NULL, NULL, '2021-04-21 21:42:11', '2021-09-11 00:29:37'),
(138, 'Twin Towers Special Care Home', '7 Elm Street, St Stephen, NB E3L 2S2', 'Tom Knox', 'knoxtom@rocketmail.com', '5064675117', NULL, NULL, 'E3L2S2', '1-20', 'Level-2', 'Lawtons', NULL, 121, '1619123637-16081ddb57572f.png', '1619123637-16081ddb57685f.jpeg', '1619123637-16081ddb577020.jpeg', '1619123637-16081ddb579593.jpeg', '1619123637-16081ddb57b88c.jpeg', '1619123637-16081ddb57beab.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 3, 9, 1, 0, '.', NULL, NULL, NULL, NULL, '2021-04-22 20:33:57', '2021-06-15 21:37:09'),
(139, 'NORTH MINTO RESIDENCE', '781 Northside Drive, Minto, NB E4B 3C7', 'PAULA FASQUEL', 'mail@northmintoresidence.ca', '506-327-9000', '506-327-3000', NULL, 'E4B 3C7', '1-20', 'Level-3B', 'Lawtons', 'Owner/Operator Marie Petitpas      Operations Manager Paula Fasquel', 122, '1621943188-160ace394659e1.jpg', '1620155420-160919c1c6f582.jpeg', '1620155420-160919c1c71ed9.jpeg', '1620155420-160919c1c7472f.jpeg', '1620155420-160919c1c776b5.jpeg', '1620155420-160919c1cc9a5e.jpeg', NULL, NULL, NULL, NULL, NULL, 'www.northmintoresidence.ca', 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 3, 18, 1, 0, 'Long Term Care Assisted Living providing  care to Level 2 and Memory Care (3B) Clients. \r\nThe Residence is equipped with an elevator / six foot wide hallways adequate to accommodate wheelchairs and walkers \r\nPrivate and Semi Private rooms with washrooms and grab bars\r\nWhirl Pool Tub, large common area with comfortable chairs, TV and telephone access\r\nWheel Chair Ramps and pull cord alarm system \r\nHallways and common areas are equipped with security cameras\r\nEntry/Exit doors are equipped with door alarms leading to a secure court yard with gazebo and walking pathway \r\n\r\nServices offered: Bilingual  24 hour Supervised Care / Medication Dispensing / Health Clinics / Individualized Personal Care Plan / Health Records / Hygiene and Personal Care / Home Cooked Nutritional Meals / Relief Care / Daily Laundry Service / Daily Housekeeping Services / Medical Transportation  / Hair Care / Foot Care / Pastoral Care / Social Activities / Outings / Newspaper / Mail Delivery', NULL, NULL, NULL, NULL, '2021-04-22 20:34:40', '2021-05-04 21:56:40'),
(140, 'Primrose Cottage Special Care Home', '418 Route 880 Lower Millstream, Sussex NB E5P 3K4', 'Lynn Wallace', 'lpearle@hotmail.com', '5064341869', NULL, NULL, 'e5p3k4', '1-20', 'Level-2', 'Lawton\'s Sussex', 'N.a', 123, '1626376784-160f08a5056670.jpg', '1626376784-160f08a5058127.JPG', '1626376784-160f08a505a5a9.jpg', '1626376784-160f08a505f047.jpg', '1626376784-160f08a5062409.jpg', '1626376784-160f08a5065570.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'We provide holistic care to level 2 residents in a home-like setting. We excel in the care of the frail elderly, dementia care, and in end-of-life/palliative care. We also provide care to those with mental health needs. Residents and staff follow direction and guidance from owner and operator, Lynn Wallace, a registered of 40 years. We frequently receive residents post-hospitalization and are successful in rehabilitation. A variety of activities and services are offered, such as hair salon services, foot care services, art therapy, physical activity programming, animal therapy and so much more.', NULL, NULL, NULL, NULL, '2021-04-25 19:23:43', '2021-05-14 08:45:51'),
(152, 'Countryside residence', '74 W Main St, Port Elgin, Moncton NB E4M 1M1', 'Crystal Lynn snowdon', 'crystallynnsnowdon1973@gmail.com', '5065382968', '538-2512', NULL, 'E4m1m1', '1-20', 'Level-2', 'Village guardian', 'A beautiful country setting', 134, '1619897268-1608dabb41b506.jpeg', NULL, NULL, NULL, NULL, NULL, 'Countryside residence', NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental', 'Moncton', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'Our 10 bed cozy atmosphere level 2 home is in a country setting with all private rooms , home cooked meals and hairdresser and doctor visits , nurse on staff , music and entertainment weekly bingo nights , a place to call home .', NULL, NULL, NULL, NULL, '2021-05-01 19:27:48', '2021-05-03 19:40:24'),
(155, 'Manor St. Jude care home', '416 Sandy point Road, Saint John, NB E2K 3R9', 'Steven', 'stevenwen@yahoo.com', '5069775188', NULL, NULL, 'E2K 3R9', '1-20', 'Level-2', 'Lawtons', 'We provide transportation to and from medical visits every Tuesday and Thursday.', 138, '1620055020-1609013eca8220.jpg', '1620055020-1609013eca8367.jpg', '1620055020-1609013eca8440.jpg', '1620055020-1609013eca8531.jpg', '1620055020-1609013eca8654.jpg', '1620055020-1609013eca8771.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Saint John', 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 2, 8, 1, 0, 'High reputation Licensed special care home . We provide 24 hours quality long / short term care for individuals with special needs or seniors, in a homey atmosphere with home cooked meals (4 meals a day). Medication reminded and delivery on time. All rooms are on one floor, Wheelchair accessible, private, quiet and spacious. Free laundry service and parking lots, close to bus stop, Location near by Hazen White-St. Francis School.  Welcome visit Manor St. Jude Care Home. 5066321888', NULL, NULL, NULL, NULL, '2021-05-03 15:17:00', '2021-06-05 17:17:10'),
(157, 'Country Lane Estates NB Inc', '21 Christopher Dr, Burton, NB E2V 3H4', 'Angela Cahill', 'countrylaneestatesinc@gmail.com', '357-2459', NULL, NULL, 'E2V 3H4', '1-20', 'Level-2', 'King Street Medicine Shoppe', 'Please contact us if you have any questions.', 206, '1620175648-16091eb20066f1.jpg', '1620175648-16091eb20068da.jpg', '1620175648-16091eb2006a64.jpg', '1620175648-16091eb2006c05.jpg', '1620175648-16091eb2006daa.jpg', '1620175648-16091eb2006f26.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Fredericton', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 2, 11, 1, 0, 'We are a level 2 home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', NULL, NULL, NULL, NULL, '2021-05-05 00:47:28', '2021-05-05 13:59:09'),
(158, 'Country Lane Estates NB Inc', '21 Christopher Dr, Burton, NB E2V 3H4', 'Angela Cahill', 'countrylaneestatesinc@gmail.com', '357-2459', NULL, NULL, 'E2V 3H4', '1-20', 'Level-3B', 'King Street Medicine Shoppe', 'We hope to hear from you.', 207, '1620176266-16091ed8a33391.jpg', '1620176266-16091ed8a33592.jpg', '1620176266-16091ed8a3371e.jpg', '1620176266-16091ed8a3387c.jpg', '1620176266-16091ed8a339da.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Fredericton', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 2, 7, 1, 0, 'We are a level 3B home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', NULL, NULL, NULL, NULL, '2021-05-05 00:57:46', '2021-05-05 13:59:21'),
(159, 'The Guardians Special Care Home Ltd.', '203 MacFarlane Street, Fredericton, NB E3A 1V7', 'Leonard Gervais', 'parkviewgardens203@outlook.com', '506-458-8968', '458-0918', NULL, 'E3A 1V7', '1-20', 'Level-2', 'Sobeys Brookside Pharmacy', 'Danielle get this done -Len', 140, '1620233216-16092cc0081b12.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health,Intellectual and Developmental', 'Fredericton', 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'The Guardians Special Care Home is a licensed level 2 special care home located on the Northside of Fredericton. The facility built in 2008-2009 has been in operation since August 2009, and is locally owned and operated. The Guardians strives to provide an enriched, healthy living experience for their residents. Nestled into Nashwaaksis The Guardians is close to many amenities including shopping malls, restaurants, bus stops, outreach programs, & convenience stores; greatly improving the opportunity for employment placements for those seeking work.  The residents enjoy the outdoor on-site pool during the summer months, are encouraged to join and participate in all activities be it singing, swimming, dancing, board/card games, karaoke, cooking, light chores, and many different Special Olympics sports & activities to name a few.  The home has a large communal living space with couches, chairs, & puzzle boards. A large Tv entertains the game show watchers by day and sport enthusiast by night. Directly beside the large open concept kitchen lies a large dining room to accommodate everyone during meal times. All staff are certified, friendly, humble, & keep the residents needs the priority.', NULL, NULL, NULL, NULL, '2021-05-05 16:46:56', '2021-05-06 18:18:49'),
(164, 'Canterbury Hall', '824 Coverdale Road, Riverview, NB E1B 0H9', 'Alison Baxter', 'abaxter@shannex.com', '5063870533', '506-387-7707', NULL, 'E1B 0H9', '41-60', 'Level-2', 'Lawton\'s Drug', 'for all inquiries please contact Alison', 144, '1620820304-1609bc150e2ca4.jpg', '1620820304-1609bc150e3fd0.jpg', '1620820304-1609bc150e4d04.jpg', '1620820304-1609bc150e582b.jpg', '1620820304-1609bc150e73a2.jpg', '1620820304-1609bc150e93ad.jpg', 'https://www.facebook.com/experienceparkland', NULL, NULL, 'https://www.youtube.com/ExperienceParkland', NULL, NULL, 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Canterbury Hall is a licensed special care home located on the Parkland Riverview Campus. We provide care for those individuals requiring level 2 care. All the units are private sleeping units with the majority of the apartments having full private washrooms with full walk-in showers with seats. A small fridge (with freezer) is provided as well as local phone, cable and internet.  We also have our own emergency pendent system. There is a dining room, living room and nurses station on each floor, so everything a resident needs is on the floor in which they reside. There are outside sitting areas, paved walking trail as well as a gazebo and fish pond, with a water fall,  to enjoy', NULL, NULL, NULL, NULL, '2021-05-12 11:51:44', '2021-09-20 22:43:19'),
(165, 'Enhanced Living Gagetown', '142 Tilley Road. Gagetown NB', 'Erynn Bailey', 'erynn@enhancedliving.ca', '506-422-8600 ext 5', '506-488-2620', NULL, 'E5M1H6', '21-40', 'Level-3B', 'Oromocto Riverside Gaurdian', 'Let me know if you need anymore information', 146, '1621356259-160a3eee3c89e9.jpg', '1621356259-160a3eee3c9370.jpg', '1621356259-160a3eee3c9471.jpg', '1621356259-160a3eee3c95ca.jpg', NULL, NULL, 'https://www.facebook.com/groups/enhancedlivinggagetown', 'enhancedlife_nb', '@EnhancedLife_NB', NULL, NULL, 'www.enhancedliving.ca', 1, 'Seniors', 'Fredericton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 27, 1, 0, 'Here at Enhanced Living Gagetown we are a memory care facility with 27 beds. We are located in the Village of Gagetown, surrounded by nature with a large open backyard for residents to enjoy. The lovely thing about being in a small town is that our staff turnover is low and our community involvement is high.', NULL, NULL, NULL, NULL, '2021-05-18 16:44:19', '2021-05-20 01:08:52'),
(166, 'Howe Hall', '50  VITALITY WAY, SAINT JOHN, NB, E2K 0J5', 'Kailey Rasch', 'krasch@shannex.com', '506-649-4713', NULL, NULL, 'E2K 0J5', '21-40', 'Level-2', 'Lawtons Drugs', 'N/A', 155, '1623079980-160be3c2c6b111.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 10, 60, 1, 0, 'Our Assisted Living suites are designed to meet the needs of those with physical or mild cognitive challenges, as well provide an enjoyable lifestyle, courtesy of all of Parkland’s amenities and activities.\r\n•	Three daily meals made to accommodate special dietary preferences\r\n•	Weekly housekeeping, including linen and personal laundry service\r\n•	All utilities, including heat, hot water and electricity\r\n•	Local telephone, cable service and Wi-Fi\r\n•	Chauffeur transportation service\r\n•	Concierge service\r\n•	Outdoor parking\r\n•	Specialized recreation programs and social calendar\r\n•	Individualized personal care plan to support daily living activities\r\n•	Medication management\r\n•	Assistance with personal care\r\n•	Annual home health record update and Personal Wellness Review\r\n•	24-hour monitored, interactive emergency response system with personal pendant included\r\n•	One easy bill per month\r\n•	Spacious, fully accessible suites\r\n•	Kitchenette with fridge\r\n•	In-suite climate control\r\n•	Spacious washrooms with seated walk-in shower\r\n•	Comforting environments:\r\n•	Secure environment with monitored access\r\n•	Team members available 24/7\r\n•	Dining and recreation on the same floor as private suite', NULL, NULL, NULL, NULL, '2021-06-07 15:33:00', '2022-05-20 20:30:41'),
(167, 'The Briarlea on Ryan level 2', '599 Ryan St., Moncton, NB E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, NULL, 'E1G 2W2', '1-20', 'Level-2', 'Jean Coutu /Medicine Shoppe', 'N/A', 195, '1623425805-160c3830d40321.jpg', '1623425805-160c3830d4175c.jpg', '1623425805-160c3830d42aa5.jpg', '1623425805-160c3830d43113.jpg', '1623425805-160c3830d434a9.jpg', '1623425805-160c3830d443cd.jpg', 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', NULL, NULL, NULL, NULL, '2021-06-11 15:36:45', '2021-06-11 19:43:04'),
(168, 'The Briarlea on Ryan 3B', '599 Ryan St., Moncton, NB E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, NULL, 'E1G 2W2', '1-20', 'Level-3B', 'Jean Coutu /Medicine Shoppe', 'n/a', 196, '1623426167-160c38477051fd.jpg', '1623426167-160c3847707da1.jpg', '1623426167-160c3847709c45.jpg', '1623426167-160c384770ad4a.jpg', '1623426167-160c384770b396.jpg', '1623426167-160c384770b6aa.jpg', 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 1, 'Seniors', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', NULL, NULL, NULL, NULL, '2021-06-11 15:42:47', '2021-06-11 19:43:12'),
(169, 'The Briarlea off Gorge Level 2', '75 Briarlea Dr, Moncton, NB E1G 2E9', 'Charline Johnson', 'thebriarlea@gmail.com', '506-857-8866', NULL, NULL, 'E1G 2E9', '21-40', 'Level-2', 'Jean Coutu /Medicine Shoppe', 'na', 197, '1623427068-160c387fc2fc3d.JPG', '1623427068-160c387fc3226d.jpg', '1623427068-160c387fc344fc.jpg', '1623427068-160c387fc366ee.jpg', '1623427068-160c387fc38862.jpg', '1623427068-160c387fc39701.jpg', NULL, NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', NULL, NULL, NULL, NULL, '2021-06-11 15:57:48', '2021-06-11 19:58:08'),
(170, 'The Briarlea off Gorge Level 3B', '75 Briarlea Dr, Moncton, NB E1G 2E9', 'Charline Johnson', 'thebriarlea@gmail.com', '506-857-8866', NULL, NULL, 'E1G 2E9', '1-20', 'Level-3B', 'Jean Coutu /Medicine Shoppe', 'n/a', 198, '1623427367-160c38927a8b38.JPG', '1623427367-160c38927ab2b0.jpg', '1623427367-160c38927ad6e6.jpg', '1623427367-160c38927afabc.jpg', '1623427367-160c38927b0aaa.jpg', '1623427367-160c38927b2400.jpg', 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 1, 'Seniors', 'Moncton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', NULL, NULL, NULL, NULL, '2021-06-11 16:02:47', '2021-06-11 20:03:27'),
(173, 'Swim\'s Adult Residential Facility', '448 White Rd, Avondale, NB E7K 1E5', 'Emily Louise Swim', 'gdswim@xplornet.com', '506-375-6613', '506-375-4609', NULL, 'E7K 1E5', '1-20', 'Level-2', 'The Medicine Shoppe', 'I trust this will be Ok.  Thankyou for all you do!', 159, '1623863317-160ca301521fbe.JPG', '1623863317-160ca301522fc9.JPG', '1623863317-160ca301523809.JPG', '1623863317-160ca30152402b.JPG', '1623863317-160ca301524683.JPG', '1623863317-160ca301524baf.JPG', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Fredericton', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'We strive to meet the individual daily needs of our guests in a secure safe environment.  Their care plans will enable them to have the best quality of living with all due considerations of their strengths and inabilities.  We provide a country living atmosphere with all conveniences within a 8-12 minute drive.', NULL, NULL, NULL, NULL, '2021-06-16 17:08:37', '2021-06-16 21:49:59'),
(174, 'Paradise Villa', '665 Clements Drive, Fredericton, NB E3G 7j2', 'Monique Corbett', 'paradisevilla.cs@gmail.com', '506-443-8000', '506-454-3413', NULL, 'E3G 7J2', '60+', 'Level-3B', 'Lawtons', '60 level 2 beds and 18 level 30B', 216, '1624298666-160d0d4aa2c637.jpg', '1624298666-160d0d4aa31ba4.jpg', '1624298666-160d0d4aa34beb.jpg', '1624298666-160d0d4aa3aa73.jpg', '1624298666-160d0d4aa3d79d.jpg', '1624298666-160d0d4aa4040c.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Fredericton', 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping, churches, bus route, and a short drive to downtown Fredericton. Our new state of the art assisted living Senior Residence Complex truly defines what seniors living should be. Thoughtfully designed and beautifully executed, this well-appointed residence offers 78 single first-class suites, and 4 of the 78 can be converted into suites for couples or siblings. This complex cares for level 2 and 3b residents. This property is very well-managed with experienced and committed staff.', NULL, NULL, NULL, NULL, '2021-06-21 18:04:26', '2021-06-21 22:04:40'),
(175, 'Alvina\'c Care Home', '32 Chamberlain Settlement Road, Moncton NB E2E 6G4', 'Alvina Allain', 'allainalvina@hotmail.com', '(506)548-3229', NULL, NULL, 'E2A 6G4', '1-20', 'Level-2', 'Sobeys', '4 available and 1 vacancy , 25 years of experience , family style care home , bilingual ,', 161, '1624382322-160d21b72bf7ab.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Moncton', 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 4, 1, 0, '25 minutes from St Peters in a beautiful country setting, Family style care, friendly, loving home. Outgoing and activity orientated staff. Family is always welcome.  Bilingual Home with 25 years of experience.', NULL, NULL, NULL, NULL, '2021-06-22 17:18:42', '2021-06-22 22:01:59'),
(176, 'Care A Lot Special Care Home', '61 St Coeur Ct, Saint John, NB E2M 5R3', 'Darlene Forgrave', 'darleneforgrave2007@hotmail.com', '(506) 214-2983', NULL, NULL, 'E2M 5R3', '1-20', 'Level-2', 'Lawtons', '6 licensed beds. 0 vacancies.', 162, '1630529575-1612fe827a70be.jpg', '1630529575-1612fe827a93c7.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 'Located in upper west side, in a quiet part of town. Activity orientated staff, we have a great walking area for our residents to enjoy. Home away from home. Wifi tv in each room', NULL, NULL, NULL, NULL, '2021-06-23 16:39:50', '2021-09-02 00:52:55'),
(177, 'CurtLin Manor', '61 Bonnie Rd, Nauwigewauk, NB E5N 7A1', 'Tammy Brown', 'breelizz@live.com', '(506) 832 3510', '832 5794', NULL, 'E5N 7A1', '1-20', 'Level-4', 'Sobeys', '9 licensed beds no vacancies', 163, '1624551504-160d4b050988e8.png', NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/groups/872685416147060', NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health,Intellectual and Developmental', 'Saint John', 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Beautiful country setting home, with highly trained staff. Surrounded by nature, and just a short drive to grocery stores, pharmacies, churches, schools, and so much more.', NULL, NULL, NULL, NULL, '2021-06-24 16:18:24', '2021-06-24 20:57:52'),
(178, 'Hawthorne Place', '8 Hawthorne St, Hartland NB E7P 1K4', 'Linda Clark', 'clarklinda59@gmail.com', '5063756687', NULL, NULL, 'E7P 1K4', '1-20', 'Level-3G', 'Lawtons', '13 licensed beds, 3 vacancies , flexible with pets, trained on specific residence', 164, '1624554538-160d4bc2a6c4b5.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Located in the town of Hartland, not far from the Upper River Valley Hospital,  close to the Hartland community school, close to stores, friendly staff, activity orientated, and fun loving environment! We love to do excursions, and field trips!', NULL, NULL, NULL, NULL, '2021-06-24 17:08:58', '2021-06-24 21:42:59'),
(179, 'Ridgeview Manor', '100 McKay Loop Rd, Pennfield NB E5H 2K4', 'Jackie', 'lambertscove@gmail.com', '(506) 755-3997', '755 3997', NULL, 'E5H 2K4', '1-20', 'Level-2', 'Lawtons  West Side', 'Call and let them know theyre sending a fax before faxing , licensed for 10 , no vacancies,  waiting on photos , no social media', 165, '1625586103-160e479b7d4d59.jpg', '1625586103-160e479b7d6ff2.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health', 'Saint John', 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Quiet country setting, it is a place where our residences can walk freely, and enjoy nature. Home away from home. Midst of blueberry country.  We have a big beautiful garden as well.', NULL, NULL, NULL, NULL, '2021-06-24 17:31:06', '2021-06-24 21:42:50'),
(180, 'Sea Street Manor', '489 Sea Street, Saint John NB E2M 2N9', 'David & Phyllis Arseneau', 'seastreetmanor@gmail.com', '506 696 0857', '214 3027', NULL, 'E2M 2N9', '1-20', 'Level-2', 'Lawtons', '18 beds, 0 vacancies, no instagram , or youtube', 166, '1624557187-160d4c6835bb47.png', NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/groups/2232173220334022', NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Beautiful view of the Bay of Fundy, and partridge island.', NULL, NULL, NULL, NULL, '2021-06-24 17:53:07', '2021-06-24 22:07:26'),
(181, 'Collingwood Rest Home', '249 Route 176 Penfield, NB E5H 1R9', 'Tina Ridgley', 'jody@jodymunn.ca', '506 456 3533', NULL, NULL, 'E5H1R9', '1-20', 'Level-2', 'Lawtons', '20 licensed beds. 8 vacancies.  No social media.', 168, '1624907974-160da20c69c79a.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health', 'Saint John', 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Country setting home, with friendly staff.  Home away from home.', NULL, NULL, NULL, NULL, '2021-06-28 19:19:34', '2021-06-28 23:23:26'),
(182, 'McNair Manor', '11 Beechwood Avenue Moncton, NB', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '8540965', NULL, 'E1A 5P7', '21-40', 'Level-2', 'Lawtons', '22 licensed beds, 1 vacancy', 169, '1652913880-1628576d8e3032.JPG', '1652913880-1628576d8e520f.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, NULL, '2021-07-05 16:42:43', '2021-07-05 22:18:08'),
(183, 'Fundy Bay Manor', '106 Main Street, St George NB E5C 3J9', 'Karen Doughtery-Seaman', 'fundybaymanor@nb.aibn.com', '506-755-2221', NULL, NULL, 'E5C 3J9', '1-20', 'Level-2', 'Guardian Drug', '8 licensed beds, no current vacancies.', 170, '1625587278-160e47e4e7f229.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'N/A', NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, '*', NULL, NULL, NULL, NULL, '2021-07-06 16:01:18', '2021-07-06 20:35:41'),
(184, 'Smith Special Care Home', '56 Dorchester St, Moncton, NB E1E 3A7', 'Alishia Perry', 'alisha.perry@accesshomecare.ca', '5063832826', NULL, NULL, 'E1E 3A7', '1-20', 'Level-2', 'Jean Coutu', '10 licensed beds, no vacancies', 171, '1625593126-160e49526b8aa8.jpg', NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/Access-Home-Care-112351725508215', 'accesshomecare', NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, '*', NULL, NULL, NULL, NULL, '2021-07-06 17:38:46', '2021-07-06 21:46:32'),
(185, 'Baycare Adult Residential Facility', '59 Pitt Street, Saint John', 'Joel McCarthy', '59pitt@nbnet.nb.ca', '5066580991', NULL, NULL, 'E2L-2V7', '1-20', 'Level-2', 'Jean Coutu', 'No comments.', 172, '1625765648-160e7371006e8d.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Saint John', 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Baycare is a bright, spacious facility which caters to the varying needs of its residents through a diverse and dynamic staff.  \r\nBaycare provides a family atmosphere for its residents and takes every effort to integrate newcomers in to the family mix.  \r\nHome cooked meals and individualized care plans help to underscore the fact that at Baycare, our residents are number one.\r\nIf you have any further questions, please feel free to contact Joel at 658-0991.', NULL, NULL, NULL, NULL, '2021-07-08 17:34:08', '2021-07-12 19:16:42'),
(186, 'Fairvilla Special Care Home', '358 Charlotte Street West Side, Saint John, NB E2M 1Y8', 'Bonnie Phillips', 'lornahydekingston@gmail.com', '5066522030', '652-1937', NULL, 'E2M 1Y8', '1-20', 'Level-2', 'Lawtons', '9 beds, no vacancies', 173, '1626200102-160edd826bcb46.jpg', NULL, NULL, NULL, NULL, NULL, 'na', 'N/A', NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Saint John', 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Large backyard, and porch to enjoy. Private rooms.  Wifi, tv, and cable provided by facility. Short distance from Lancaster mall, and our facility is on a bus route. Wheel chair accessible facility. Excellent food menu. Charming staff.', NULL, NULL, NULL, NULL, '2021-07-13 18:15:02', '2021-07-19 05:27:23'),
(187, 'Crescent Gardens Guest Home', '1 Crescent Gardens', 'June Shaw', 'rdls@bellaliant.net', '5063759113', NULL, NULL, 'E7P1L9', '1-20', 'Level-2', 'Nevers Pharmacy Hartland', 'We do not have hired staff.  Our residents go where I go and have many excursions weekly.', 174, '1626812988-160f7323c39b71.html', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Fredericton', 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, '2 Occupied beds.  1 Empty bed.  All rooms are single occupancy.  Home is located on a cul-de-sac overlooking the\r\nSt. John River with views of the Hugh John Bridge.', NULL, NULL, NULL, NULL, '2021-07-20 20:29:48', '2021-07-21 03:21:31'),
(188, 'Hearne street residence', '210 hearne st. Fredericton n.b.', 'Melinda smith', 'abcmelindasmith@yahoo.com', '450-0909', 'None', NULL, 'E3b6m3', '1-20', 'Level-2', 'Sobeys brookside dr.', 'None', 175, '1628805491-1611599735aaae.jpg', '1628805491-1611599735e762.jpg', '1628805491-1611599735f8bb.jpg', '1628805491-16115997360a08.jpg', '1628805491-1611599736291e.jpg', '1628805491-161159973647b2.jpg', 'None', 'None', 'None', 'None', 'None', 'None', 1, 'Mental Health', 'Fredericton', 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Family setting and comfort for those with mental health conditions.', NULL, NULL, NULL, NULL, '2021-08-12 21:58:11', '2021-08-13 14:15:47'),
(189, 'Hanwell Special Care and Senior Home', '2434 Route 640 Hanwell, NB, E3E 2C7', 'Karla Roberts', 'kroberts@nb.aibn.com', '5064519814', NULL, NULL, 'E3E 2C7', '1-20', 'Level-2', 'Lawtons', 'Emily filled out this profile on the phone', 176, '1629295468-1611d136c77447.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Blended Facility', 'Fredericton', 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 'Hanwell Special Care Home is a twenty bed special care home located in Fredericton, New Brunswick.', NULL, NULL, NULL, NULL, '2021-08-18 14:04:28', '2021-08-19 21:03:10'),
(190, 'Autumn Lee Retirement', '2031 Mountain Road, Monton, NB, E1G1B1', 'Wanda Penney- (506) 337-2249', 'autumnlee@outlook.com', '(506) 874-0757', '5063888866', NULL, 'E1G1B1', '41-60', 'Level-2', 'Lawtons', 'Emily created this profile on the phone. The website link did not work. The photos that were requested from Kijiji didn\'t work.', 177, '1629309002-1611d484a63de7.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Autumn Lee Retirement home is a 45 licensed bed home located in Moncton New Brunswick.', NULL, NULL, NULL, NULL, '2021-08-18 17:50:02', '2021-08-19 21:07:35'),
(192, 'Smiths Special Care Home', '56  DORCHESTER STREET, MONCTON, NB,', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', NULL, 'E1E 3A7', '1-20', 'Level-2', 'Jean Coutu', 'n.a', 179, '1632154449-16148b351eb656.jpg', '1632154449-16148b351f107f.jpg', '1632154450-16148b35201703.jpg', '1632154450-16148b35204286.jpg', '1632154450-16148b35206e76.jpg', '1632154450-16148b35209557.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Smith Special Care home is located off West Main Street in the desirable Jones Lake area. It is on a quiet street, close to bus routes and amenities. Our ten bed fully licensed facility has a lovely green space with a vegetable garden that is used to cook our home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TC, cable and internet access. Smith Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nSmith Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', NULL, NULL, NULL, NULL, '2021-09-20 16:14:10', '2021-09-20 20:14:32'),
(193, 'Residence Collette', '64  STEADMAN STREET, MONCTON, NB', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', NULL, 'E1C 9X5', '1-20', 'Level-2', 'Jean Coutu', 'n/a', 199, '1632154734-16148b46e09c3d.jpg', '1632154734-16148b46e0c18d.jpg', '1632154734-16148b46e0e203.jpg', '1632154734-16148b46e102ce.jpg', '1632154734-16148b46e15040.jpg', '1632154734-16148b46e1703b.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Residence Collette is located in downtown Moncton close to bus routes and all amenities. Our eighteen bed fully licensed facility is a very quiet home despite in the downtown core. We offer home cooked meal that are tailored to you (diabetic, low salt, etc)\r\n\r\nWe have a cozy common area that has comfortable couches and a TV – each bedroom has a TV, cable and internet access. Residence Collette also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nResidence Collette is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', NULL, NULL, NULL, NULL, '2021-09-20 16:18:54', '2021-09-20 20:19:12'),
(194, 'DALY\'S HOME CARE INC.', '28  TRIDER COURT, RIVERVIEW, NB,', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', NULL, 'E1B 4T9', '1-20', 'Level-2', 'Jean Coutu', 'na', 200, '1632154983-16148b56710fe0.jpg', '1632154983-16148b56713821.jpg', '1632154983-16148b56715dde.jpg', '1632154983-16148b567182f7.jpg', '1632154983-16148b5671a6bf.jpg', '1632154983-16148b5671ce45.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Daly’s Special Care Home is located on a quiet crescent in Riverview close to a bus route and amenities. Our fully licensed ten bed facility has a very large back yard with a swing to read your favourite book on. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable couches and TV – each bedroom has a TV, cable and internet access. Daley Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nDaley’s Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', NULL, NULL, NULL, NULL, '2021-09-20 16:23:03', '2021-09-20 20:23:18'),
(195, 'Residence Adventure', '1076  ELMWOOD DRIVE, MONCTON, NB,', 'Roberta Buchanan', 'roberta.buchanan@accesshomecare.ca', '(506) 874-0757', '506-383-9575', NULL, 'E1E 2H2', '1-20', 'Level-2', 'Jean Coutu', 'na', 201, '1632155236-16148b6642ec1b.jpg', '1632155236-16148b664339b2.jpg', '1632155236-16148b664364ab.jpg', '1632155236-16148b6643cdd0.jpg', '1632155236-16148b6643f0c8.jpg', '1632155236-16148b6644164e.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 'Residence Aventure Inc is located in beautiful Irishtown just outside the Moncton City limits not far from the Irishtown Nature Park. Our thirty bed fully licensed facility has wheelchair accessibility and lots of green space, vegetables gardens and a farm just around the corner. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TV, cable, internet access. They also have safety measures such as an emergency bell and grip bars.\r\n\r\nResidence Aventure Inc also offers personal care services such as laundry services, personal care, medication and diabetic management.  Residence Aventure is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', NULL, NULL, NULL, NULL, '2021-09-20 16:27:16', '2021-10-26 13:33:38'),
(201, 'Blackville Special Care Home', '178 Main Street', 'eric walls', 'ericwalls2015@hotmail.com', '15066253334', NULL, NULL, 'e9b1s4', '1-20', 'Level-3', 'Blackville Pharmacy', 'thank you for all the work', 184, '1641433720-161d64a78739f2.jpeg', '1641433720-161d64a78791ff.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors,Mental Health,Intellectual and Developmental,Blended Facility', 'Miramichi', 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, '9 bed care home in quite village of Blackville. Across the street from pharmacy and beautiful walking trail in the back that leads to local park. \r\nTransportation to appointments and the ability to keep your family doctor.\r\nSingle and double room available and satellite tv in all rooms.', NULL, NULL, NULL, NULL, '2022-01-06 01:48:40', '2022-01-10 00:26:12'),
(205, 'Dobbelsteyn Care Home', '245 Mount Pleasant Ave (E)', 'Paula Dobbelsteyn', 'jpdobbelsteyn@gmail.com', '506-633-0883', NULL, NULL, 'E2J1T7', '21-40', 'Level-2', 'Lawtons', 'Sorry I\'m late to the party.', 189, '1645727964-16217d0dc1fa9d.jpg', '1645727964-16217d0dc22b21.jpg', '1645727964-16217d0dc2317f.jpg', '1645727964-16217d0dc254b2.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Saint John', 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'Welcome to Dobbelsteyn Care Home. A family owned and operated Level 2 Special Care Home since 1995. Enjoy a large spacious facility built in September 2011. All rooms are all private, some.with private half bath. Lots of in house activities and plenty of space outside to sit and enjoy warm sunny days. Excellent home cooked meals, a family atmosphere with kind and friendly staff.', NULL, NULL, NULL, NULL, '2022-02-24 18:39:24', '2022-03-06 03:55:42');
INSERT INTO `member_homes` (`id`, `spch_name`, `spch_address`, `spch_contact_name`, `spch_email`, `spch_phone`, `spch_fax`, `spch_dept_name`, `spch_postal_code`, `spch_num_bed`, `spch_level_care`, `spch_pharmacy_name`, `spch_notes`, `spch_member_id`, `photo_url`, `photo_url_two`, `photo_url_three`, `photo_url_four`, `photo_url_five`, `photo_url_six`, `fb_url`, `inst_url`, `twi_url`, `youtube_url`, `linkdin_url`, `website_url`, `status`, `spch_facility`, `region`, `charge_above_government`, `provide_transport`, `allow_pet`, `allow_furniture`, `comfort_clothing_money`, `transport_medical_appointment`, `home_hairdressing`, `have_foot_care`, `staf_diabetes_insulin_train`, `staf_oxygen_thrapy_train`, `staf_colostomy_care_train`, `staf_wound_care_train`, `staf_dementia_care_train`, `accept_incontinent_urine`, `monitoring_sys_door`, `accept_mrsa_positve_client`, `have_experience_client_suffering_addictions`, `client_keep_physicians`, `have_practitioner_doc_nurse`, `relationship_extra_menual_nursing`, `client_extra_mural_care`, `provide_adaptive_equipment`, `how_to_acquire`, `provide_house_excursions`, `resident_outreach_attend_program`, `resident_work_community`, `staf_medication_administartion_traing`, `accommodate_special_diet`, `accessible_shower_wheelchair_person`, `have_outdoor_area`, `specific_visting_hour`, `provide_reference_existing_client`, `accept_resident_incontinent`, `administering_medication_training_required`, `free_vacancy`, `num_open_beds`, `is_free_vocancy`, `is_new`, `public_description`, `open_day`, `close_day`, `open_time`, `close_time`, `created_at`, `updated_at`) VALUES
(206, '44 Wildwood Drive', '44 Wildwood Drive, Lower Woodstock NB', 'Leonard Foster', 'crlb@nb.aibn.com', '1 506 325 4536', '1 506 325 4537', NULL, 'E7M 4C2', '1-20', 'Level-4', 'Medinine Shoppe', 'Main contact, Leonard Foster is the administrator and does not work at the home.  Can be reached at the number provided.', 190, '1647438146-16231e942bee26.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental,Blended Facility', 'Fredericton', 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'A level 4 facility that provides support to clients from the Departments of Social Development and Mental Health.', NULL, NULL, NULL, NULL, '2022-03-16 13:42:26', '2022-03-25 19:06:39'),
(207, '69 Beardsley Road', '69 Beardsley Road, Lower Woodstock . NB', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', NULL, 'E7M 4C8', '1-20', 'Level-4', 'Medicine Shoppe', 'Main contact Leonard Foster does not work at the facility.  Can be reached at number provided.', 202, '1647438146-16231e942c29b0.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental,Blended Facility', 'Fredericton', 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'A facility that provides level 4 care to clients referred from Departments of Social Development and Mental Health.', NULL, NULL, NULL, NULL, '2022-03-16 13:42:26', '2022-03-25 19:07:04'),
(208, '119 Broadway', '119 Broadway St, Woodstock Nb', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', NULL, 'EcM 6B4', '1-20', 'Level-4', 'Medicine Shoppe', 'Main contact, Leonard Foster does not work at the facility, can be reached at the number provided.', 203, '1647438146-16231e942c5d92.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental,Blended Facility', 'Fredericton', 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'A facility that provides level 4 care to clients referred from the Departments of Social Development and Mental Health.', NULL, NULL, NULL, NULL, '2022-03-16 13:42:26', '2022-03-25 19:07:13'),
(209, '117 Broadway', '117 Broadway Street, Woodstock NB', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', NULL, 'E7M 6B4', '1-20', 'Level-4', 'Medicine Shoppe', 'Main contact Leonard Foster does not work at the facility, can be reached at the above number.', 204, '1647438146-16231e942c7626.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Intellectual and Developmental,Blended Facility', 'Fredericton', 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, '117 is a level 4 facility providing care to clients referred from the Departments of Social Development and Mental Health.', NULL, NULL, NULL, NULL, '2022-03-16 13:42:26', '2022-03-25 19:07:23'),
(210, 'Silver Fox Special Care Home', '32 & 34 Vaughan St', 'Jason Wilson', 'jason@silverfoxretirementliving.com', '5062278061', '5063724518', NULL, 'E4J 2S8', '21-40', 'Level-2', 'PJC Jean Coutu Petitcodiac', 'n/a', 191, '1648841242-16247521a967d4.jpg', NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/Silver-Fox-Special-Care-Home', NULL, NULL, NULL, NULL, 'https://silverfoxretirementliving.com/silver-fox-special-care-home/', 1, 'Blended Facility', 'Moncton', 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'Silver Fox Special Care Home consists of two facilities offering 24 hour care for residents requiring Level 1 & 2 care needs accepting individuals with mental health concerns and senior residents. Our facilities offer home-like environments in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, etc.', NULL, NULL, NULL, NULL, '2022-04-01 19:27:22', '2022-05-10 17:31:21'),
(211, 'Silver Fox Estate', '10 Rae Drive', 'Jason Wilson', 'jason@silverfoxretirementliving.com', '5062278061', '5063724518', NULL, 'E4J 0E9', '21-40', 'Level-2', 'PJC Jean Coutu Petitcodiac', 'n/a', 215, '1648841242-16247521aa2f1c.jpg', '1648841242-16247521aa3426.jpg', NULL, NULL, NULL, NULL, 'https://www.facebook.com/SilverFoxEstate/', NULL, NULL, NULL, NULL, 'https://silverfoxretirementliving.com/', 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 'Silver Fox Estate is a retirement living home offering 24 hour care for residents requiring Level 1 & 2 care needs. Our facility offers a home-like environment in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care and spiritual services. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, floor curling, iPad training, etc.', NULL, NULL, NULL, NULL, '2022-04-01 19:27:22', '2022-05-10 17:31:29'),
(213, 'LJ Jaillet Residence Inc.', '3223 Mountain Road Moncton NB', 'Jackie', 'jackiejaillet@gmail.com', '(506)830-8175', NULL, NULL, 'E1G 2X1', '1-20', 'Level-2', 'Superstore', 'NA', 193, '1649684905-1625431a9a0d76.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Blended Facility', 'Moncton', 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 'We are a level 2 Special Care Home.', NULL, NULL, NULL, NULL, '2022-04-11 13:48:25', '2022-05-12 17:28:02'),
(214, 'Alternative Residences Alternatives', '1144 Amirault Street, Dieppe, NB', 'Trudy Jones', 'info@arainc.org', '5068547229 Ext. 1', NULL, NULL, 'E1A 1E2', '21-40', 'Level-3', 'Jean Coutu', 'We will update/add more information soon.', 194, '1651588011-162713bab8bcd5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Mental Health', 'Moncton', 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 'Alternative Residences Alternatives Inc. was first incorporated under the New Brunswick Companies Act in August of 1984 and today acts as the largest charitable organization in Greater Moncton that provides shelter, support services and amenities for those individuals dealing with mental illness.\r\n\r\nThe very existence of the organization is the result of numerous hours of volunteer work by dedicated Mental Health professionals and concerned citizens who voiced the need for an alternative to the institutional options available to the mentally ill. Today, we carry on that mission to better the lives of those individuals dealing with mental illness in our community.\r\n\r\nWe are a registered, not for profit charity. We partner with the two Regional Health Authorities, Social Development, as well as other community agencies such as CMHA.\r\n\r\nOur  mission is to provide a continuum of community-based housing and support services, with a recovery-oriented focus, providing individualized and client-centered services by working in collaboration with our partners in the addiction and mental health field.\"', NULL, NULL, NULL, NULL, '2022-05-03 14:26:51', '2022-05-04 00:39:58'),
(215, 'McNair Manor Level 3G, Moncton', '44 Beechwood Ave', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', NULL, 'E1A3L5', '1-20', 'Level-3G', 'Lawton\'s', 'Memory Care Level 3B, 1 vacancy', 210, '1652913503-16285755ff00a1.JPG', '1652913503-16285755ff1fab.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, NULL, '2022-05-18 22:38:24', '2022-05-19 21:04:00'),
(216, 'McNair Manor Level 3B, Riverview', '137 Whitepine Road', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', NULL, 'E1B4Y5', '1-20', 'Level-3B', 'Lawton\'s', 'Memory Care, Level 3B, 1 vacancy', 211, '1652913695-16285761f338c7.JPG', '1652913695-16285761f356ec.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Seniors', 'Moncton', 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, NULL, '2022-05-18 22:41:35', '2022-05-19 21:04:15');

-- --------------------------------------------------------

--
-- Table structure for table `member_menu`
--

CREATE TABLE `member_menu` (
  `id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  `display` int(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member_menu`
--

INSERT INTO `member_menu` (`id`, `class`, `name`, `link`, `parent_id`, `status`, `display`, `sort_order`) VALUES
(1, 'fa-dashboard', 'Dashboard', '', 0, 'Y', 1, 0),
(2, '', 'Dashboard', 'home/dashboard', 1, 'Y', 1, 0),
(3, 'fa-cubes', 'Resources', '', 0, 'Y', 1, 0),
(4, '', 'News', 'resources/news', 3, 'Y', 1, 0),
(5, '', 'Forms', 'resources/forms', 3, 'Y', 1, 1),
(6, '', 'Links', 'resources/links', 3, 'Y', 1, 2),
(7, '', 'Membership', 'membership', 1, 'Y', 1, 1),
(8, '', 'Residence', 'residences', 1, 'Y', 1, 2),
(9, '', 'Enquires', 'enquiries/overview', 1, 'Y', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `member_reset`
--

CREATE TABLE `member_reset` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_key` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menuitems`
--

CREATE TABLE `menuitems` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `link_type` varchar(255) NOT NULL,
  `link_object` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `show_subitems` tinyint(1) NOT NULL DEFAULT '1',
  `target_type` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuitems`
--

INSERT INTO `menuitems` (`id`, `menu_id`, `parent_id`, `link_type`, `link_object`, `class`, `attachment`, `show_subitems`, `target_type`, `sort_order`, `status`) VALUES
(1, 1, 0, 'internal', '', '', NULL, 1, '_self', 1, 1),
(2, 1, 0, 'internal', '', '', NULL, 1, '_self', 1, 1),
(3, 1, 0, 'pages', '4', '', NULL, 1, '', 2, 1),
(4, 2, 0, 'pages', '14', '', NULL, 1, '_blank', 1, 1),
(6, 1, 0, 'pages', '5', '', NULL, 1, '', 3, 1),
(7, 1, 0, 'pages', '6', '', NULL, 1, '', 4, 1),
(8, 1, 0, 'pages', '7', '', NULL, 1, '', 5, 1),
(9, 1, 0, 'pages', '8', '', NULL, 1, '', 6, 1),
(10, 1, 0, 'pages', '9', '', NULL, 1, '', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menuitems_desc`
--

CREATE TABLE `menuitems_desc` (
  `desc_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuitems_desc`
--

INSERT INTO `menuitems_desc` (`desc_id`, `menuitem_id`, `name`, `link`, `language`) VALUES
(1, 2, 'Home', '/', 'en'),
(2, 2, 'Home', '/', 'fr'),
(3, 3, 'About', '/', 'en'),
(4, 3, 'About', '/', 'fr'),
(5, 4, 'Covid-19 Statement', '/', 'en'),
(6, 4, 'Covid-19 Statement', '/', 'fr'),
(9, 6, 'Residences', '', 'en'),
(10, 6, 'Residences', '', 'fr'),
(11, 7, 'Board', '', 'en'),
(12, 7, 'Board', '', 'fr'),
(13, 8, 'Sponsors', '', 'en'),
(14, 8, 'Sponsors', '', 'fr'),
(15, 9, 'News', '', 'en'),
(16, 9, 'News', '', 'fr'),
(17, 10, 'Contact', '', 'en'),
(18, 10, 'Contact', 'contact', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `class`, `code`, `status`) VALUES
(1, 'Main Menu', '', 'main_menu', 1),
(2, 'Top Menu', '', 'top_menu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `type`, `slug`, `category`, `author`, `image`, `publish_date`, `sort_order`, `status`) VALUES
(1, 'member', 'nbscha-affordable-quality-now', 4, 'NBSCHA', 'mqdefault.jpg', '2021-03-30 18:30:00', 0, 1),
(2, 'public', 'nbscha-affordable-quality-now-220323060856', 4, 'NBSCHA', 'NBSCHA_Affordable_Quality_Now.jpg', '2021-03-30 18:30:00', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_categories`
--

CREATE TABLE `news_categories` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_categories`
--

INSERT INTO `news_categories` (`id`, `slug`, `sort_order`, `status`) VALUES
(1, 'training', 0, 1),
(2, 'agm', 0, 1),
(3, 'community', 0, 1),
(4, 'special-care-week', 0, 1),
(5, 'committees', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_categories_desc`
--

CREATE TABLE `news_categories_desc` (
  `desc_id` int(11) NOT NULL,
  `news_category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_categories_desc`
--

INSERT INTO `news_categories_desc` (`desc_id`, `news_category_id`, `name`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Training', NULL, NULL, NULL, 'en'),
(2, 2, 'AGM', NULL, NULL, NULL, 'en'),
(3, 3, 'Community', NULL, NULL, NULL, 'en'),
(4, 4, 'Special Care Week', NULL, NULL, NULL, 'en'),
(5, 5, 'Committees', NULL, NULL, NULL, 'en'),
(6, 1, 'Training', NULL, NULL, NULL, 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `news_desc`
--

CREATE TABLE `news_desc` (
  `desc_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text,
  `body` text,
  `video` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_desc`
--

INSERT INTO `news_desc` (`desc_id`, `news_id`, `title`, `summary`, `body`, `video`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'NBSCHA Affordable. Quality. Now.', 'New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '', 'NBSCHA Affordable. Quality. Now.', NULL, NULL, 'en'),
(2, 2, 'NBSCHA Affordable. Quality. Now.', 'New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '', 'NBSCHA Affordable. Quality. Now.', NULL, NULL, 'en'),
(3, 1, 'NBSCHA Affordable. Quality. Now.', 'New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', NULL, 'NBSCHA Affordable. Quality. Now.', '', '', 'fr'),
(4, 2, 'NBSCHA Affordable. Quality. Now.', 'New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', NULL, 'NBSCHA Affordable. Quality. Now.', '', '', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `banner_video` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `slug`, `class`, `banner_image`, `banner_video`, `status`) VALUES
(1, '', NULL, NULL, NULL, 1),
(2, '', NULL, NULL, NULL, 1),
(3, '', NULL, NULL, NULL, 1),
(4, 'about', NULL, NULL, NULL, 1),
(5, 'residences', 'residences', '', '', 1),
(6, 'board', NULL, '', '', 1),
(7, 'sponsors', NULL, '', '', 1),
(8, 'news', NULL, '', '', 1),
(9, 'contact', NULL, '', '', 1),
(10, 'news-details', NULL, '', '', 1),
(11, 'board-member-page', NULL, '', '', 1),
(12, 'residence-page', NULL, '', '', 1),
(13, 'faq', NULL, '', '', 1),
(14, 'covid-19-statement', NULL, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pages_desc`
--

CREATE TABLE `pages_desc` (
  `desc_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages_desc`
--

INSERT INTO `pages_desc` (`desc_id`, `page_id`, `title`, `subtitle`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Home', NULL, 'Home', NULL, NULL, 'en'),
(2, 2, 'Page not found', NULL, 'Page not found', NULL, NULL, 'en'),
(3, 1, 'Home', NULL, 'Home', NULL, NULL, 'fr'),
(4, 2, 'Page not found', NULL, 'Page not found', NULL, NULL, 'fr'),
(5, 3, 'Register', NULL, 'Register', NULL, NULL, 'en'),
(6, 3, 'Register', NULL, 'Register', NULL, NULL, 'fr'),
(7, 4, 'About Us', NULL, 'About Us', NULL, NULL, 'en'),
(8, 4, 'About Us', NULL, 'About Us', NULL, NULL, 'fr'),
(9, 5, 'Residences', '', 'Residences', NULL, NULL, 'en'),
(10, 6, 'Board', '', 'Board', NULL, NULL, 'en'),
(11, 7, 'Sponsors', '', 'Sponsors', NULL, NULL, 'en'),
(12, 8, 'News', '', 'News', NULL, NULL, 'en'),
(13, 9, 'Contact', '', 'Contact', NULL, NULL, 'en'),
(14, 10, 'News Details', '', 'News Details', NULL, NULL, 'en'),
(15, 11, 'Board Member Page', '', 'Board Member Page', NULL, NULL, 'en'),
(16, 12, 'Residence Page', '', 'Residence Page', NULL, NULL, 'en'),
(17, 13, 'FAQ', '', 'FAQ', NULL, NULL, 'en'),
(18, 14, 'Covid-19 Statement', '', 'Covid-19 Statement', NULL, NULL, 'en'),
(19, 0, 'Residences', '', NULL, NULL, NULL, ''),
(20, 0, 'Residences', '', NULL, NULL, NULL, ''),
(21, 0, 'Residences', '', NULL, NULL, NULL, 'fr'),
(22, 0, 'Residences', '', NULL, NULL, NULL, 'fr'),
(23, 5, 'Residences', '', 'Residences', '', '', 'fr'),
(24, 6, 'Board', '', NULL, NULL, NULL, 'fr'),
(25, 8, 'News', '', NULL, NULL, NULL, 'fr'),
(26, 10, 'News Details', '', NULL, NULL, NULL, 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_type` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `content` text,
  `gallery` text,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_contents`
--

INSERT INTO `page_contents` (`id`, `page_id`, `content_type`, `title`, `subtitle`, `image`, `video`, `content`, `gallery`, `sort_order`, `language`) VALUES
(1, 14, 'text_only', '', '', '', '', '<p>\r\n	2020 and 2021 have been challenging years for the entire world as we navigate this ever-changing pandemic.&nbsp; Much preparation has taken place to ensure Special Care Homes in New Brunswick are prepared, supported, and operating with the utmost emphasis on safety, while ensuring quality care services are maintained for our residents.</p>\r\n<p>\r\n	The two provincial associations have worked in unison with the multiple government departments and have continued to have your back with regards to ensuring proper supply to PPE, additional funding for your staff, financial subsidy to assist with additional costs related to COVID, securing funding, and helping prepare a comprehensive Operational Plan template (reach out to your association and we will forward you the link) that you can edit for your own personal use, and much much more.</p>\r\n<p>\r\n	Although our province has experienced a few outbreaks and unfortunately some deaths due to this disease, we are extremely grateful for our thousands of dedicated employees and hundreds of operators that have stayed the course and worked so hard to keep our residents and each other as safe as possible.</p>\r\n<p>\r\n	We have also assisted, alongside the Department of Social Development and the Extra-Mural Program of NB, in ensuring you have direct access to the most up-to-date COVID-19 information, statistics, vaccine clinic protocol, inspection protocols and preparedness, and many other helpful ways.</p>\r\n<p>\r\n	Our residents and their families and friends have experienced major interruptions in their time spent together.&nbsp; However, due to the incredible dedication and organizational ability of our operators, every effort has been made to ensure access to each other.&nbsp; The most up-to-date guidance information can be accessed at&nbsp;<a href=\"https://www2.gnb.ca/content/dam/gnb/Departments/h-s/pdf/Adult-Residential-Facilities-Nursing-Homes.pdf\" rel=\"noopener\" target=\"_blank\">https://www2.gnb.ca/content/dam/gnb/Departments/h-s/pdf/Adult-Residential-Facilities-Nursing-Homes.pdf</a></p>\r\n<p>\r\n	Provincial visiting protocols for each phase and accurate tools for operators and staff to help with increased infection control practices, isolation methods, reporting requirements, and many other topics can be accessed in this guidance document and also through directly contacting your association.</p>\r\n<p>\r\n	General public are encouraged to also view the visitation guidelines prepared by GNB at&nbsp;<a href=\"https://www2.gnb.ca/content/dam/gnb/Departments/h-s/pdf/arf_visitation_guidance_yellow-e.pdf\" rel=\"noopener\" target=\"_blank\">https://www2.gnb.ca/content/dam/gnb/Departments/h-s/pdf/arf_visitation_guidance_yellow-e.pdf</a></p>\r\n<p>\r\n	If operators are looking for help with completing their own operational plan for their residence please feel free to contact your association.</p>\r\n<p>\r\n	Take care everyone, and be safe</p>\r\n<p>\r\n	Board of Directors, NBSCHA</p>\r\n', NULL, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `page_widgets`
--

CREATE TABLE `page_widgets` (
  `page_id` int(11) NOT NULL,
  `widget_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_widgets`
--

INSERT INTO `page_widgets` (`page_id`, `widget_id`, `sort_order`) VALUES
(1, 4, 2),
(1, 5, 1),
(1, 6, 3),
(1, 9, 4),
(4, 2, 1),
(4, 3, 3),
(4, 13, 2),
(4, 14, 4),
(5, 11, 1),
(6, 7, 1),
(7, 12, 1),
(8, 10, 1),
(9, 15, 1),
(13, 8, 1),
(14, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `rid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`rid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 1, 0),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0),
(5, 0, 1, 0),
(6, 0, 1, 0),
(7, 0, 1, 0),
(8, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `regions_desc`
--

CREATE TABLE `regions_desc` (
  `desc_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `region_name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regions_desc`
--

INSERT INTO `regions_desc` (`desc_id`, `region_id`, `region_name`, `language`) VALUES
(1, 1, 'Region 1: Moncton', 'en'),
(2, 2, 'Region 2: Saint John', 'en'),
(3, 3, 'Region 3: Fredericton', 'en'),
(4, 4, 'Region 4: Edmundston', 'en'),
(5, 5, 'Region 5: Restigouche', 'en'),
(6, 6, 'Region 6: Chaleur', 'en'),
(7, 7, 'Region 7: Miramichi', 'en'),
(8, 8, 'Region 8: Acadian Peninsula', 'en'),
(9, 1, 'Region 1: Moncton', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `renewal_requests`
--

CREATE TABLE `renewal_requests` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `previous_package_id` int(11) NOT NULL,
  `previous_issue_date` timestamp NULL DEFAULT NULL,
  `previous_expiry_date` timestamp NULL DEFAULT NULL,
  `new_package_id` int(11) NOT NULL,
  `new_max_beds_count` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `payment_response` text NOT NULL,
  `payment_comments` text,
  `payment_info` text NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `processed_by` int(11) NOT NULL,
  `processed_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `residences`
--

CREATE TABLE `residences` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postalcode` varchar(255) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `max_beds_count` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `pharmacy_name` varchar(255) NOT NULL,
  `facilities` varchar(255) NOT NULL,
  `region_id` int(11) NOT NULL,
  `mainimage` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `image4` varchar(255) DEFAULT NULL,
  `image5` varchar(255) DEFAULT NULL,
  `image6` varchar(255) DEFAULT NULL,
  `virtual_tour` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `features` text NOT NULL,
  `beds_count` int(11) NOT NULL,
  `vacancy` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `residences`
--

INSERT INTO `residences` (`id`, `slug`, `member_id`, `address`, `postalcode`, `contact_name`, `email`, `phone`, `fax`, `package_id`, `max_beds_count`, `language_id`, `level_id`, `pharmacy_name`, `facilities`, `region_id`, `mainimage`, `image2`, `image3`, `image4`, `image5`, `image6`, `virtual_tour`, `facebook`, `instagram`, `twitter`, `youtube`, `linkedin`, `website`, `features`, `beds_count`, `vacancy`, `created`, `status`) VALUES
(1, 'seely-lodge', 1, '3277 Westfield, Saint John, NB E2M 7B5', 'E2M7B5', 'Jan Seely', 'janseely@rogers.com', '506-639-4478', '506-217-1700', 1, 12, 1, 1, 'Lawtons Catherwood st. Saint John', '1,2,4', 2, '1617303527-1606617e76d231.jpeg', '1617303527-1606617e76ed98.jpeg', '1650200112-1625c0e30e8771.jpg', '1650200112-1625c0e30ea612.jpg', '1650200112-1625c0e30ebf6b.jpg', '1650200112-1625c0e30ed97f.jpg', NULL, 'https://www.facebook.com/seely.lodge.9', NULL, NULL, NULL, NULL, 'www.murraystseelylodgesch.com', 'a:26:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2021-04-01 18:58:47', 1),
(2, 'birchmount-lodge', 2, '144 Birchmount Drive, Moncton by', 'E1C8E7', 'Joanne Allen', 'openarmscare@hotmail.com', '506-384-7573', '506-384-7523', 2, 32, 1, 1, 'Medicine Shoppe 294', '2', 1, '1612457219-1601c2503cca45.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:8:{i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 40, 0, '2020-11-13 16:59:45', 1),
(3, 'victoria-villa-inc', 3, '566 East Riverside Dr., Perth-Andover', 'E7H 1Z4', 'Jennifer Eagan', 'victoriavillainc@outlook.com', '506-273-9394', '506-273-9797', 2, 24, 1, 1, 'Johnson\'s Guardian', '1', 3, '1617623143-1606af86734e41.jpg', '1621246016-160a24040d8d0f.JPG', '1621246016-160a24040db562.JPG', '1621246016-160a24040ddccd.JPG', '1621246016-160a24040e051a.JPG', '1621246016-160a24040e2faf.JPG', NULL, 'https://www.facebook.com/Victoria-Villa-Inc-Special-Care-Home-187805967969814', NULL, NULL, NULL, NULL, 'www.victoriavilla.ca', 'a:16:{i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 40, 0, '2021-04-05 11:45:43', 1),
(4, 'all-needs-special-care-home-inc', 4, '152 Douglas Avenue, Fredericton NB E3A 2N9', 'E3A 2N9', 'Miluska H Walton', 'miluskahwalton@gmail.com', '(506)459-2186', '(506)459-0120', 1, 8, 1, 1, 'Fredericton Sobeys Northside', '4', 3, '1605288146-15faec0d25a22c.jpeg', '1605288146-15faec0d25a72e.jpeg', '1617801340-1606db07c94989.JPG', '1618950129-1607f37f133707.JPG', '1619292804-160847284db800.JPG', '1618950129-1607f37f13a92a.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-13 17:22:26', 1),
(5, 'alouette-special-care-home', 5, '2100 Amirault Street, Dieppe, NB E1A 7K4', 'E1A 7K4', 'Elizabeth McLay', 'administration@alouetteresidence.ca', '5068579200', '5068579201', 3, 55, 1, 1, 'Dieppe Pharmacy', '2', 1, '1605288590-15faec28ee8951.png', '1605288590-15faec28ee8ac7.png', '1605288590-15faec28eeb590.jpg', '1605288590-15faec28eec3df.JPG', '1605288590-15faec28eecc60.JPG', '1605288590-15faec28eed133.JPG', NULL, NULL, NULL, NULL, NULL, NULL, 'alouettespecialcarehome.com', 'a:15:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 60, 8, '2020-11-13 17:29:50', 1),
(6, 'concorde-hall', 6, '15 Shannex Drive', 'E2E 0M5', 'Kim Davis', 'kdavis@shannex.com', '506-848-3194', '848-3201', 3, 60, 1, 1, 'Lawton\'s', '1', 2, '1623024369-160bd62f1b28e3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://experienceparkland.com/en/lifestyle-options/supportive-lifestyle/', 'a:19:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 60, 9, '2020-11-13 17:50:06', 1),
(7, 'hillside-view-special-care-home', 7, '560 Front Mountain Road, Moncton NB E1G 3H3', 'E1G3H3', 'Mary Phillips', 'hillsideview13@gmail.com', '5063883018', '5063883018', 1, 0, 1, 4, 'Jean Coutu', '1', 1, '1605290585-15faeca5903702.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-13 18:03:05', 1),
(8, 'loch-lomond-villa-special-care-home', 8, '185 Loch Lomond Rd, Saint John, NB E2J 3S3', 'E2J 3S3', 'Christa', 'cmatheson@lochlomondvilla.com', '5066438497', '5066438283', 1, 0, 1, 1, 'Lawton\'s Pharmacy', '1', 2, '1605291757-15faeceed322de.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:5:{i:6;s:1:\"1\";i:20;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-13 18:22:37', 1),
(9, 'paradise-villa-inc', 9, '665 Clements Drive, Fredericton', 'E1G 7J2', 'Monique Corbett', 'directorofcare@paradise-villa.ca', '506-443-8000', '506-454-3413', 4, 0, 1, 1, 'Lawtons', '1', 3, '1617719585-1606c7121811e1.jpg', '1617719585-1606c712181768.jpg', '1617719585-1606c712183436.JPG', '1617719585-1606c712186606.JPG', '1617719585-1606c712189620.JPG', '1617719585-1606c71218c67c.JPG', NULL, 'https://www.facebook.com/paradisevillainc/', NULL, NULL, NULL, NULL, 'https://paradise-villa.ca/', 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 0, 0, '2020-11-13 19:01:15', 1),
(10, 'mazerolle-special-care-home-ltd', 10, '448 Gauvin Rd, Dieppe NB E1A 1M1', 'E1A1M1', 'Darlene Mazerolle', 'd_mazerolle96@hotmail.com', '506.869.0624', '506.855.5911', 2, 26, 1, 1, 'Familiprix', '4', 1, '1619054772-16080d0b43d88a.jpg', '1619047615-16080b4bf025e3.jpg', '1619047615-16080b4bf03ec3.jpg', '1619047615-16080b4bf05da3.jpg', '1619047615-16080b4bf08182.jpg', '1619047615-16080b4bf08f37.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";}', 40, 3, '2020-11-13 19:33:53', 1),
(11, 'riverdale-manor', 11, '3 Riverdale Dr, Hampton', 'E5N 5k2', 'Krissy travis', 'Krissy5646@gmail.com', '5068324051', '5068328989', 1, 0, 1, 1, 'Lawton sussex', '4', 2, '1631037989-16137aa25c2ee5.jpg', '1631037989-16137aa25c84dd.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-13 22:22:13', 1),
(12, 'serenity-cove-special-care-home', 12, '9919 Rte 102, Woodmans Point, NB E5K 4P5', 'E5K 4P5', 'Jennifer Paul Armstrong', 'jennlynnpaul@hotmail.com', '5067578155', '5062170265', 1, 9, 1, 1, 'Guardian Drugs GrandBay', '1,4', 2, '1605393567-15fb05c9fbfca9.jpeg', '1648505766-1624233a663ba5.jpg', '1605393567-15fb05c9fc2bf3.jpeg', '1648505766-1624233a66683b.jpg', '1648505766-1624233a6684c7.jpg', '1648505766-1624233a669479.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 1, '2020-11-14 22:39:27', 1),
(13, 'riverbend-residence', 13, '158 Wellington St., Miramichi, NB E1N 1L9', 'E1N1L9', 'Sara Williston', 'riverbendresidence@hotmail.com', '506-352-0137', '506-352-3035', 1, 20, 1, 1, 'Shoppers drug mart Douglastown', '1', 7, '1605488540-15fb1cf9cf419c.jpeg', '1605488541-15fb1cf9d0025c.jpeg', '1605488541-15fb1cf9d013ae.jpeg', '1605488541-15fb1cf9d021a8.jpeg', '1605488541-15fb1cf9d03fb2.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:10:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-16 01:02:21', 1),
(14, 'agape-home', 14, '690 Route 121, Bloomfield Norton, NB E5N 4V3', 'E5N4V3', 'Hazen and Fran Cooke', 'agapehome@bellaliant.com', '5068325935', '506 832-8815', 1, 0, 1, 1, 'Lawtons', '4', 2, '1605552535-15fb2c9977c0fa.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:11:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-16 18:48:55', 1),
(15, 'brunswick-hall', 15, '35 Patience Lane, Fredericton, NB E3B 0K4', 'E3B 0K4', 'Robyn Hutchison', 'rhutchison@shannex.com', '506-447-6450', '506-447-6451', 3, 60, 1, 1, 'Lawtons', '1', 3, '1623081032-160be4048e66fb.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:17:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 60, 2, '2020-11-16 21:00:04', 1),
(16, 'bb-balanced-wellness-center-inccentre-du-mieux-être-équilibré-bb-inc', 16, '49 Bulman Drive Moncton NB', 'E1G1G9', 'Lucie Boudreau', 'balancedwellnesscenter@gmail.com', '506-387-8456', '506-387-7060', 1, 0, 1, 5, 'Lawtons', '', 1, '1605623763-15fb3dfd31048f.PNG', NULL, NULL, NULL, NULL, NULL, NULL, 'https://m.facebook.com/communityresidence/?ref=bookmarks', NULL, NULL, NULL, NULL, NULL, 'a:13:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-17 14:36:03', 1),
(17, 'always-here-care-home', 17, '32 Baxter Rd. Saint John NB', 'E2H2V5', 'Katrina Drost', 'katrina.4.boys@hotmail.com', '506 696 6750', '506 693 6932', 1, 6, 1, 1, 'Lawton’s McAllister', '4', 2, '1605677008-15fb4afd0aabe3.jpeg', '1643319836-161f3121c5052e.jpg', '1643319836-161f3121c51c89.jpg', '1643319836-161f3121c52c74.jpg', '1643319836-161f3121c53873.jpg', '1643319836-161f3121c543c9.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-18 05:23:28', 1),
(18, 'slow-current-special-care-home', 18, '1126 Route 148, Nashwaak Village', 'E6C1N2', 'Cristie Dykeman', 'slowcurrentspecialcarehome@gmail.com', '5064597494', NULL, 1, 0, 1, 1, 'Ross Drugs', '1', 3, '1605750597-15fb5cf459a1f8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Slowcurrentspecialcarehome.com', 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-19 01:49:57', 1),
(19, 'melansons-special-care-home', 19, '215 st Patrick st bathurst nb', 'E2a4c9', 'Tammy dunn', 'cottage.53@hotmail.ca', '5065482534', '5065465502', 1, 14, 1, 1, 'Sobeys', '2', 6, '1619979059-1608eeb3341301.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:10:{i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 3, '2020-11-19 15:51:03', 1),
(20, 'hillside-lodge-inc', 20, '155 Tilley Drive, Fredericton NB E3B 5L2', 'E3B 5L2', 'Sarah Jenkins', 'sarah.jenkins@nbed.nb.ca', '5064507600', NULL, 1, 9, 1, 1, 'Medicine Shop on King Street', '4', 3, '1605999959-15fb99d578f2e1.JPG', '1605999959-15fb99d578f50a.JPG', '1605999959-15fb99d578f6c0.jpg', '1605999959-15fb99d578fc57.JPG', '1605999959-15fb99d57901d2.jpg', '1605999959-15fb99d57906f4.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-21 23:05:59', 1),
(21, 'maritime-manor-special-care-home', 21, '299 GOLDEN GROVE ROAD', 'E2H 2V5', 'Crystal Powell', 'kathleen11251@gmail.com', '15066474087', NULL, 1, 9, 1, 1, 'Sobeys East Point', '4', 2, '1651935092-162768774b3149.jpg', '1606332039-15fbeae8731084.jpg', '1606332039-15fbeae8732431.jpg', '1606332039-15fbeae873352b.jpg', '1606332039-15fbeae8734465.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:18:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-25 19:20:39', 1),
(22, 'carlisle-special-care-home', 22, '173 Carlisle Road, Douglas E3G 7M7', 'E3G 7M7', 'Susan VanWart', 'susanmvanwart@gmail.com', '450-3957', '506-206-1287', 1, 0, 1, 1, 'Keswick Pharmacy', '4', 3, '1606503519-15fc14c5f3e909.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-27 18:58:39', 1),
(23, 'protem-memory-care', 23, '71 Gorge Rd, Moncton, NB E1G 1E5', 'E1G 1E5', 'Danielle DeAgazio', 'info@protem.ca', '506-874-9652', '506-854-3519', 3, 50, 1, 3, 'Guardian', '1', 1, '1618583937-16079a1815f5c0.JPG', '1618583937-16079a18163b87.JPG', '1618583937-16079a1816703a.JPG', '1618583937-16079a1816c036.jpg', '1618583937-16079a1816ea1f.jpg', '1618948551-1607f31c793945.jpg', NULL, 'https://www.facebook.com/ProTemMemoryCare', 'https://www.instagram.com/protemmemorycare/', NULL, NULL, NULL, 'www.protem.ca', 'a:22:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 60, 0, '2021-04-15 20:09:55', 1),
(24, 'grass-home-ltd', 24, '774 Coverdale Rd', 'E1B 3L5', 'Lynn Grass', 'jgrass1213@rogers.com', '506-386-1740', '506-386-7040', 2, 24, 1, 4, 'Ford\'s Jean Coutu', '1', 1, '1606508787-15fc160f3bb8c5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 40, 0, '2020-11-27 20:26:27', 1),
(25, 'charlenes-special-care-home', 25, '44 Boucher St., Campbellton, NB E3N 2P4', 'E3N 2P4', 'Charlene Noye', 'charlenenoye@outlook.com', '5067592773', NULL, 1, 0, 1, 1, 'Different Pharmacies', '4', 5, '1608529851-15fe037bb0bde6.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:17:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-27 23:10:32', 1),
(26, 'west-side-manor', 26, '646 George Street', 'E2M3T3', 'Lisa Melanson', 'jklm2k2@hotmail.com', '506-672-1534', NULL, 1, 0, 1, 1, 'Lawtons Catherwood', '4', 2, '1606520126-15fc18d3e88b1a.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-27 23:35:26', 1),
(27, '3-brooks-villa', 27, '2587 Rte109 Three Brooks , N.B.', 'E7G2W6', 'Kelly Briggs', 'Kellybriggs12@live.ca', '506-356-8327', '506-356-2319', 1, 19, 1, 1, 'Superstore pharmacy', '4', 3, '1606523161-15fc19919c0890.png', '1606523161-15fc19919c23dd.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:18:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 2, '2020-11-28 00:26:01', 1),
(28, 'elizabeth-house-special-care-home-inc', 28, '178 Bridge Street Saint John', 'E2K 1S5', 'Amy Cook', 'rideout_amy@hotmail.com', '5066426058', NULL, 1, 0, 1, 1, 'Jean Coutu', '4', 2, '1606576583-15fc269c79bd85.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:9:{i:18;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:10;s:1:\"1\";i:12;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-28 15:16:23', 1),
(29, 'mcgrath-special-care-home', 29, '267 Rockland Road', 'E2K3K3', 'Lori McGrath', 'lorrainelynnmc@gmail.com', '5066523083', NULL, 1, 10, 1, 1, 'Lawton\'s', '2', 2, '1606576625-15fc269f1acbf8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:8:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";}', 20, 1, '2020-11-28 15:17:05', 1),
(30, 'mclays-oak-bay-haven-inc', 30, '12 Giddens lane Oak Bay NB', 'E3L 4K2', 'Steve McLay', 'mclaysbayhaven@gmail.com', '5064666611', '5064662533', 1, 0, 1, 1, 'Gaurdian Drug', '4', 2, '1606580213-15fc277f562f8b.jpeg', '1606580213-15fc277f56437f.jpeg', '1606580213-15fc277f5658ea.jpeg', '1606580213-15fc277f566a8d.jpeg', '1606580213-15fc277f56753e.jpeg', NULL, NULL, 'https://m.facebook.com/mclaysoakbayhaven/', NULL, NULL, NULL, NULL, NULL, 'a:22:{i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-28 16:16:53', 1),
(31, 'residence-o-bons-soins', 31, '330 Rue Pascal-Poirier, Shediac, NB E4P 2K9', 'E4P 2K9', 'Collette Doucette', 'collette.obs@rogers.com', '(506) 312-3301', '(506) 532-5459', 4, 98, 1, 1, 'Jean-Coutu', '1,4', 1, '1606637213-15fc3569db5a9b.jpg', '1606637213-15fc3569dbfc67.jpg', '1606637213-15fc3569dbfd45.jpg', '1606637213-15fc3569dbfdda.jpg', '1619046636-16080b0ec5fb70.jpg', '1619046636-16080b0ec6009b.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.shediacseniors.com/', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 0, 1, '2020-11-29 08:06:53', 1),
(32, 'southern-comfort-villa', 32, '1394 King Avenue, Bathurst, NB E2A 1S8', 'E2A1S8', 'Lillian Drapeau', 'drapeaulillian14@gmail.com', '15063509000', '15063508000', 3, 60, 1, 1, 'Jean Coutu', '1,3', 6, '1606695966-15fc43c1e89fc6.jpg', '1606695966-15fc43c1e8b1f5.JPG', '1606695966-15fc43c1e8b8e2.jpg', '1606695966-15fc43c1e8b9eb.JPG', '1606695966-15fc43c1e8c881.JPG', '1606695966-15fc43c1e8d2f2.JPG', NULL, 'Southern Comfort Villa', NULL, NULL, NULL, NULL, 'southerncomfortvilla.com', 'a:23:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:19;s:1:\"1\";}', 60, 0, '2020-11-30 00:26:06', 1),
(33, 'emery-house', 33, '88 Emery St', 'E1B 1B1', 'Jeff Hunter', 'jefhunter@rogers.com', '5063874518', '5063877854', 1, 9, 1, 1, 'Medicine Shoppe (West Main)', '4', 1, '1606740800-15fc4eb40b58fb.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-11-30 12:53:20', 1),
(34, 'scenic-view-special-care-home', 34, '3481 Eoute 121', 'E5P 1B2', 'Mercy Burge', 'ilovemyjobcanada@gmail.com', '15064334538', '15067991881', 1, 0, 1, 1, 'Lawtons', '1', 2, '1606781238-15fc58936ee80d.jpg', NULL, NULL, NULL, NULL, NULL, NULL, '@scenicViewCares', NULL, NULL, NULL, NULL, 'www.scenicviewcares.com', 'a:0:{}', 20, 0, '2020-12-01 00:07:19', 1),
(35, 'résidence-ti-bons-soins', 35, '60 Rue Gallagher, Shediac, NB E4P 1S5', 'E4P 1S5', 'Nicole Leblanc', 'tibonssoins@rogers.com', '351-0478', '351-0498', 1, 0, 1, 3, 'Lawtons Drugstore', '1', 1, '1607104709-15fca78c5d0342.jpeg', '1607104709-15fca78c5d0fb7.jpeg', '1607104709-15fca78c5d1b63.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:15:{i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-12-04 17:58:29', 1),
(36, 'ruth-sawler', 36, '37  CLARK STREET, HARTLAND, NB, E7P 1L3', 'E7P 1L3', 'Ruth Sawler', 'ruan@nbnet.nb.ca', '5063759193', '506-375-9193', 1, 0, 1, 1, 'Nevers & Pharmacy for Life', '4', 3, '1607180137-15fcb9f693e6a8.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:1;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-12-05 14:55:37', 1),
(37, 'topaz-special-care-home', 37, '219 route 124 Norton NB', 'E5T1B7', 'Tammy Long', 'tammylong@hotmail.com', '5068392715', '5065700062', 1, 10, 1, 1, 'Lawtons', '4', 2, '1607475454-15fd020fe2793a.jpeg', '1607475454-15fd020fe2e595.jpeg', '1607475454-15fd020fe2f700.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 1, '2020-12-09 00:57:34', 1),
(38, 'trueman-house', 38, '265-267 Church Street Moncton NB', 'e1c-5a7', 'Cary MacDonald', 'carymac63@gmail.com', '506-389-3138', NULL, 1, 0, 1, 1, 'Lawtons long term', '2', 1, '1607532278-15fd0fef6ec79e.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:16:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-12-09 16:44:39', 1),
(39, 'serenacare', 39, '15 Lady Russell St, Moncton, NB E1G 2E9', 'E1E 0C3', 'Susan Dixson', 'serenacare@bellaliant.com', '5063811550', '5062049156', 1, 0, 1, 4, 'Lawton\'s', '1', 1, '1628788136-1611555a883db4.JPG', '1628788136-1611555a88b33a.JPG', '1628788136-1611555a88fcab.JPG', '1628788136-1611555a893fdd.jpg', '1628788136-1611555a896c82.jpg', '1628788136-1611555a8995d9.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'www.serenacare.ca', 'a:18:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2020-12-13 17:44:37', 1),
(40, 'burns-manor', 40, '26 Bromley Ave', 'E1C5T9', 'Mike Sewell', 'jenburnsmanor@gmail.com', '(506)852-3554', NULL, 1, 0, 1, 1, 'Atlantic Superstore Trinity', '4', 1, '1608221857-15fdb84a10500a.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:10;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-12-17 16:17:37', 1),
(41, 'green-meadows-special-care-home-millstream', 41, '374 Route 880', 'E5P3K4', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-433-2502', '506-808-0028', 1, 0, 1, 1, 'Lawton\'s', '2', 2, '1642077155-161e01be33b426.jpeg', '1642077155-161e01be3403ff.JPG', '1642077155-161e01be3472ec.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-01-08 17:38:19', 1),
(42, 'the-briarlea-on-ryan-3g', 42, '599 Ryan St., Moncton, NB E1G 2W2', 'E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, 2, 0, 1, 4, 'Jean Coutu / Medicine Shoppe', '1', 1, '1610978245-1600593c56e200.jpg', '1623424648-160c37e88c877c.jpg', '1623424648-160c37e88caab0.jpg', '1623424648-160c37e88cc73c.jpg', '1623424648-160c37e88cdb52.jpg', '1623424648-160c37e88ced49.jpg', NULL, 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2021-01-18 13:57:25', 1),
(43, 'victory-house', 43, '30 Victory Ave', 'E3A 3V5', 'Jody Munn', 'jodymunnster@gmail.com', '506-260-3354', NULL, 1, 7, 1, 1, 'Medicine Shoppe', '2', 3, '1611421173-1600c55f534d73.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:7:{i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:15;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-01-23 16:59:33', 1),
(44, 'goguen-residence-678780-nb-inc', 44, '76 John st, Moncton NB,', 'E1C 2G9', 'Colleen Paynter', 'colleenpaynter@hotmail.com', '506 855-3549', '506 855-7257', 1, 0, 1, 5, 'Lawtons', '3', 1, '1612981401-1602424992f0ab.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-02-10 18:23:21', 1),
(45, 'laura-manor-special-care-home', 45, '86 Mecklenburg street, Saint John, NB E2L 1R3', 'E2L 1R3', 'Danielle Gallant', 'lauramanor86@gmail.com', '5066508706', NULL, 1, 16, 1, 1, 'Lawtons Pharmacy Catherwood', '1,2,3,4', 2, '1617302396-16066137c562d9.jpeg', '1622040670-160ae605e7cb07.jpeg', '1622040670-160ae605e7dcb6.jpeg', '1622040670-160ae605e7ecc6.jpeg', '1622040670-160ae605e7ff3d.jpeg', '1622040670-160ae605e803e2.jpg', NULL, 'https://www.facebook.com/search/top?q=Laura%20Manor%20Care%20Home', NULL, NULL, NULL, NULL, NULL, 'a:21:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-04-01 18:39:56', 1),
(46, 'waddell-residencehobby-farm', 46, '1077 Route 845 , Kingston, NB E5N 1K7', 'E5N 1K7', 'Ann Waddell', 'waddell@levesqueonline.com', '(506) 763-2257', '506-763-2257', 1, 0, 1, 1, 'Sobeys Rothesay', '1,2,3,4', 2, '1617903094-1606f3df6e9f61.jpg', '1617795369-1606d99298a8ff.jpg', '1619049000-16080ba28bbfa4.jpg', '1619049000-16080ba28bca34.jpg', '1619049000-16080ba28bdbe9.JPG', '1619049000-16080ba28be4ce.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-04-07 11:36:09', 1),
(47, 'living-hope-special-care-home', 47, '467 Picadilly Road, Piccadilly, Saint John NB E4E 5J7', 'E4E 5J7', 'Wilma Ledin', 'buchananwilma@gmail.com', '506 229 2170', '506 432 6322', 1, 8, 1, 1, 'Lawtons', '1', 2, '1618252662-160749376e9f1e.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:17:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 1, '2021-04-12 18:37:42', 1),
(48, 'murray-street-lodge', 48, '35 Murray Street, Grand Bay-Westfield, NB E1C5C7', 'E1C5C7', 'Heather Perrin', 'hseely86@hotmail.com', '5067383500', '5062171700', 1, 13, 1, 1, 'Lawtons', '1,2,3,4', 2, '1618377533-160767b3d7fcf1.JPG', '1618377533-160767b3d835cf.JPG', '1618377533-160767b3d84004.JPG', '1618377533-160767b3d84a3a.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'www.murraystseelylodgesch.com', 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-04-14 05:18:53', 1),
(49, 'metcalf-manor', 49, '133 Metcalf Street, Saint John, NB E2K 1K2', 'e2k1k2', 'VANESSA HARRIS OR BRYAN GALLANT', 'metcalfmanor1@gmail.com', '15062141690', NULL, 1, 6, 1, 1, 'SOBEY\'S NORTH', '4', 2, '1618842658-1607d94222ac9d.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:19;s:1:\"1\";}', 20, 1, '2021-04-19 14:30:58', 1),
(50, 'the-cedars', 50, '28 Milton Lane, Sackville, NB E4L3B7', 'E4L3B7', 'Julie Steeves', 'thecedarsarf@gmail.com', '506-939-2233', '506-939-2233', 1, 10, 1, 1, 'Lawtons', '4', 1, '1619017751-160804017c89fe.jpg', '1619017751-160804017cb094.jpg', '1621758095-160aa108f50d42.jpg', '1619017751-160804017cbf2b.jpg', NULL, '1619017751-160804017cc15f.jpg', NULL, 'https://www.facebook.com/thecedarsarf/', 'https://instagram.com/thecedarsarf?igshid=1cfdu2yj2dspk', NULL, NULL, NULL, NULL, 'a:18:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 1, '2021-04-21 15:09:11', 1),
(51, 'bartlett-gardens-care-home', 51, '15  Craig St', 'E3A6S9', 'Wendy Symonds', 'bartlettgardenscarehome@gmail.com', '9026644089', NULL, 1, 8, 1, 1, 'St. Mary’s', '4', 3, '1619037381-160808cc598df6.jpeg', '1619037381-160808cc598fab.jpeg', '1619037381-160808cc599122.jpeg', '1619037381-160808cc5992af.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:18:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 1, '2021-04-21 20:36:21', 1),
(52, 'coultons-special-care-home', 52, '251Loch Lomond Rd.', 'E2J1Y6', 'Marion MacDougall', 'coultonsspecialcarehome@live.com', '(506)214-1664', '(506)214-0142', 1, 14, 1, 1, 'Sandra Ferris', '1,2', 2, '1619041331-160809c33ee75f.jpeg', '1619041331-160809c33eeaae.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:18:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 2, '2021-04-21 21:42:11', 1),
(53, 'twin-towers-special-care-home', 53, '7 Elm Street, St Stephen, NB E3L 2S2', 'E3L2S2', 'Tom Knox', 'knoxtom@rocketmail.com', '5064675117', NULL, 1, 9, 1, 1, 'Lawtons', '4', 2, '1619123637-16081ddb57572f.png', '1619123637-16081ddb57685f.jpeg', '1619123637-16081ddb577020.jpeg', '1619123637-16081ddb579593.jpeg', '1619123637-16081ddb57b88c.jpeg', '1619123637-16081ddb57beab.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:14:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:3;s:1:\"1\";i:9;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 3, '2021-04-22 20:33:57', 1),
(54, 'north-minto-residence', 54, '781 Northside Drive, Minto, NB E4B 3C7', 'E4B 3C7', 'PAULA FASQUEL', 'mail@northmintoresidence.ca', '506-327-9000', '506-327-3000', 1, 18, 1, 3, 'Lawtons', '1,2,3,4', 3, '1621943188-160ace394659e1.jpg', '1620155420-160919c1c6f582.jpeg', '1620155420-160919c1c71ed9.jpeg', '1620155420-160919c1c7472f.jpeg', '1620155420-160919c1c776b5.jpeg', '1620155420-160919c1cc9a5e.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, 'www.northmintoresidence.ca', 'a:23:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 3, '2021-04-22 20:34:40', 1),
(55, 'primrose-cottage-special-care-home', 55, '418 Route 880 Lower Millstream, Sussex NB E5P 3K4', 'e5p3k4', 'Lynn Wallace', 'lpearle@hotmail.com', '5064341869', NULL, 1, 0, 1, 1, 'Lawton\'s Sussex', '4', 2, '1626376784-160f08a5056670.jpg', '1626376784-160f08a5058127.JPG', '1626376784-160f08a505a5a9.jpg', '1626376784-160f08a505f047.jpg', '1626376784-160f08a5062409.jpg', '1626376784-160f08a5065570.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-04-25 19:23:43', 1),
(56, 'countryside-residence', 56, '74 W Main St, Port Elgin, Moncton NB E4M 1M1', 'E4m1m1', 'Crystal Lynn snowdon', 'crystallynnsnowdon1973@gmail.com', '5065382968', '538-2512', 1, 0, 1, 1, 'Village guardian', '1,2,3', 1, '1619897268-1608dabb41b506.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, 'Countryside residence', NULL, NULL, NULL, NULL, NULL, 'a:25:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2021-05-01 19:27:48', 1),
(57, 'manor-st-jude-care-home', 57, '416 Sandy point Road, Saint John, NB E2K 3R9', 'E2K 3R9', 'Steven', 'stevenwen@yahoo.com', '5069775188', NULL, 1, 8, 1, 1, 'Lawtons', '1,2,3,4', 2, '1620055020-1609013eca8220.jpg', '1620055020-1609013eca8367.jpg', '1620055020-1609013eca8440.jpg', '1620055020-1609013eca8531.jpg', '1620055020-1609013eca8654.jpg', '1620055020-1609013eca8771.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:15:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:20;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 2, '2021-05-03 15:17:00', 1),
(58, 'the-guardians-special-care-home-ltd', 58, '203 MacFarlane Street, Fredericton, NB E3A 1V7', 'E3A 1V7', 'Leonard Gervais', 'parkviewgardens203@outlook.com', '506-458-8968', '458-0918', 1, 0, 1, 1, 'Sobeys Brookside Pharmacy', '2,3', 3, '1620233216-16092cc0081b12.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:18;s:1:\"1\";i:3;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-05-05 16:46:56', 1),
(59, 'canterbury-hall', 59, '824 Coverdale Road, Riverview, NB E1B 0H9', 'E1B 0H9', 'Alison Baxter', 'abaxter@shannex.com', '5063870533', '506-387-7707', 3, 0, 1, 1, 'Lawton\'s Drug', '1', 1, '1620820304-1609bc150e2ca4.jpg', '1620820304-1609bc150e3fd0.jpg', '1620820304-1609bc150e4d04.jpg', '1620820304-1609bc150e582b.jpg', '1620820304-1609bc150e73a2.jpg', '1620820304-1609bc150e93ad.jpg', NULL, 'https://www.facebook.com/experienceparkland', NULL, NULL, 'https://www.youtube.com/ExperienceParkland', NULL, NULL, 'a:16:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 60, 0, '2021-05-12 11:51:44', 1),
(60, 'enhanced-living-gagetown', 60, '142 Tilley Road. Gagetown NB', 'E5M1H6', 'Erynn Bailey', 'erynn@enhancedliving.ca', '506-422-8600 ext 5', '506-488-2620', 2, 27, 1, 3, 'Oromocto Riverside Gaurdian', '1', 3, '1621356259-160a3eee3c89e9.jpg', '1621356259-160a3eee3c9370.jpg', '1621356259-160a3eee3c9471.jpg', '1621356259-160a3eee3c95ca.jpg', NULL, NULL, NULL, 'https://www.facebook.com/groups/enhancedlivinggagetown', 'enhancedlife_nb', '@EnhancedLife_NB', NULL, NULL, 'www.enhancedliving.ca', 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 40, 1, '2021-05-18 16:44:19', 1),
(61, 'howe-hall', 61, '50  VITALITY WAY, SAINT JOHN, NB, E2K 0J5', 'E2K 0J5', 'Kailey Rasch', 'krasch@shannex.com', '506-649-4713', NULL, 2, 60, 1, 1, 'Lawtons Drugs', '1', 2, '1623079980-160be3c2c6b111.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 40, 10, '2021-06-07 15:33:00', 1),
(62, 'swims-adult-residential-facility', 62, '448 White Rd, Avondale, NB E7K 1E5', 'E7K 1E5', 'Emily Louise Swim', 'gdswim@xplornet.com', '506-375-6613', '506-375-4609', 1, 0, 1, 1, 'The Medicine Shoppe', '1,2,3,4', 3, '1623863317-160ca301521fbe.JPG', '1623863317-160ca301522fc9.JPG', '1623863317-160ca301523809.JPG', '1623863317-160ca30152402b.JPG', '1623863317-160ca301524683.JPG', '1623863317-160ca301524baf.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:23:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-06-16 17:08:37', 1),
(63, 'alvinac-care-home', 63, '32 Chamberlain Settlement Road, Moncton NB E2E 6G4', 'E2A 6G4', 'Alvina Allain', 'allainalvina@hotmail.com', '(506)548-3229', NULL, 1, 4, 1, 1, 'Sobeys', '2', 1, '1624382322-160d21b72bf7ab.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:17:{i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 1, '2021-06-22 17:18:42', 1),
(64, 'care-a-lot-special-care-home', 64, '61 St Coeur Ct, Saint John, NB E2M 5R3', 'E2M 5R3', 'Darlene Forgrave', 'darleneforgrave2007@hotmail.com', '(506) 214-2983', NULL, 1, 0, 1, 1, 'Lawtons', '4', 2, '1630529575-1612fe827a70be.jpg', '1630529575-1612fe827a93c7.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:11:{i:28;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:27;s:1:\"1\";}', 20, 1, '2021-06-23 16:39:50', 1),
(65, 'curtlin-manor', 65, '61 Bonnie Rd, Nauwigewauk, NB E5N 7A1', 'E5N 7A1', 'Tammy Brown', 'breelizz@live.com', '(506) 832 3510', '832 5794', 1, 0, 1, 5, 'Sobeys', '2,3', 2, '1624551504-160d4b050988e8.png', NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/groups/872685416147060', NULL, NULL, NULL, NULL, NULL, 'a:20:{i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-06-24 16:18:24', 1),
(66, 'hawthorne-place', 66, '8 Hawthorne St, Hartland NB E7P 1K4', 'E7P 1K4', 'Linda Clark', 'clarklinda59@gmail.com', '5063756687', NULL, 1, 0, 1, 4, 'Lawtons', '4', 3, '1624554538-160d4bc2a6c4b5.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-06-24 17:08:58', 1),
(67, 'ridgeview-manor', 67, '100 McKay Loop Rd, Pennfield NB E5H 2K4', 'E5H 2K4', 'Jackie', 'lambertscove@gmail.com', '(506) 755-3997', '755 3997', 1, 0, 1, 1, 'Lawtons  West Side', '1,2', 2, '1625586103-160e479b7d4d59.jpg', '1625586103-160e479b7d6ff2.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:23:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-06-24 17:31:06', 1),
(68, 'sea-street-manor', 68, '489 Sea Street, Saint John NB E2M 2N9', 'E2M 2N9', 'David & Phyllis Arseneau', 'seastreetmanor@gmail.com', '506 696 0857', '214 3027', 1, 0, 1, 1, 'Lawtons', '1', 2, '1624557187-160d4c6835bb47.png', NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/groups/2232173220334022', NULL, NULL, NULL, NULL, NULL, 'a:17:{i:28;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-06-24 17:53:07', 1),
(69, 'collingwood-rest-home', 69, '249 Route 176 Penfield, NB E5H 1R9', 'E5H1R9', 'Tina Ridgley', 'jody@jodymunn.ca', '506 456 3533', NULL, 1, 0, 1, 1, 'Lawtons', '1,2', 2, '1624907974-160da20c69c79a.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:16:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:15;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-06-28 19:19:34', 1),
(70, 'mcnair-manor', 70, '11 Beechwood Avenue Moncton, NB', 'E1A 5P7', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '8540965', 2, 0, 1, 1, 'Lawtons', '1', 1, '1652913880-1628576d8e3032.JPG', '1652913880-1628576d8e520f.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2021-07-05 16:42:43', 1),
(71, 'fundy-bay-manor', 71, '106 Main Street, St George NB E5C 3J9', 'E5C 3J9', 'Karen Doughtery-Seaman', 'fundybaymanor@nb.aibn.com', '506-755-2221', NULL, 1, 0, 1, 1, 'Guardian Drug', '4', 2, '1625587278-160e47e4e7f229.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N/A', NULL, NULL, NULL, NULL, 'a:18:{i:28;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-07-06 16:01:18', 1),
(72, 'smith-special-care-home', 72, '56 Dorchester St, Moncton, NB E1E 3A7', 'E1E 3A7', 'Alishia Perry', 'alisha.perry@accesshomecare.ca', '5063832826', NULL, 1, 0, 1, 1, 'Jean Coutu', '2', 1, '1625593126-160e49526b8aa8.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/Access-Home-Care-112351725508215', 'accesshomecare', NULL, NULL, NULL, NULL, 'a:19:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-07-06 17:38:46', 1),
(73, 'baycare-adult-residential-facility', 73, '59 Pitt Street, Saint John', 'E2L-2V7', 'Joel McCarthy', '59pitt@nbnet.nb.ca', '5066580991', NULL, 1, 0, 1, 1, 'Jean Coutu', '2', 2, '1625765648-160e7371006e8d.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-07-08 17:34:08', 1);
INSERT INTO `residences` (`id`, `slug`, `member_id`, `address`, `postalcode`, `contact_name`, `email`, `phone`, `fax`, `package_id`, `max_beds_count`, `language_id`, `level_id`, `pharmacy_name`, `facilities`, `region_id`, `mainimage`, `image2`, `image3`, `image4`, `image5`, `image6`, `virtual_tour`, `facebook`, `instagram`, `twitter`, `youtube`, `linkedin`, `website`, `features`, `beds_count`, `vacancy`, `created`, `status`) VALUES
(74, 'fairvilla-special-care-home', 74, '358 Charlotte Street West Side, Saint John, NB E2M 1Y8', 'E2M 1Y8', 'Bonnie Phillips', 'lornahydekingston@gmail.com', '5066522030', '652-1937', 1, 0, 1, 1, 'Lawtons', '4', 2, '1626200102-160edd826bcb46.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'na', 'N/A', NULL, NULL, NULL, NULL, 'a:19:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-07-13 18:15:02', 1),
(75, 'crescent-gardens-guest-home', 75, '1 Crescent Gardens', 'E7P1L9', 'June Shaw', 'rdls@bellaliant.net', '5063759113', NULL, 1, 0, 1, 1, 'Nevers Pharmacy Hartland', '1', 3, '1626812988-160f7323c39b71.html', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:7:{i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-07-20 20:29:48', 1),
(76, 'hearne-street-residence', 76, '210 hearne st. Fredericton n.b.', 'E3b6m3', 'Melinda smith', 'abcmelindasmith@yahoo.com', '450-0909', 'None', 1, 0, 1, 1, 'Sobeys brookside dr.', '2', 3, '1628805491-1611599735aaae.jpg', '1628805491-1611599735e762.jpg', '1628805491-1611599735f8bb.jpg', '1628805491-16115997360a08.jpg', '1628805491-1611599736291e.jpg', '1628805491-161159973647b2.jpg', NULL, 'None', 'None', 'None', 'None', 'None', 'None', 'a:15:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:9;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-08-12 21:58:11', 1),
(77, 'hanwell-special-care-and-senior-home', 77, '2434 Route 640 Hanwell, NB, E3E 2C7', 'E3E 2C7', 'Karla Roberts', 'kroberts@nb.aibn.com', '5064519814', NULL, 1, 0, 1, 1, 'Lawtons', '1,2,4', 3, '1629295468-1611d136c77447.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:18:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-08-18 14:04:28', 1),
(78, 'autumn-lee-retirement', 78, '2031 Mountain Road, Monton, NB, E1G1B1', 'E1G1B1', 'Wanda Penney- (506) 337-2249', 'autumnlee@outlook.com', '(506) 874-0757', '5063888866', 3, 0, 1, 1, 'Lawtons', '1,2,4', 1, '1629309002-1611d484a63de7.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:26:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 60, 0, '2021-08-18 17:50:02', 1),
(79, 'smiths-special-care-home', 79, '56  DORCHESTER STREET, MONCTON, NB,', 'E1E 3A7', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', 1, 0, 1, 1, 'Jean Coutu', '4', 1, '1632154449-16148b351eb656.jpg', '1632154449-16148b351f107f.jpg', '1632154450-16148b35201703.jpg', '1632154450-16148b35204286.jpg', '1632154450-16148b35206e76.jpg', '1632154450-16148b35209557.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:25:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-09-20 16:14:10', 1),
(80, 'blackville-special-care-home', 80, '178 Main Street', 'e9b1s4', 'eric walls', 'ericwalls2015@hotmail.com', '15066253334', NULL, 1, 0, 1, 2, 'Blackville Pharmacy', '1,2,3,4', 7, '1641433720-161d64a78739f2.jpeg', '1641433720-161d64a78791ff.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-01-06 01:48:40', 1),
(81, 'dobbelsteyn-care-home', 81, '245 Mount Pleasant Ave (E)', 'E2J1T7', 'Paula Dobbelsteyn', 'jpdobbelsteyn@gmail.com', '506-633-0883', NULL, 2, 0, 1, 1, 'Lawtons', '1', 2, '1645727964-16217d0dc1fa9d.jpg', '1645727964-16217d0dc22b21.jpg', '1645727964-16217d0dc2317f.jpg', '1645727964-16217d0dc254b2.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:19:{i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2022-02-24 18:39:24', 1),
(82, '44-wildwood-drive', 82, '44 Wildwood Drive, Lower Woodstock NB', 'E7M 4C2', 'Leonard Foster', 'crlb@nb.aibn.com', '1 506 325 4536', '1 506 325 4537', 1, 0, 1, 5, 'Medinine Shoppe', '3,4', 3, '1647438146-16231e942bee26.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-03-16 13:42:26', 1),
(83, 'silver-fox-special-care-home', 83, '32 & 34 Vaughan St', 'E4J 2S8', 'Jason Wilson', 'jason@silverfoxretirementliving.com', '5062278061', '5063724518', 2, 0, 1, 1, 'PJC Jean Coutu Petitcodiac', '4', 1, '1648841242-16247521a967d4.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/Silver-Fox-Special-Care-Home', NULL, NULL, NULL, NULL, 'https://silverfoxretirementliving.com/silver-fox-special-care-home/', 'a:28:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2022-04-01 19:27:22', 1),
(84, 'lj-jaillet-residence-inc', 84, '3223 Mountain Road Moncton NB', 'E1G 2X1', 'Jackie', 'jackiejaillet@gmail.com', '(506)830-8175', NULL, 1, 0, 1, 1, 'Superstore', '4', 1, '1649684905-1625431a9a0d76.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:13:{i:18;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-04-11 13:48:25', 1),
(85, 'alternative-residences-alternatives', 85, '1144 Amirault Street, Dieppe, NB', 'E1A 1E2', 'Trudy Jones', 'info@arainc.org', '5068547229 Ext. 1', NULL, 2, 0, 1, 2, 'Jean Coutu', '2', 1, '1651588011-162713bab8bcd5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:15:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2022-05-03 14:26:51', 1),
(86, 'the-briarlea-on-ryan-level-2', 86, '599 Ryan St., Moncton, NB E1G 2W2', 'E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, 1, 0, 1, 1, 'Jean Coutu /Medicine Shoppe', '4', 1, '1623425805-160c3830d40321.jpg', '1623425805-160c3830d4175c.jpg', '1623425805-160c3830d42aa5.jpg', '1623425805-160c3830d43113.jpg', '1623425805-160c3830d434a9.jpg', '1623425805-160c3830d443cd.jpg', NULL, 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2021-06-11 15:36:45', 1),
(87, 'the-briarlea-on-ryan-3b', 87, '599 Ryan St., Moncton, NB E1G 2W2', 'E1G 2W2', 'Charline Johnson', 'thebriarlea@gmail.com', '506-204-1099', NULL, 1, 0, 1, 3, 'Jean Coutu /Medicine Shoppe', '1', 1, '1623426167-160c38477051fd.jpg', '1623426167-160c3847707da1.jpg', '1623426167-160c3847709c45.jpg', '1623426167-160c384770ad4a.jpg', '1623426167-160c384770b396.jpg', '1623426167-160c384770b6aa.jpg', NULL, 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2021-06-11 15:42:47', 1),
(88, 'the-briarlea-off-gorge-level-2', 88, '75 Briarlea Dr, Moncton, NB E1G 2E9', 'E1G 2E9', 'Charline Johnson', 'thebriarlea@gmail.com', '506-857-8866', NULL, 2, 0, 1, 1, 'Jean Coutu /Medicine Shoppe', '4', 1, '1623427068-160c387fc2fc3d.JPG', '1623427068-160c387fc3226d.jpg', '1623427068-160c387fc344fc.jpg', '1623427068-160c387fc366ee.jpg', '1623427068-160c387fc38862.jpg', '1623427068-160c387fc39701.jpg', NULL, NULL, NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2021-06-11 15:57:48', 1),
(89, 'the-briarlea-off-gorge-level-3b', 89, '75 Briarlea Dr, Moncton, NB E1G 2E9', 'E1G 2E9', 'Charline Johnson', 'thebriarlea@gmail.com', '506-857-8866', NULL, 1, 0, 1, 3, 'Jean Coutu /Medicine Shoppe', '1', 1, '1623427367-160c38927a8b38.JPG', '1623427367-160c38927ab2b0.jpg', '1623427367-160c38927ad6e6.jpg', '1623427367-160c38927afabc.jpg', '1623427367-160c38927b0aaa.jpg', '1623427367-160c38927b2400.jpg', NULL, 'https://www.facebook.com/Briarlea-Ryan-Rd-322007488720953', NULL, NULL, NULL, NULL, 'www.thebriarlea.com', 'a:24:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2021-06-11 16:02:47', 1),
(90, 'residence-collette', 90, '64  STEADMAN STREET, MONCTON, NB', 'E1C 9X5', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', 1, 0, 1, 1, 'Jean Coutu', '4', 1, '1632154734-16148b46e09c3d.jpg', '1632154734-16148b46e0c18d.jpg', '1632154734-16148b46e0e203.jpg', '1632154734-16148b46e102ce.jpg', '1632154734-16148b46e15040.jpg', '1632154734-16148b46e1703b.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:25:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-09-20 16:18:54', 1),
(91, 'dalys-home-care-inc', 91, '28  TRIDER COURT, RIVERVIEW, NB,', 'E1B 4T9', 'Alisha Perry', 'alisha.perry@accesshomecare.ca', '(506) 874-0757', '506-383-9575', 1, 0, 1, 1, 'Jean Coutu', '4', 1, '1632154983-16148b56710fe0.jpg', '1632154983-16148b56713821.jpg', '1632154983-16148b56715dde.jpg', '1632154983-16148b567182f7.jpg', '1632154983-16148b5671a6bf.jpg', '1632154983-16148b5671ce45.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:25:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-09-20 16:23:03', 1),
(92, 'residence-adventure', 92, '1076  ELMWOOD DRIVE, MONCTON, NB,', 'E1E 2H2', 'Roberta Buchanan', 'roberta.buchanan@accesshomecare.ca', '(506) 874-0757', '506-383-9575', 1, 0, 1, 1, 'Jean Coutu', '4', 1, '1632155236-16148b6642ec1b.jpg', '1632155236-16148b664339b2.jpg', '1632155236-16148b664364ab.jpg', '1632155236-16148b6643cdd0.jpg', '1632155236-16148b6643f0c8.jpg', '1632155236-16148b6644164e.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:25:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-09-20 16:27:16', 1),
(93, '69-beardsley-road', 93, '69 Beardsley Road, Lower Woodstock . NB', 'E7M 4C8', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', 1, 0, 1, 5, 'Medicine Shoppe', '3,4', 3, '1647438146-16231e942c29b0.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-03-16 13:42:26', 1),
(94, '119-broadway', 94, '119 Broadway St, Woodstock Nb', 'EcM 6B4', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', 1, 0, 1, 5, 'Medicine Shoppe', '3,4', 3, '1647438146-16231e942c5d92.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-03-16 13:42:26', 1),
(95, '117-broadway', 95, '117 Broadway Street, Woodstock NB', 'E7M 6B4', 'Leonard Foster', 'crlb@nb.aibn.com', '506 325 4536', '506 325 4537', 1, 0, 1, 5, 'Medicine Shoppe', '3,4', 3, '1647438146-16231e942c7626.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-03-16 13:42:26', 1),
(96, 'macleods-too-inc', 96, '6437 Route 105, Lower Brighton, NB E7P 3J5', 'E7P 3J5', 'Heather Allison', 'kitt1yg@gmail.com', '5063758395', NULL, 1, 12, 1, 5, 'Medicine Shop - Woodstock', '2', 3, '1605999959-15fb99d57946ce.jpg', '1619831069-1608ca91d00584.jpg', '1619831069-1608ca91d01dc1.jpg', '1619831069-1608ca91d034a9.jpg', '1619831069-1608ca91d0478c.jpg', '1619831069-1608ca91d05ca1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2020-11-21 23:05:59', 1),
(97, 'country-lane-estates-nb-inc', 97, '21 Christopher Dr, Burton, NB E2V 3H4', 'E2V 3H4', 'Angela Cahill', 'countrylaneestatesinc@gmail.com', '357-2459', NULL, 1, 11, 1, 1, 'King Street Medicine Shoppe', '1,2,3,4', 3, '1620175648-16091eb20066f1.jpg', '1620175648-16091eb20068da.jpg', '1620175648-16091eb2006a64.jpg', '1620175648-16091eb2006c05.jpg', '1620175648-16091eb2006daa.jpg', '1620175648-16091eb2006f26.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 2, '2021-05-05 00:47:28', 1),
(98, 'country-lane-estates-nb-inc-220521061901', 98, '21 Christopher Dr, Burton, NB E2V 3H4', 'E2V 3H4', 'Angela Cahill', 'countrylaneestatesinc@gmail.com', '357-2459', NULL, 1, 7, 1, 3, 'King Street Medicine Shoppe', '1,2,3,4', 3, '1620176266-16091ed8a33391.jpg', '1620176266-16091ed8a33592.jpg', '1620176266-16091ed8a3371e.jpg', '1620176266-16091ed8a3387c.jpg', '1620176266-16091ed8a339da.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 2, '2021-05-05 00:57:46', 1),
(99, 'goguen-residence-621090nb-inc', 99, '15 Norwood Ave', 'E1C 6L7', 'Star Whalen', 'starwhalen76@hotmail.com', '506 381-4841', '506 3887964', 1, 0, 1, 5, 'Lawtons', '3', 1, '1612981401-16024249938c2b.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:17:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-02-10 18:23:21', 1),
(100, 'goguen-residence-inc', 100, '34 Bromley Ave', 'E1C 5T9', 'Colleen Paynter', 'colleen@goguenresidences.ca', '506 204-8448', '506 389-8139', 1, 0, 1, 5, 'Lawtons', '3', 1, '1612981401-1602424993afd5.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:21:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";}', 20, 0, '2021-02-10 18:23:21', 1),
(101, 'mcnair-manor-level-3g-moncton', 101, '44 Beechwood Ave', 'E1A3L5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 1, 0, 1, 4, 'Lawton\'s', '1', 1, '1652913503-16285755ff00a1.JPG', '1652913503-16285755ff1fab.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 20, 0, '2022-05-18 22:38:24', 1),
(102, 'mcnair-manor-level-3b-riverview', 102, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 1, 0, 1, 3, 'Lawton\'s', '1', 1, '1652913695-16285761f338c7.JPG', '1652913695-16285761f356ec.jpg', NULL, NULL, NULL, NULL, 'https://www.victoriavilla.ca', '', '', '', '', '', 'https://www.victoriavilla.ca', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 20, 0, '2022-05-18 22:41:35', 1),
(103, 'green-meadows-special-care-home-berwick', 103, '1063 Route 880', 'E5P3A9', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-433-1364', '506-808-0028', 1, 0, 1, 1, 'Lawton\'s', '1', 2, '1642077238-161e01c36d058c.jpeg', '1642077238-161e01c36d0de8.JPG', '1642077238-161e01c36d8f58.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 0, '2021-01-08 17:38:19', 1),
(104, 'green-meadows-special-care-home-belleisle', 104, '1199 East Scotch Settlement Road', 'E5P1N7', 'Chris Smith', 'chris.smith@ambienthealth.ca', '506-485-5890', '506-808-0028', 1, 1, 1, 1, 'Lawton\'s', '4', 2, '1642077560-161e01d782d0e9.jpeg', '1642077560-161e01d782da61.JPG', '1642077560-161e01d78327fd.JPG', '1642077560-161e01d7837fbe.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:22:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 20, 1, '2021-01-08 17:38:19', 1),
(105, 'open-arms-special-care-home', 105, '98 Glengrove Road, Moncton', 'E1A5X5', 'Joanne Allen', 'openarmscare@hotmail.com', '506-204-8409', NULL, 1, 8, 1, 1, 'Medicine Shoppe 294', '4', 1, '1605286785-15faebb818e60d.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:8:{i:2;s:1:\"1\";i:6;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:12;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";}', 20, 1, '2020-11-13 16:59:45', 1),
(106, 'silver-fox-estate', 106, '10 Rae Drive', 'E4J 0E9', 'Jason Wilson', 'jason@silverfoxretirementliving.com', '5062278061', '5063724518', 2, 0, 1, 1, 'PJC Jean Coutu Petitcodiac', '1', 1, '1648841242-16247521aa2f1c.jpg', '1648841242-16247521aa3426.jpg', NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com/SilverFoxEstate/', NULL, NULL, NULL, NULL, 'https://silverfoxretirementliving.com/', 'a:26:{i:18;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:11;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:23;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:15;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";i:17;s:1:\"1\";i:29;s:1:\"1\";i:19;s:1:\"1\";}', 40, 0, '2022-04-01 19:27:22', 1),
(107, 'paradise-villa', 107, '665 Clements Drive, Fredericton, NB E3G 7j2', 'E3G 7J2', 'Monique Corbett', 'paradisevilla.cs@gmail.com', '506-443-8000', '506-454-3413', 4, 0, 1, 3, 'Lawtons', '1', 3, '1624298666-160d0d4aa2c637.jpg', '1624298666-160d0d4aa31ba4.jpg', '1624298666-160d0d4aa34beb.jpg', '1624298666-160d0d4aa3aa73.jpg', '1624298666-160d0d4aa3d79d.jpg', '1624298666-160d0d4aa4040c.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a:20:{i:28;s:1:\"1\";i:18;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:20;s:1:\"1\";i:10;s:1:\"1\";i:21;s:1:\"1\";i:22;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:24;s:1:\"1\";i:14;s:1:\"1\";i:26;s:1:\"1\";i:16;s:1:\"1\";i:27;s:1:\"1\";}', 0, 0, '2021-06-21 18:04:26', 1),
(108, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 06:59:20', 1),
(109, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'None', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:02:58', 1),
(110, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', 'None', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:03:48', 1),
(111, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'None', '', '', '', '', '', 'None', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:05:09', 1),
(112, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'None', '', '', '', '', '', 'None', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:07:29', 1),
(113, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'sfasfasf', '', '', '', '', '', 'None', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:07:55', 1),
(114, '', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.victoriavilla.ca', '', '', '', '', '', 'https://www.victoriavilla.ca', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 07:16:05', 1),
(115, 'mcnair-manor-level-3b-riverview', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.victoriavilla.ca', '', '', '', '', '', 'https://www.victoriavilla.ca', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 13:16:40', 1),
(116, 'mcnair-manor-level-3b-riverview', 0, '137 Whitepine Road', 'E1B4Y5', 'Amy McNair', 'info@mcnairmanor.com', '5068515852', '5068540695', 0, 0, 1, 3, 'Lawton\'s', '1', 1, NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.victoriavilla.ca', '', '', '', '', '', 'https://www.victoriavilla.ca', 'a:21:{i:7;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";i:3;s:1:\"1\";i:16;s:1:\"1\";i:18;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:4;s:1:\"1\";i:6;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:26;s:1:\"1\";i:27;s:1:\"1\";i:29;s:1:\"1\";i:5;s:1:\"1\";}', 0, 0, '2022-05-25 13:23:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `residences_desc`
--

CREATE TABLE `residences_desc` (
  `desc_id` int(11) NOT NULL,
  `residence_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(400) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `residences_desc`
--

INSERT INTO `residences_desc` (`desc_id`, `residence_id`, `name`, `description`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Seely Lodge', 'Welcome to Seely Lodge Special Care Home, where your comfort and well-being are our number one priority.   For over 25 years we have remained dedicated to providing the highest level of care possible for our residents.    Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help!\r\n\r\nDescription of Services: \r\n\r\nOur home is located in Martinon, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices.\r\nWe provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc.\r\n\r\nProgramming:\r\n\r\nResidents are encouraged to be active and stay involved in community programs and events. We also employ a recreation director and utilize dedicated volunteers to enhance our weekly activities.  Eligible residents also attend weekly Outreach program offered by Loch Lomond Villa and we provide transportation to and from. \r\n\r\nLevel of Care:\r\n\r\nOur areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. \r\n\r\nWe are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies.\r\n\r\nCredentials:\r\n\r\nJan Seely has owned and operated this home for 25 years.  Our home is licensed and inspected, by the Department of Social Development.  Our personnel are fully qualified according to provincial standards and regulations.  We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', 'Seely Lodge', NULL, NULL, 'en'),
(2, 1, 'Seely Lodge', 'Welcome to Seely Lodge Special Care Home, where your comfort and well-being are our number one priority.   For over 25 years we have remained dedicated to providing the highest level of care possible for our residents.    Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help!\r\n\r\nDescription of Services: \r\n\r\nOur home is located in Martinon, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices.\r\nWe provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc.\r\n\r\nProgramming:\r\n\r\nResidents are encouraged to be active and stay involved in community programs and events. We also employ a recreation director and utilize dedicated volunteers to enhance our weekly activities.  Eligible residents also attend weekly Outreach program offered by Loch Lomond Villa and we provide transportation to and from. \r\n\r\nLevel of Care:\r\n\r\nOur areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. \r\n\r\nWe are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies.\r\n\r\nCredentials:\r\n\r\nJan Seely has owned and operated this home for 25 years.  Our home is licensed and inspected, by the Department of Social Development.  Our personnel are fully qualified according to provincial standards and regulations.  We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', 'Seely Lodge', NULL, NULL, 'fr'),
(3, 2, 'Birchmount Lodge', NULL, 'Birchmount Lodge', NULL, NULL, 'en'),
(4, 2, 'Birchmount Lodge', NULL, 'Birchmount Lodge', NULL, NULL, 'fr'),
(5, 3, 'Victoria Villa Inc.', 'N/A', 'Victoria Villa Inc.', NULL, NULL, 'en'),
(6, 3, 'Victoria Villa Inc.', 'N/A', 'Victoria Villa Inc.', NULL, NULL, 'fr'),
(7, 4, 'All Needs Special Care Home Inc.', 'Residents may be driven to appointments when necessary. We ask that families pitch in with family members appointments for their own good, as long as permitted.', 'All Needs Special Care Home Inc.', NULL, NULL, 'en'),
(8, 4, 'All Needs Special Care Home Inc.', 'Residents may be driven to appointments when necessary. We ask that families pitch in with family members appointments for their own good, as long as permitted.', 'All Needs Special Care Home Inc.', NULL, NULL, 'fr'),
(9, 5, 'Alouette Special Care Home', 'n', 'Alouette Special Care Home', NULL, NULL, 'en'),
(10, 5, 'Alouette Special Care Home', 'n', 'Alouette Special Care Home', NULL, NULL, 'fr'),
(11, 6, 'Concorde Hall', 'Licensed 60 bed special care home located in Quispamsis, NB. Welcome to Parkland In The Valley.', 'Concorde Hall', NULL, NULL, 'en'),
(12, 6, 'Concorde Hall', 'Licensed 60 bed special care home located in Quispamsis, NB. Welcome to Parkland In The Valley.', 'Concorde Hall', NULL, NULL, 'fr'),
(13, 7, 'Hillside View Special Care Home', 'j', 'Hillside View Special Care Home', NULL, NULL, 'en'),
(14, 7, 'Hillside View Special Care Home', 'j', 'Hillside View Special Care Home', NULL, NULL, 'fr'),
(15, 8, 'Loch Lomond Villa Special Care Home', '.', 'Loch Lomond Villa Special Care Home', NULL, NULL, 'en'),
(16, 8, 'Loch Lomond Villa Special Care Home', '.', 'Loch Lomond Villa Special Care Home', NULL, NULL, 'fr'),
(17, 9, 'Paradise Villa Inc.', 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping,\r\nchurches, bus route, and a short drive to downtown Fredericton.  Our new state of the art\r\nassisted living Senior Residence Complex truly defines what seniors living should\r\nbe.  Thoughtfully designed and beautifully executed, this well-appointed residence offers 78\r\nsingle first-class suites, and 4 of the 78 can be converted into suites for couples or\r\nsiblings.  This complex cares for level 2 and 3b residents.  This property is very well-managed\r\nwith experienced and committed staff.', 'Paradise Villa Inc.', NULL, NULL, 'en'),
(18, 9, 'Paradise Villa Inc.', 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping,\r\nchurches, bus route, and a short drive to downtown Fredericton.  Our new state of the art\r\nassisted living Senior Residence Complex truly defines what seniors living should\r\nbe.  Thoughtfully designed and beautifully executed, this well-appointed residence offers 78\r\nsingle first-class suites, and 4 of the 78 can be converted into suites for couples or\r\nsiblings.  This complex cares for level 2 and 3b residents.  This property is very well-managed\r\nwith experienced and committed staff.', 'Paradise Villa Inc.', NULL, NULL, 'fr'),
(19, 10, 'Mazerolle special care home LTD', 'Mazerolle Special care home is a licensed 26 bed level 2 home established in 1995.\r\nOur home is located in the beautiful city of Dieppe which offers there residents a shared cost for accessible transportation to and from medical appointments and outings. We are located on the city bus route and walking distance to corner store, church, mall and bowling alley.\r\nOur home is a ground floor facility with wheel chair accessibility inside and out with large patios, outdoor green space for lots of flowers and veggie gardens and a beautiful breeze off the cool marsh.\r\nThe home offers homestyle meals and snacks that adhere to Canada\'s food guide along with special diets including diabetic, cardiac, nephrology.\r\nThe facility has lots of safety features with sturdy grip poles and transfer benches in all bathrooms along with a sprinkler system in place and monitored fire alarms with security cameras. We are inspected yearly by fire marshal office, public health and social development.\r\nOur cozy living room has lots of windows, big screen TV and leather lazy boy chairs. There is an activity room with internet café set up for virtual visits and access to our house Gmail account. We have a full service hair and nail salon and a lazy house cat named \"Bonnie\".\r\nWe offer personal care, laundry services, medication and diabetic management, support from Extra-Mural and updating any new physicians orders as needed with lots of activities both inside and out. Staff are dedicated, love their job and have met or exceeded all social developments hiring requirements.. \r\nCome join our family!', 'Mazerolle special care home LTD', NULL, NULL, 'en'),
(20, 10, 'Mazerolle special care home LTD', 'Mazerolle Special care home is a licensed 26 bed level 2 home established in 1995.\r\nOur home is located in the beautiful city of Dieppe which offers there residents a shared cost for accessible transportation to and from medical appointments and outings. We are located on the city bus route and walking distance to corner store, church, mall and bowling alley.\r\nOur home is a ground floor facility with wheel chair accessibility inside and out with large patios, outdoor green space for lots of flowers and veggie gardens and a beautiful breeze off the cool marsh.\r\nThe home offers homestyle meals and snacks that adhere to Canada\'s food guide along with special diets including diabetic, cardiac, nephrology.\r\nThe facility has lots of safety features with sturdy grip poles and transfer benches in all bathrooms along with a sprinkler system in place and monitored fire alarms with security cameras. We are inspected yearly by fire marshal office, public health and social development.\r\nOur cozy living room has lots of windows, big screen TV and leather lazy boy chairs. There is an activity room with internet café set up for virtual visits and access to our house Gmail account. We have a full service hair and nail salon and a lazy house cat named \"Bonnie\".\r\nWe offer personal care, laundry services, medication and diabetic management, support from Extra-Mural and updating any new physicians orders as needed with lots of activities both inside and out. Staff are dedicated, love their job and have met or exceeded all social developments hiring requirements.. \r\nCome join our family!', 'Mazerolle special care home LTD', NULL, NULL, 'fr'),
(21, 11, 'Riverdale Manor', 'Country style home, located in Hampton. Home away from home!', 'Riverdale Manor', NULL, NULL, 'en'),
(22, 11, 'Riverdale Manor', 'Country style home, located in Hampton. Home away from home!', 'Riverdale Manor', NULL, NULL, 'fr'),
(23, 12, 'Serenity Cove Special Care Home', 'Our home is in the country and has a huge back deck with a waterfall which makes it so relaxing for the residents to enjoy the nice summer days.  Our residents also enjoy their own private rooms.  Our residents also love that our home use to be a rectory.  We are only 1 minute from Grandbay-Westfield and 15 Minutes to get into town.', 'Serenity Cove Special Care Home', NULL, NULL, 'en'),
(24, 12, 'Serenity Cove Special Care Home', 'Our home is in the country and has a huge back deck with a waterfall which makes it so relaxing for the residents to enjoy the nice summer days.  Our residents also enjoy their own private rooms.  Our residents also love that our home use to be a rectory.  We are only 1 minute from Grandbay-Westfield and 15 Minutes to get into town.', 'Serenity Cove Special Care Home', NULL, NULL, 'fr'),
(25, 13, 'Riverbend residence', 'Questions you may have about living in our Special Care Home: \r\nRiverbend Residence @ Norma’s Place\r\n\r\n\r\nWho owns and operates Riverbend Residence? Local Miramichiers, Colin and Sara Williston, own and operate Riverbend Residence@ NormasPlace.  Colin has his degree in Business from Dalhousie University and is a proprietor for over 25 years and Sara is a Registered Nurse of over 25 years\r\n\r\nWhen did Riverbend Residence @ Normas Place open? We opened May 1st, 2020\r\nWhere did Riverbend Residence get its name? We wished to incorporate our beautiful river system while commemorating Colin’s Mother, Norma.  Each resident room is named after a tributary river which feeds into the Great Miramichi River\r\n\r\nWhere are you located?  We are centrally located at 158 Wellington Street, Downtown Chatham, Miramichi, NB \r\n\r\nWhat level of care do you offer at Riverbend Residence? We specialize in Level 1 and Level 2 adult care.  We help with assistance in personal hygiene, medication administration, and activities of daily living.  \r\n\r\nWho pays for what? – The cost to stay at Riverbend is the same for everyone. Social Development carries out a financial assessment which will determine the amount that you will pay Riverbend Residence for your stay and what Social Development will contribute.  Depending on your income amount, a combination of your income and a subsidized amount provided by Social Development will cover the cost of rent at Riverbend Residence @ Norma’s Place. Once again, this is dependent on your individual income. \r\n\r\nWhat is included in the rent at Riverbend? Riverbend provides you a comfortable single room equipped with furnishings, 3 nutritious meals, snacks, entertainment, heat, lights, wifi, and 24 hour professional personal care.\r\n\r\nDo I receive any personal money to do with as I wish? – Each month, everyone will receive a comfort allowance as per Social Development. This allowance helps cover the costs of your medications and any personal items you may require.\r\n\r\nWhat is in each room?  In each room, there is a single bed, bed linens including a duvet, individual sinks, a chest of drawers, a bedside table and lamp, an armoire, a chair, a television, and a telephone. (cable service and personal phone line is provided at a reduced rate of $50/mth)\r\n\r\nCan couples live together? -  Riverbend Residence will do their best to accommodate the request to have side-by-side rooms however; there are no double rooms in our home.\r\n\r\nDoes Riverbend make and take me to any medical appointments?  We ask that you and your family maintain your medical management with respect to doctor’s appointments, and any other healthcare appointments. In the event that your family is not able to assist, we can help make arrangements with you to meet those needs.  \r\n\r\nAre there items I am not allowed to bring? – You are not permitted to have any appliance with an element in your rooms (i.e coffee maker, toaster, kettle etc.). Also, anything with an open flame is not permitted as per fire regulations and the safety to our home.\r\n\r\nAre pets allowed?  Riverbend Residence @ Norma’s Place welcomes visits from pets with permission from the operator.  \r\n\r\nWhat is your smoking policy? – Smoking is not permitted in or around Riverbend Residence @ Norma’s Place within 9 meters of an entrance; however, there is a designated smoking area on the grounds of our home.\r\n\r\nHow many residents does your home accommodate? We can accommodate 20 people with individual care needs at Riverbend Residence @ Norma’s Place.  \r\n\r\nWhat is the meal service like? – We take pride in saying that each day there are 3 home cooked meals served along with snacks in the afternoon and evening if desired by the residents. Meals are served at approximately: 8am, 12pm, and 4:30pm with the largest meal of the day being lunchtime. \r\n\r\nAre families welcome to visit? – Families and friends are always encouraged and certainly welcome. Sometimes there are rules and regulations that we are required to follow as per Social Development.\r\n\r\nAre there specific visiting hours? There are no designated visiting hours at Riverbend Residence @ Norma’s Place however due to some Social Development regulations during health outbreaks, restrictions may be in place with restricted or limited visiting.  It is best to call us to find out if there are such rules in place.\r\n\r\nAm I allowed to give gifts to employees? – Riverbend Residence @ Norma’s Place kindly asks that the public and residents do not give gifts of significant monetary value to employees. Small gifts, however, of insignificant monetary value are permitted, for example cookies that can be enjoyed by all staff.\r\n\r\nDo I bring my medications? Upon arrival, you are asked to bring all of you medications.  Your medications will be placed in a locked medication room and administered by staff only. You are not permitted to keep any medications on hand or in your room as per Social Development guidelines except for rescue medications such as rescue inhaler or epi pens.\r\n\r\nAre there social activities at Riverbend Residence?  We have had several different social activities at Riverbend including- Movie nights, music entertainers, crafts, weekly bingo, daily card games, campfire outings, washer toss, etc…\r\n\r\nIs alcohol or recreational drugs permitted at Riverbend?  We do not permit the use of alcohol or recreational drugs in our home unless directed and monitored by their primary heath care provider.\r\nCan I leave Riverbend to visit friends and family? What about overnight stays?  We encourage you to maintain and foster personal and/or family relationships, which includes your family and friends visiting you in your home and you visiting them in theirs.\r\n\r\nWho do I contact if I have any other questions?  You can call Sara at 625-3998 or Colin at 623-8608 \r\nWe would like to thank you for your interest in Riverbend Residence@ Norma’s Place\r\nColin and Sara', 'Riverbend residence', NULL, NULL, 'en'),
(26, 13, 'Riverbend residence', 'Questions you may have about living in our Special Care Home: \r\nRiverbend Residence @ Norma’s Place\r\n\r\n\r\nWho owns and operates Riverbend Residence? Local Miramichiers, Colin and Sara Williston, own and operate Riverbend Residence@ NormasPlace.  Colin has his degree in Business from Dalhousie University and is a proprietor for over 25 years and Sara is a Registered Nurse of over 25 years\r\n\r\nWhen did Riverbend Residence @ Normas Place open? We opened May 1st, 2020\r\nWhere did Riverbend Residence get its name? We wished to incorporate our beautiful river system while commemorating Colin’s Mother, Norma.  Each resident room is named after a tributary river which feeds into the Great Miramichi River\r\n\r\nWhere are you located?  We are centrally located at 158 Wellington Street, Downtown Chatham, Miramichi, NB \r\n\r\nWhat level of care do you offer at Riverbend Residence? We specialize in Level 1 and Level 2 adult care.  We help with assistance in personal hygiene, medication administration, and activities of daily living.  \r\n\r\nWho pays for what? – The cost to stay at Riverbend is the same for everyone. Social Development carries out a financial assessment which will determine the amount that you will pay Riverbend Residence for your stay and what Social Development will contribute.  Depending on your income amount, a combination of your income and a subsidized amount provided by Social Development will cover the cost of rent at Riverbend Residence @ Norma’s Place. Once again, this is dependent on your individual income. \r\n\r\nWhat is included in the rent at Riverbend? Riverbend provides you a comfortable single room equipped with furnishings, 3 nutritious meals, snacks, entertainment, heat, lights, wifi, and 24 hour professional personal care.\r\n\r\nDo I receive any personal money to do with as I wish? – Each month, everyone will receive a comfort allowance as per Social Development. This allowance helps cover the costs of your medications and any personal items you may require.\r\n\r\nWhat is in each room?  In each room, there is a single bed, bed linens including a duvet, individual sinks, a chest of drawers, a bedside table and lamp, an armoire, a chair, a television, and a telephone. (cable service and personal phone line is provided at a reduced rate of $50/mth)\r\n\r\nCan couples live together? -  Riverbend Residence will do their best to accommodate the request to have side-by-side rooms however; there are no double rooms in our home.\r\n\r\nDoes Riverbend make and take me to any medical appointments?  We ask that you and your family maintain your medical management with respect to doctor’s appointments, and any other healthcare appointments. In the event that your family is not able to assist, we can help make arrangements with you to meet those needs.  \r\n\r\nAre there items I am not allowed to bring? – You are not permitted to have any appliance with an element in your rooms (i.e coffee maker, toaster, kettle etc.). Also, anything with an open flame is not permitted as per fire regulations and the safety to our home.\r\n\r\nAre pets allowed?  Riverbend Residence @ Norma’s Place welcomes visits from pets with permission from the operator.  \r\n\r\nWhat is your smoking policy? – Smoking is not permitted in or around Riverbend Residence @ Norma’s Place within 9 meters of an entrance; however, there is a designated smoking area on the grounds of our home.\r\n\r\nHow many residents does your home accommodate? We can accommodate 20 people with individual care needs at Riverbend Residence @ Norma’s Place.  \r\n\r\nWhat is the meal service like? – We take pride in saying that each day there are 3 home cooked meals served along with snacks in the afternoon and evening if desired by the residents. Meals are served at approximately: 8am, 12pm, and 4:30pm with the largest meal of the day being lunchtime. \r\n\r\nAre families welcome to visit? – Families and friends are always encouraged and certainly welcome. Sometimes there are rules and regulations that we are required to follow as per Social Development.\r\n\r\nAre there specific visiting hours? There are no designated visiting hours at Riverbend Residence @ Norma’s Place however due to some Social Development regulations during health outbreaks, restrictions may be in place with restricted or limited visiting.  It is best to call us to find out if there are such rules in place.\r\n\r\nAm I allowed to give gifts to employees? – Riverbend Residence @ Norma’s Place kindly asks that the public and residents do not give gifts of significant monetary value to employees. Small gifts, however, of insignificant monetary value are permitted, for example cookies that can be enjoyed by all staff.\r\n\r\nDo I bring my medications? Upon arrival, you are asked to bring all of you medications.  Your medications will be placed in a locked medication room and administered by staff only. You are not permitted to keep any medications on hand or in your room as per Social Development guidelines except for rescue medications such as rescue inhaler or epi pens.\r\n\r\nAre there social activities at Riverbend Residence?  We have had several different social activities at Riverbend including- Movie nights, music entertainers, crafts, weekly bingo, daily card games, campfire outings, washer toss, etc…\r\n\r\nIs alcohol or recreational drugs permitted at Riverbend?  We do not permit the use of alcohol or recreational drugs in our home unless directed and monitored by their primary heath care provider.\r\nCan I leave Riverbend to visit friends and family? What about overnight stays?  We encourage you to maintain and foster personal and/or family relationships, which includes your family and friends visiting you in your home and you visiting them in theirs.\r\n\r\nWho do I contact if I have any other questions?  You can call Sara at 625-3998 or Colin at 623-8608 \r\nWe would like to thank you for your interest in Riverbend Residence@ Norma’s Place\r\nColin and Sara', 'Riverbend residence', NULL, NULL, 'fr'),
(27, 14, 'Agape Home', '.', 'Agape Home', NULL, NULL, 'en'),
(28, 14, 'Agape Home', '.', 'Agape Home', NULL, NULL, 'fr'),
(29, 15, 'Brunswick Hall', 'Services designed to meet specialized care needs. Assisted Living allows you to enjoy the lifestyle you want, while providing a helping hand to support you in your daily activities.', 'Brunswick Hall', NULL, NULL, 'en'),
(30, 15, 'Brunswick Hall', 'Services designed to meet specialized care needs. Assisted Living allows you to enjoy the lifestyle you want, while providing a helping hand to support you in your daily activities.', 'Brunswick Hall', NULL, NULL, 'fr'),
(31, 16, 'B&B Balanced Wellness Center Inc/Centre du mieux-être équilibré B&B Inc.', NULL, 'B&B Balanced Wellness Center Inc/Centre du mieux-être équilibré B&B Inc.', NULL, NULL, 'en'),
(32, 16, 'B&B Balanced Wellness Center Inc/Centre du mieux-être équilibré B&B Inc.', NULL, 'B&B Balanced Wellness Center Inc/Centre du mieux-être équilibré B&B Inc.', NULL, NULL, 'fr'),
(33, 17, 'Always Here Care Home', 'Welcome to our Home nestled on a beautiful property at 32 Baxter Rd.\r\n\r\nI would like to list a few items of interest:\r\n\r\n~ Owner lives on site with her family, 2 pups and a cat.\r\n~ Owner has operated this Care Home for 27 years.\r\n~ All one level.\r\n~ Wheelchair accessible.\r\n~ Designated Smoking area.\r\n~ 24 hr. supervision.\r\n~ Medications administered by qualified staff.\r\n~ Home cooked meals prepared by qualified staff.\r\n~ Transportation provided to and from Drs. appts.\r\n~ No upcharge.\r\n~ Foot Care provided for eligible residents.\r\n~ Mobile hairdresser.\r\n~ Established ongoing relationship with Extra Mural.\r\n~ All private rooms.\r\n~ 2 full baths.\r\n\r\nIf there’s further info./questions, please feel free to reach out.', 'Always Here Care Home', NULL, NULL, 'en'),
(34, 17, 'Always Here Care Home', 'Welcome to our Home nestled on a beautiful property at 32 Baxter Rd.\r\n\r\nI would like to list a few items of interest:\r\n\r\n~ Owner lives on site with her family, 2 pups and a cat.\r\n~ Owner has operated this Care Home for 27 years.\r\n~ All one level.\r\n~ Wheelchair accessible.\r\n~ Designated Smoking area.\r\n~ 24 hr. supervision.\r\n~ Medications administered by qualified staff.\r\n~ Home cooked meals prepared by qualified staff.\r\n~ Transportation provided to and from Drs. appts.\r\n~ No upcharge.\r\n~ Foot Care provided for eligible residents.\r\n~ Mobile hairdresser.\r\n~ Established ongoing relationship with Extra Mural.\r\n~ All private rooms.\r\n~ 2 full baths.\r\n\r\nIf there’s further info./questions, please feel free to reach out.', 'Always Here Care Home', NULL, NULL, 'fr'),
(35, 18, 'Slow Current Special Care Home', 'N/A', 'Slow Current Special Care Home', NULL, NULL, 'en'),
(36, 18, 'Slow Current Special Care Home', 'N/A', 'Slow Current Special Care Home', NULL, NULL, 'fr'),
(37, 19, 'Melansons special care home', 'Residential care house operating since 1985. Offer full suite of services including medical transport, medication management, outings, meal prep and special diets, laundry,  personal hygiene, central location,', 'Melansons special care home', NULL, NULL, 'en'),
(38, 19, 'Melansons special care home', 'Residential care house operating since 1985. Offer full suite of services including medical transport, medication management, outings, meal prep and special diets, laundry,  personal hygiene, central location,', 'Melansons special care home', NULL, NULL, 'fr'),
(39, 20, 'Hillside Lodge Inc', 'We are a level 2 home located in the heart of Fredeicton. We provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Hillside Lodge Inc', NULL, NULL, 'en'),
(40, 20, 'Hillside Lodge Inc', 'We are a level 2 home located in the heart of Fredeicton. We provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Hillside Lodge Inc', NULL, NULL, 'fr'),
(41, 21, 'Maritime Manor Special Care Home', 'We are a level 2 special care home. We strive on making our clients feel like they are at home in our small 9 bed facility, with a cozy home like feeling. We have qualified staff and 15plus years experience in geriatric care.', 'Maritime Manor Special Care Home', NULL, NULL, 'en'),
(42, 21, 'Maritime Manor Special Care Home', 'We are a level 2 special care home. We strive on making our clients feel like they are at home in our small 9 bed facility, with a cozy home like feeling. We have qualified staff and 15plus years experience in geriatric care.', 'Maritime Manor Special Care Home', NULL, NULL, 'fr'),
(43, 22, 'Carlisle Special Care Home', 'm', 'Carlisle Special Care Home', NULL, NULL, 'en'),
(44, 22, 'Carlisle Special Care Home', 'm', 'Carlisle Special Care Home', NULL, NULL, 'fr'),
(45, 23, 'ProTem Memory Care', 'ProTem Memory Care provides care exclusively to those who are living with a dementia diagnosis (3B).\r\nOur community is made up of 5 small homes that include a secured backyard area with gardens and walking paths. To the best of our ability we schedule the same care team in the same home with no more than 10 residents. We want our residents to build a meaningful and trusting relationship with those who are caring for them. There is 1 caregiver for every 3 residents. Our structural layout, customized care packages, daily activities, and trained team members is how ProTem offers true resident centred care to our residents and their families.', 'ProTem Memory Care', NULL, NULL, 'en'),
(46, 23, 'ProTem Memory Care', 'ProTem Memory Care provides care exclusively to those who are living with a dementia diagnosis (3B).\r\nOur community is made up of 5 small homes that include a secured backyard area with gardens and walking paths. To the best of our ability we schedule the same care team in the same home with no more than 10 residents. We want our residents to build a meaningful and trusting relationship with those who are caring for them. There is 1 caregiver for every 3 residents. Our structural layout, customized care packages, daily activities, and trained team members is how ProTem offers true resident centred care to our residents and their families.', 'ProTem Memory Care', NULL, NULL, 'fr'),
(47, 24, 'Grass Home Ltd', NULL, 'Grass Home Ltd', NULL, NULL, 'en'),
(48, 24, 'Grass Home Ltd', NULL, 'Grass Home Ltd', NULL, NULL, 'fr'),
(49, 25, 'Charlene’s Special Care Home', '.', 'Charlene’s Special Care Home', NULL, NULL, 'en'),
(50, 25, 'Charlene’s Special Care Home', '.', 'Charlene’s Special Care Home', NULL, NULL, 'fr'),
(51, 26, 'West Side Manor', NULL, 'West Side Manor', NULL, NULL, 'en'),
(52, 26, 'West Side Manor', NULL, 'West Side Manor', NULL, NULL, 'fr'),
(53, 27, '3 Brooks Villa', NULL, '3 Brooks Villa', NULL, NULL, 'en'),
(54, 27, '3 Brooks Villa', NULL, '3 Brooks Villa', NULL, NULL, 'fr'),
(55, 28, 'Elizabeth House Special Care Home Inc.', NULL, 'Elizabeth House Special Care Home Inc.', NULL, NULL, 'en'),
(56, 28, 'Elizabeth House Special Care Home Inc.', NULL, 'Elizabeth House Special Care Home Inc.', NULL, NULL, 'fr'),
(57, 29, 'McGrath Special Care Home', NULL, 'McGrath Special Care Home', NULL, NULL, 'en'),
(58, 29, 'McGrath Special Care Home', NULL, 'McGrath Special Care Home', NULL, NULL, 'fr'),
(59, 30, 'McLay’s Oak Bay Haven Inc', NULL, 'McLay’s Oak Bay Haven Inc', NULL, NULL, 'en'),
(60, 30, 'McLay’s Oak Bay Haven Inc', NULL, 'McLay’s Oak Bay Haven Inc', NULL, NULL, 'fr'),
(61, 31, 'Residence O Bons Soins', 'Residence O Bons Soins is located in the beautiful Shediac NB area and we are always available to talk with you about our facility and your needs.\r\n\r\nWe have 98 License subsidies beds and 33 Private independent beds\r\n\r\nCall Collette anytime at 506-312-3301to include your name on a waiting list.', 'Residence O Bons Soins', NULL, NULL, 'en'),
(62, 31, 'Residence O Bons Soins', 'Residence O Bons Soins is located in the beautiful Shediac NB area and we are always available to talk with you about our facility and your needs.\r\n\r\nWe have 98 License subsidies beds and 33 Private independent beds\r\n\r\nCall Collette anytime at 506-312-3301to include your name on a waiting list.', 'Residence O Bons Soins', NULL, NULL, 'fr'),
(63, 32, 'Southern Comfort Villa', 's', 'Southern Comfort Villa', NULL, NULL, 'en'),
(64, 32, 'Southern Comfort Villa', 's', 'Southern Comfort Villa', NULL, NULL, 'fr'),
(65, 33, 'Emery House', NULL, 'Emery House', NULL, NULL, 'en'),
(66, 33, 'Emery House', NULL, 'Emery House', NULL, NULL, 'fr'),
(67, 34, 'Scenic View Special Care Home', NULL, 'Scenic View Special Care Home', NULL, NULL, 'en'),
(68, 34, 'Scenic View Special Care Home', NULL, 'Scenic View Special Care Home', NULL, NULL, 'fr'),
(69, 35, 'Résidence Ti Bons Soins', 'm', 'Résidence Ti Bons Soins', NULL, NULL, 'en'),
(70, 35, 'Résidence Ti Bons Soins', 'm', 'Résidence Ti Bons Soins', NULL, NULL, 'fr'),
(71, 36, 'Ruth Sawler', 'g', 'Ruth Sawler', NULL, NULL, 'en'),
(72, 36, 'Ruth Sawler', 'g', 'Ruth Sawler', NULL, NULL, 'fr'),
(73, 37, 'Topaz Special care home', NULL, 'Topaz Special care home', NULL, NULL, 'en'),
(74, 37, 'Topaz Special care home', NULL, 'Topaz Special care home', NULL, NULL, 'fr'),
(75, 38, 'Trueman House', NULL, 'Trueman House', NULL, NULL, 'en'),
(76, 38, 'Trueman House', NULL, 'Trueman House', NULL, NULL, 'fr'),
(77, 39, 'Serenacare', 'N/A', 'Serenacare', NULL, NULL, 'en'),
(78, 39, 'Serenacare', 'N/A', 'Serenacare', NULL, NULL, 'fr'),
(79, 40, 'Burns Manor', NULL, 'Burns Manor', NULL, NULL, 'en'),
(80, 40, 'Burns Manor', NULL, 'Burns Manor', NULL, NULL, 'fr'),
(81, 41, 'Green Meadows Special Care Home - Millstream', 'When it comes to mental health, our Lower Millstream location is committed to providing lasting care to the people you love.', 'Green Meadows Special Care Home - Millstream', NULL, NULL, 'en'),
(82, 41, 'Green Meadows Special Care Home - Millstream', 'When it comes to mental health, our Lower Millstream location is committed to providing lasting care to the people you love.', 'Green Meadows Special Care Home - Millstream', NULL, NULL, 'fr'),
(83, 42, 'The Briarlea on Ryan 3G', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan 3G', NULL, NULL, 'en'),
(84, 42, 'The Briarlea on Ryan 3G', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan 3G', NULL, NULL, 'fr'),
(85, 43, 'Victory House', 'N/A', 'Victory House', NULL, NULL, 'en'),
(86, 43, 'Victory House', 'N/A', 'Victory House', NULL, NULL, 'fr'),
(87, 44, 'Goguen Residence 678780 NB INC.', '-', 'Goguen Residence 678780 NB INC.', NULL, NULL, 'en'),
(88, 44, 'Goguen Residence 678780 NB INC.', '-', 'Goguen Residence 678780 NB INC.', NULL, NULL, 'fr'),
(89, 45, 'Laura Manor Special Care Home', 'Laura Manor Special Care Home has been operating since 1992. Located in the heart of uptown Saint John. On bus route, walking distance to Key Industries, Mental Health Recovery services on Duke street and Mercantile. We accommodate your needs!', 'Laura Manor Special Care Home', NULL, NULL, 'en'),
(90, 45, 'Laura Manor Special Care Home', 'Laura Manor Special Care Home has been operating since 1992. Located in the heart of uptown Saint John. On bus route, walking distance to Key Industries, Mental Health Recovery services on Duke street and Mercantile. We accommodate your needs!', 'Laura Manor Special Care Home', NULL, NULL, 'fr'),
(91, 46, 'Waddell Residence/hobby farm', 'Waddell Residence is situated on the Kingston Peninsula. Just off the Gondola Point Ferry turn right and 1 ½ km’s.\r\nIt is also a hobby farm. We have alpaca’s, goats, sheep, rabbits, chickens cats and dogs the residents help with the care and help look after the yard also..\r\n\r\nIt is close to a local store, school and churches.  Also 5 minutes to Quispamsis. Our clients are accepted by our small community. \r\nWe are registered for 6 clients, everyone has their own room, TV and loads of movies.  Home made meals of course.  I also take them to their appointments and their shopping.', 'Waddell Residence/hobby farm', NULL, NULL, 'en'),
(92, 46, 'Waddell Residence/hobby farm', 'Waddell Residence is situated on the Kingston Peninsula. Just off the Gondola Point Ferry turn right and 1 ½ km’s.\r\nIt is also a hobby farm. We have alpaca’s, goats, sheep, rabbits, chickens cats and dogs the residents help with the care and help look after the yard also..\r\n\r\nIt is close to a local store, school and churches.  Also 5 minutes to Quispamsis. Our clients are accepted by our small community. \r\nWe are registered for 6 clients, everyone has their own room, TV and loads of movies.  Home made meals of course.  I also take them to their appointments and their shopping.', 'Waddell Residence/hobby farm', NULL, NULL, 'fr'),
(93, 47, 'Living Hope Special Care Home', 'Living Hope Special Care Home an 8 bed facility located in beautiful Picadilly NB, just 10 minutes outside of Sussex. We strive to be a home where residents want to live and staff choose to work.  We are an 8 bed level 2 care home.   At Living Hope Special Care Home we are committed to providing you and your family with the same care that we would expect for ourselves and our own families.', 'Living Hope Special Care Home', NULL, NULL, 'en'),
(94, 47, 'Living Hope Special Care Home', 'Living Hope Special Care Home an 8 bed facility located in beautiful Picadilly NB, just 10 minutes outside of Sussex. We strive to be a home where residents want to live and staff choose to work.  We are an 8 bed level 2 care home.   At Living Hope Special Care Home we are committed to providing you and your family with the same care that we would expect for ourselves and our own families.', 'Living Hope Special Care Home', NULL, NULL, 'fr'),
(95, 48, 'Murray Street Lodge', 'Welcome to Murray Street Lodge Special Care Home, where your comfort and well-being are our number one priority. For over 10 years we have remained dedicated to providing the highest level of care possible for our residents. Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help! Description of Services: Our home is located in Grand Bay-Westfield, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices. We provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc. Programming: Residents are encouraged to be active and stay involved in community programs and events.We utilize dedicated volunteers to enhance our weekly activities. Level of Care: Our areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. We are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies. Credentials: Heather Perrin has operated this home for 10 years. Our home is licensed and inspected, by the Department of Social Development. Our personnel are fully qualified according to provincial standards and regulations. We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', 'Murray Street Lodge', NULL, NULL, 'en'),
(96, 48, 'Murray Street Lodge', 'Welcome to Murray Street Lodge Special Care Home, where your comfort and well-being are our number one priority. For over 10 years we have remained dedicated to providing the highest level of care possible for our residents. Our smaller comfortable setting offers you and your family a more intimate and accessible experience to care. When staying at home is no longer an option, or you just need temporary accommodations, let us help! Description of Services: Our home is located in Grand Bay-Westfield, a short drive from West Saint John. This provides easy access to doctors, dentists, churches, pharmacies, community centers, walking trails and post offices. We provide 24-hour care and supervision for a wide range of physical, social, medical and mental health needs. This includes full medication administration, all personal care, housekeeping, laundry, meals and snacks, etc. Programming: Residents are encouraged to be active and stay involved in community programs and events.We utilize dedicated volunteers to enhance our weekly activities. Level of Care: Our areas of experience include oxygen use, diabetes management, mild to moderate dementia, multiple sclerosis, epilepsy, catheter & ostomy care, MRSA, incontinence, congestive heart failure, mobility issues, wound care, and various mental health conditions, etc. We are approved to offer long term or short term accommodations. Temporary placement for relief/respite or convalescent care is available depending upon existing vacancies. Credentials: Heather Perrin has operated this home for 10 years. Our home is licensed and inspected, by the Department of Social Development. Our personnel are fully qualified according to provincial standards and regulations. We also have regular inspections, and adhere to all requirements, of the provincial Fire Marshall\'s office and Public Health & Safety Department.', 'Murray Street Lodge', NULL, NULL, 'fr'),
(97, 49, 'METCALF MANOR', 'WE ARE HERE TO HELP THOSE WHO NEED DIRECTION WITH LIFE SKILLS, MEDICATION REMINDERS, ASSISTING WITH PERSONAL CARE, ORGANIZING AND GETTING TO APPOINTMENTS, MEALS AND COMPANIONSHIP.', 'METCALF MANOR', NULL, NULL, 'en'),
(98, 49, 'METCALF MANOR', 'WE ARE HERE TO HELP THOSE WHO NEED DIRECTION WITH LIFE SKILLS, MEDICATION REMINDERS, ASSISTING WITH PERSONAL CARE, ORGANIZING AND GETTING TO APPOINTMENTS, MEALS AND COMPANIONSHIP.', 'METCALF MANOR', NULL, NULL, 'fr'),
(99, 50, 'The Cedars', 'In floor heating, home cooked meals, country living on a large 2 acres secluded property within walking distance to all major restaurants, sprinkler and alarm system for safety, ongoing update for your comfort and convenience and last but definitely not least, staff that really care. Private and semi-private rooms, please contact us for availability!', 'The Cedars', NULL, NULL, 'en'),
(100, 50, 'The Cedars', 'In floor heating, home cooked meals, country living on a large 2 acres secluded property within walking distance to all major restaurants, sprinkler and alarm system for safety, ongoing update for your comfort and convenience and last but definitely not least, staff that really care. Private and semi-private rooms, please contact us for availability!', 'The Cedars', NULL, NULL, 'fr'),
(101, 51, 'Bartlett Gardens Care Home', 'Bartlett Gardens Care Home welcomes you to contact the home.', 'Bartlett Gardens Care Home', NULL, NULL, 'en'),
(102, 51, 'Bartlett Gardens Care Home', 'Bartlett Gardens Care Home welcomes you to contact the home.', 'Bartlett Gardens Care Home', NULL, NULL, 'fr'),
(103, 52, 'Coultons Special Care Home', 'We currently have 2 beds available (ladies only)', 'Coultons Special Care Home', NULL, NULL, 'en'),
(104, 52, 'Coultons Special Care Home', 'We currently have 2 beds available (ladies only)', 'Coultons Special Care Home', NULL, NULL, 'fr'),
(105, 53, 'Twin Towers Special Care Home', '.', 'Twin Towers Special Care Home', NULL, NULL, 'en'),
(106, 53, 'Twin Towers Special Care Home', '.', 'Twin Towers Special Care Home', NULL, NULL, 'fr'),
(107, 54, 'NORTH MINTO RESIDENCE', 'Long Term Care Assisted Living providing  care to Level 2 and Memory Care (3B) Clients. \r\nThe Residence is equipped with an elevator / six foot wide hallways adequate to accommodate wheelchairs and walkers \r\nPrivate and Semi Private rooms with washrooms and grab bars\r\nWhirl Pool Tub, large common area with comfortable chairs, TV and telephone access\r\nWheel Chair Ramps and pull cord alarm system \r\nHallways and common areas are equipped with security cameras\r\nEntry/Exit doors are equipped with door alarms leading to a secure court yard with gazebo and walking pathway \r\n\r\nServices offered: Bilingual  24 hour Supervised Care / Medication Dispensing / Health Clinics / Individualized Personal Care Plan / Health Records / Hygiene and Personal Care / Home Cooked Nutritional Meals / Relief Care / Daily Laundry Service / Daily Housekeeping Services / Medical Transportation  / Hair Care / Foot Care / Pastoral Care / Social Activities / Outings / Newspaper / Mail Delivery', 'NORTH MINTO RESIDENCE', NULL, NULL, 'en'),
(108, 54, 'NORTH MINTO RESIDENCE', 'Long Term Care Assisted Living providing  care to Level 2 and Memory Care (3B) Clients. \r\nThe Residence is equipped with an elevator / six foot wide hallways adequate to accommodate wheelchairs and walkers \r\nPrivate and Semi Private rooms with washrooms and grab bars\r\nWhirl Pool Tub, large common area with comfortable chairs, TV and telephone access\r\nWheel Chair Ramps and pull cord alarm system \r\nHallways and common areas are equipped with security cameras\r\nEntry/Exit doors are equipped with door alarms leading to a secure court yard with gazebo and walking pathway \r\n\r\nServices offered: Bilingual  24 hour Supervised Care / Medication Dispensing / Health Clinics / Individualized Personal Care Plan / Health Records / Hygiene and Personal Care / Home Cooked Nutritional Meals / Relief Care / Daily Laundry Service / Daily Housekeeping Services / Medical Transportation  / Hair Care / Foot Care / Pastoral Care / Social Activities / Outings / Newspaper / Mail Delivery', 'NORTH MINTO RESIDENCE', NULL, NULL, 'fr'),
(109, 55, 'Primrose Cottage Special Care Home', 'We provide holistic care to level 2 residents in a home-like setting. We excel in the care of the frail elderly, dementia care, and in end-of-life/palliative care. We also provide care to those with mental health needs. Residents and staff follow direction and guidance from owner and operator, Lynn Wallace, a registered of 40 years. We frequently receive residents post-hospitalization and are successful in rehabilitation. A variety of activities and services are offered, such as hair salon services, foot care services, art therapy, physical activity programming, animal therapy and so much more.', 'Primrose Cottage Special Care Home', NULL, NULL, 'en'),
(110, 55, 'Primrose Cottage Special Care Home', 'We provide holistic care to level 2 residents in a home-like setting. We excel in the care of the frail elderly, dementia care, and in end-of-life/palliative care. We also provide care to those with mental health needs. Residents and staff follow direction and guidance from owner and operator, Lynn Wallace, a registered of 40 years. We frequently receive residents post-hospitalization and are successful in rehabilitation. A variety of activities and services are offered, such as hair salon services, foot care services, art therapy, physical activity programming, animal therapy and so much more.', 'Primrose Cottage Special Care Home', NULL, NULL, 'fr'),
(111, 56, 'Countryside residence', 'Our 10 bed cozy atmosphere level 2 home is in a country setting with all private rooms , home cooked meals and hairdresser and doctor visits , nurse on staff , music and entertainment weekly bingo nights , a place to call home .', 'Countryside residence', NULL, NULL, 'en'),
(112, 56, 'Countryside residence', 'Our 10 bed cozy atmosphere level 2 home is in a country setting with all private rooms , home cooked meals and hairdresser and doctor visits , nurse on staff , music and entertainment weekly bingo nights , a place to call home .', 'Countryside residence', NULL, NULL, 'fr'),
(113, 57, 'Manor St. Jude care home', 'High reputation Licensed special care home . We provide 24 hours quality long / short term care for individuals with special needs or seniors, in a homey atmosphere with home cooked meals (4 meals a day). Medication reminded and delivery on time. All rooms are on one floor, Wheelchair accessible, private, quiet and spacious. Free laundry service and parking lots, close to bus stop, Location near by Hazen White-St. Francis School.  Welcome visit Manor St. Jude Care Home. 5066321888', 'Manor St. Jude care home', NULL, NULL, 'en');
INSERT INTO `residences_desc` (`desc_id`, `residence_id`, `name`, `description`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(114, 57, 'Manor St. Jude care home', 'High reputation Licensed special care home . We provide 24 hours quality long / short term care for individuals with special needs or seniors, in a homey atmosphere with home cooked meals (4 meals a day). Medication reminded and delivery on time. All rooms are on one floor, Wheelchair accessible, private, quiet and spacious. Free laundry service and parking lots, close to bus stop, Location near by Hazen White-St. Francis School.  Welcome visit Manor St. Jude Care Home. 5066321888', 'Manor St. Jude care home', NULL, NULL, 'fr'),
(115, 58, 'The Guardians Special Care Home Ltd.', 'The Guardians Special Care Home is a licensed level 2 special care home located on the Northside of Fredericton. The facility built in 2008-2009 has been in operation since August 2009, and is locally owned and operated. The Guardians strives to provide an enriched, healthy living experience for their residents. Nestled into Nashwaaksis The Guardians is close to many amenities including shopping malls, restaurants, bus stops, outreach programs, & convenience stores; greatly improving the opportunity for employment placements for those seeking work.  The residents enjoy the outdoor on-site pool during the summer months, are encouraged to join and participate in all activities be it singing, swimming, dancing, board/card games, karaoke, cooking, light chores, and many different Special Olympics sports & activities to name a few.  The home has a large communal living space with couches, chairs, & puzzle boards. A large Tv entertains the game show watchers by day and sport enthusiast by night. Directly beside the large open concept kitchen lies a large dining room to accommodate everyone during meal times. All staff are certified, friendly, humble, & keep the residents needs the priority.', 'The Guardians Special Care Home Ltd.', NULL, NULL, 'en'),
(116, 58, 'The Guardians Special Care Home Ltd.', 'The Guardians Special Care Home is a licensed level 2 special care home located on the Northside of Fredericton. The facility built in 2008-2009 has been in operation since August 2009, and is locally owned and operated. The Guardians strives to provide an enriched, healthy living experience for their residents. Nestled into Nashwaaksis The Guardians is close to many amenities including shopping malls, restaurants, bus stops, outreach programs, & convenience stores; greatly improving the opportunity for employment placements for those seeking work.  The residents enjoy the outdoor on-site pool during the summer months, are encouraged to join and participate in all activities be it singing, swimming, dancing, board/card games, karaoke, cooking, light chores, and many different Special Olympics sports & activities to name a few.  The home has a large communal living space with couches, chairs, & puzzle boards. A large Tv entertains the game show watchers by day and sport enthusiast by night. Directly beside the large open concept kitchen lies a large dining room to accommodate everyone during meal times. All staff are certified, friendly, humble, & keep the residents needs the priority.', 'The Guardians Special Care Home Ltd.', NULL, NULL, 'fr'),
(117, 59, 'Canterbury Hall', 'Canterbury Hall is a licensed special care home located on the Parkland Riverview Campus. We provide care for those individuals requiring level 2 care. All the units are private sleeping units with the majority of the apartments having full private washrooms with full walk-in showers with seats. A small fridge (with freezer) is provided as well as local phone, cable and internet.  We also have our own emergency pendent system. There is a dining room, living room and nurses station on each floor, so everything a resident needs is on the floor in which they reside. There are outside sitting areas, paved walking trail as well as a gazebo and fish pond, with a water fall,  to enjoy', 'Canterbury Hall', NULL, NULL, 'en'),
(118, 59, 'Canterbury Hall', 'Canterbury Hall is a licensed special care home located on the Parkland Riverview Campus. We provide care for those individuals requiring level 2 care. All the units are private sleeping units with the majority of the apartments having full private washrooms with full walk-in showers with seats. A small fridge (with freezer) is provided as well as local phone, cable and internet.  We also have our own emergency pendent system. There is a dining room, living room and nurses station on each floor, so everything a resident needs is on the floor in which they reside. There are outside sitting areas, paved walking trail as well as a gazebo and fish pond, with a water fall,  to enjoy', 'Canterbury Hall', NULL, NULL, 'fr'),
(119, 60, 'Enhanced Living Gagetown', 'Here at Enhanced Living Gagetown we are a memory care facility with 27 beds. We are located in the Village of Gagetown, surrounded by nature with a large open backyard for residents to enjoy. The lovely thing about being in a small town is that our staff turnover is low and our community involvement is high.', 'Enhanced Living Gagetown', NULL, NULL, 'en'),
(120, 60, 'Enhanced Living Gagetown', 'Here at Enhanced Living Gagetown we are a memory care facility with 27 beds. We are located in the Village of Gagetown, surrounded by nature with a large open backyard for residents to enjoy. The lovely thing about being in a small town is that our staff turnover is low and our community involvement is high.', 'Enhanced Living Gagetown', NULL, NULL, 'fr'),
(121, 61, 'Howe Hall', 'Our Assisted Living suites are designed to meet the needs of those with physical or mild cognitive challenges, as well provide an enjoyable lifestyle, courtesy of all of Parkland’s amenities and activities.\r\n•	Three daily meals made to accommodate special dietary preferences\r\n•	Weekly housekeeping, including linen and personal laundry service\r\n•	All utilities, including heat, hot water and electricity\r\n•	Local telephone, cable service and Wi-Fi\r\n•	Chauffeur transportation service\r\n•	Concierge service\r\n•	Outdoor parking\r\n•	Specialized recreation programs and social calendar\r\n•	Individualized personal care plan to support daily living activities\r\n•	Medication management\r\n•	Assistance with personal care\r\n•	Annual home health record update and Personal Wellness Review\r\n•	24-hour monitored, interactive emergency response system with personal pendant included\r\n•	One easy bill per month\r\n•	Spacious, fully accessible suites\r\n•	Kitchenette with fridge\r\n•	In-suite climate control\r\n•	Spacious washrooms with seated walk-in shower\r\n•	Comforting environments:\r\n•	Secure environment with monitored access\r\n•	Team members available 24/7\r\n•	Dining and recreation on the same floor as private suite', 'Howe Hall', NULL, NULL, 'en'),
(122, 61, 'Howe Hall', 'Our Assisted Living suites are designed to meet the needs of those with physical or mild cognitive challenges, as well provide an enjoyable lifestyle, courtesy of all of Parkland’s amenities and activities.\r\n•	Three daily meals made to accommodate special dietary preferences\r\n•	Weekly housekeeping, including linen and personal laundry service\r\n•	All utilities, including heat, hot water and electricity\r\n•	Local telephone, cable service and Wi-Fi\r\n•	Chauffeur transportation service\r\n•	Concierge service\r\n•	Outdoor parking\r\n•	Specialized recreation programs and social calendar\r\n•	Individualized personal care plan to support daily living activities\r\n•	Medication management\r\n•	Assistance with personal care\r\n•	Annual home health record update and Personal Wellness Review\r\n•	24-hour monitored, interactive emergency response system with personal pendant included\r\n•	One easy bill per month\r\n•	Spacious, fully accessible suites\r\n•	Kitchenette with fridge\r\n•	In-suite climate control\r\n•	Spacious washrooms with seated walk-in shower\r\n•	Comforting environments:\r\n•	Secure environment with monitored access\r\n•	Team members available 24/7\r\n•	Dining and recreation on the same floor as private suite', 'Howe Hall', NULL, NULL, 'fr'),
(123, 62, 'Swim\'s Adult Residential Facility', 'We strive to meet the individual daily needs of our guests in a secure safe environment.  Their care plans will enable them to have the best quality of living with all due considerations of their strengths and inabilities.  We provide a country living atmosphere with all conveniences within a 8-12 minute drive.', 'Swim\'s Adult Residential Facility', NULL, NULL, 'en'),
(124, 62, 'Swim\'s Adult Residential Facility', 'We strive to meet the individual daily needs of our guests in a secure safe environment.  Their care plans will enable them to have the best quality of living with all due considerations of their strengths and inabilities.  We provide a country living atmosphere with all conveniences within a 8-12 minute drive.', 'Swim\'s Adult Residential Facility', NULL, NULL, 'fr'),
(125, 63, 'Alvina\'c Care Home', '25 minutes from St Peters in a beautiful country setting, Family style care, friendly, loving home. Outgoing and activity orientated staff. Family is always welcome.  Bilingual Home with 25 years of experience.', 'Alvina\'c Care Home', NULL, NULL, 'en'),
(126, 63, 'Alvina\'c Care Home', '25 minutes from St Peters in a beautiful country setting, Family style care, friendly, loving home. Outgoing and activity orientated staff. Family is always welcome.  Bilingual Home with 25 years of experience.', 'Alvina\'c Care Home', NULL, NULL, 'fr'),
(127, 64, 'Care A Lot Special Care Home', 'Located in upper west side, in a quiet part of town. Activity orientated staff, we have a great walking area for our residents to enjoy. Home away from home. Wifi tv in each room', 'Care A Lot Special Care Home', NULL, NULL, 'en'),
(128, 64, 'Care A Lot Special Care Home', 'Located in upper west side, in a quiet part of town. Activity orientated staff, we have a great walking area for our residents to enjoy. Home away from home. Wifi tv in each room', 'Care A Lot Special Care Home', NULL, NULL, 'fr'),
(129, 65, 'CurtLin Manor', 'Beautiful country setting home, with highly trained staff. Surrounded by nature, and just a short drive to grocery stores, pharmacies, churches, schools, and so much more.', 'CurtLin Manor', NULL, NULL, 'en'),
(130, 65, 'CurtLin Manor', 'Beautiful country setting home, with highly trained staff. Surrounded by nature, and just a short drive to grocery stores, pharmacies, churches, schools, and so much more.', 'CurtLin Manor', NULL, NULL, 'fr'),
(131, 66, 'Hawthorne Place', 'Located in the town of Hartland, not far from the Upper River Valley Hospital,  close to the Hartland community school, close to stores, friendly staff, activity orientated, and fun loving environment! We love to do excursions, and field trips!', 'Hawthorne Place', NULL, NULL, 'en'),
(132, 66, 'Hawthorne Place', 'Located in the town of Hartland, not far from the Upper River Valley Hospital,  close to the Hartland community school, close to stores, friendly staff, activity orientated, and fun loving environment! We love to do excursions, and field trips!', 'Hawthorne Place', NULL, NULL, 'fr'),
(133, 67, 'Ridgeview Manor', 'Quiet country setting, it is a place where our residences can walk freely, and enjoy nature. Home away from home. Midst of blueberry country.  We have a big beautiful garden as well.', 'Ridgeview Manor', NULL, NULL, 'en'),
(134, 67, 'Ridgeview Manor', 'Quiet country setting, it is a place where our residences can walk freely, and enjoy nature. Home away from home. Midst of blueberry country.  We have a big beautiful garden as well.', 'Ridgeview Manor', NULL, NULL, 'fr'),
(135, 68, 'Sea Street Manor', 'Beautiful view of the Bay of Fundy, and partridge island.', 'Sea Street Manor', NULL, NULL, 'en'),
(136, 68, 'Sea Street Manor', 'Beautiful view of the Bay of Fundy, and partridge island.', 'Sea Street Manor', NULL, NULL, 'fr'),
(137, 69, 'Collingwood Rest Home', 'Country setting home, with friendly staff.  Home away from home.', 'Collingwood Rest Home', NULL, NULL, 'en'),
(138, 69, 'Collingwood Rest Home', 'Country setting home, with friendly staff.  Home away from home.', 'Collingwood Rest Home', NULL, NULL, 'fr'),
(139, 70, 'McNair Manor', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor', NULL, NULL, 'en'),
(140, 70, 'McNair Manor', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor', NULL, NULL, 'fr'),
(141, 71, 'Fundy Bay Manor', '*', 'Fundy Bay Manor', NULL, NULL, 'en'),
(142, 71, 'Fundy Bay Manor', '*', 'Fundy Bay Manor', NULL, NULL, 'fr'),
(143, 72, 'Smith Special Care Home', '*', 'Smith Special Care Home', NULL, NULL, 'en'),
(144, 72, 'Smith Special Care Home', '*', 'Smith Special Care Home', NULL, NULL, 'fr'),
(145, 73, 'Baycare Adult Residential Facility', 'Baycare is a bright, spacious facility which caters to the varying needs of its residents through a diverse and dynamic staff.  \r\nBaycare provides a family atmosphere for its residents and takes every effort to integrate newcomers in to the family mix.  \r\nHome cooked meals and individualized care plans help to underscore the fact that at Baycare, our residents are number one.\r\nIf you have any further questions, please feel free to contact Joel at 658-0991.', 'Baycare Adult Residential Facility', NULL, NULL, 'en'),
(146, 73, 'Baycare Adult Residential Facility', 'Baycare is a bright, spacious facility which caters to the varying needs of its residents through a diverse and dynamic staff.  \r\nBaycare provides a family atmosphere for its residents and takes every effort to integrate newcomers in to the family mix.  \r\nHome cooked meals and individualized care plans help to underscore the fact that at Baycare, our residents are number one.\r\nIf you have any further questions, please feel free to contact Joel at 658-0991.', 'Baycare Adult Residential Facility', NULL, NULL, 'fr'),
(147, 74, 'Fairvilla Special Care Home', 'Large backyard, and porch to enjoy. Private rooms.  Wifi, tv, and cable provided by facility. Short distance from Lancaster mall, and our facility is on a bus route. Wheel chair accessible facility. Excellent food menu. Charming staff.', 'Fairvilla Special Care Home', NULL, NULL, 'en'),
(148, 74, 'Fairvilla Special Care Home', 'Large backyard, and porch to enjoy. Private rooms.  Wifi, tv, and cable provided by facility. Short distance from Lancaster mall, and our facility is on a bus route. Wheel chair accessible facility. Excellent food menu. Charming staff.', 'Fairvilla Special Care Home', NULL, NULL, 'fr'),
(149, 75, 'Crescent Gardens Guest Home', '2 Occupied beds.  1 Empty bed.  All rooms are single occupancy.  Home is located on a cul-de-sac overlooking the\r\nSt. John River with views of the Hugh John Bridge.', 'Crescent Gardens Guest Home', NULL, NULL, 'en'),
(150, 75, 'Crescent Gardens Guest Home', '2 Occupied beds.  1 Empty bed.  All rooms are single occupancy.  Home is located on a cul-de-sac overlooking the\r\nSt. John River with views of the Hugh John Bridge.', 'Crescent Gardens Guest Home', NULL, NULL, 'fr'),
(151, 76, 'Hearne street residence', 'Family setting and comfort for those with mental health conditions.', 'Hearne street residence', NULL, NULL, 'en'),
(152, 76, 'Hearne street residence', 'Family setting and comfort for those with mental health conditions.', 'Hearne street residence', NULL, NULL, 'fr'),
(153, 77, 'Hanwell Special Care and Senior Home', 'Hanwell Special Care Home is a twenty bed special care home located in Fredericton, New Brunswick.', 'Hanwell Special Care and Senior Home', NULL, NULL, 'en'),
(154, 77, 'Hanwell Special Care and Senior Home', 'Hanwell Special Care Home is a twenty bed special care home located in Fredericton, New Brunswick.', 'Hanwell Special Care and Senior Home', NULL, NULL, 'fr'),
(155, 78, 'Autumn Lee Retirement', 'Autumn Lee Retirement home is a 45 licensed bed home located in Moncton New Brunswick.', 'Autumn Lee Retirement', NULL, NULL, 'en'),
(156, 78, 'Autumn Lee Retirement', 'Autumn Lee Retirement home is a 45 licensed bed home located in Moncton New Brunswick.', 'Autumn Lee Retirement', NULL, NULL, 'fr'),
(157, 79, 'Smiths Special Care Home', 'Smith Special Care home is located off West Main Street in the desirable Jones Lake area. It is on a quiet street, close to bus routes and amenities. Our ten bed fully licensed facility has a lovely green space with a vegetable garden that is used to cook our home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TC, cable and internet access. Smith Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nSmith Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', 'Smiths Special Care Home', NULL, NULL, 'en'),
(158, 79, 'Smiths Special Care Home', 'Smith Special Care home is located off West Main Street in the desirable Jones Lake area. It is on a quiet street, close to bus routes and amenities. Our ten bed fully licensed facility has a lovely green space with a vegetable garden that is used to cook our home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TC, cable and internet access. Smith Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nSmith Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', 'Smiths Special Care Home', NULL, NULL, 'fr'),
(159, 80, 'Blackville Special Care Home', '9 bed care home in quite village of Blackville. Across the street from pharmacy and beautiful walking trail in the back that leads to local park. \r\nTransportation to appointments and the ability to keep your family doctor.\r\nSingle and double room available and satellite tv in all rooms.', 'Blackville Special Care Home', NULL, NULL, 'en'),
(160, 80, 'Blackville Special Care Home', '9 bed care home in quite village of Blackville. Across the street from pharmacy and beautiful walking trail in the back that leads to local park. \r\nTransportation to appointments and the ability to keep your family doctor.\r\nSingle and double room available and satellite tv in all rooms.', 'Blackville Special Care Home', NULL, NULL, 'fr'),
(161, 81, 'Dobbelsteyn Care Home', 'Welcome to Dobbelsteyn Care Home. A family owned and operated Level 2 Special Care Home since 1995. Enjoy a large spacious facility built in September 2011. All rooms are all private, some.with private half bath. Lots of in house activities and plenty of space outside to sit and enjoy warm sunny days. Excellent home cooked meals, a family atmosphere with kind and friendly staff.', 'Dobbelsteyn Care Home', NULL, NULL, 'en'),
(162, 81, 'Dobbelsteyn Care Home', 'Welcome to Dobbelsteyn Care Home. A family owned and operated Level 2 Special Care Home since 1995. Enjoy a large spacious facility built in September 2011. All rooms are all private, some.with private half bath. Lots of in house activities and plenty of space outside to sit and enjoy warm sunny days. Excellent home cooked meals, a family atmosphere with kind and friendly staff.', 'Dobbelsteyn Care Home', NULL, NULL, 'fr'),
(163, 82, '44 Wildwood Drive', 'A level 4 facility that provides support to clients from the Departments of Social Development and Mental Health.', '44 Wildwood Drive', NULL, NULL, 'en'),
(164, 82, '44 Wildwood Drive', 'A level 4 facility that provides support to clients from the Departments of Social Development and Mental Health.', '44 Wildwood Drive', NULL, NULL, 'fr'),
(165, 83, 'Silver Fox Special Care Home', 'Silver Fox Special Care Home consists of two facilities offering 24 hour care for residents requiring Level 1 & 2 care needs accepting individuals with mental health concerns and senior residents. Our facilities offer home-like environments in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, etc.', 'Silver Fox Special Care Home', NULL, NULL, 'en'),
(166, 83, 'Silver Fox Special Care Home', 'Silver Fox Special Care Home consists of two facilities offering 24 hour care for residents requiring Level 1 & 2 care needs accepting individuals with mental health concerns and senior residents. Our facilities offer home-like environments in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, etc.', 'Silver Fox Special Care Home', NULL, NULL, 'fr'),
(167, 84, 'LJ Jaillet Residence Inc.', 'We are a level 2 Special Care Home.', 'LJ Jaillet Residence Inc.', NULL, NULL, 'en'),
(168, 84, 'LJ Jaillet Residence Inc.', 'We are a level 2 Special Care Home.', 'LJ Jaillet Residence Inc.', NULL, NULL, 'fr'),
(169, 85, 'Alternative Residences Alternatives', 'Alternative Residences Alternatives Inc. was first incorporated under the New Brunswick Companies Act in August of 1984 and today acts as the largest charitable organization in Greater Moncton that provides shelter, support services and amenities for those individuals dealing with mental illness.\r\n\r\nThe very existence of the organization is the result of numerous hours of volunteer work by dedicated Mental Health professionals and concerned citizens who voiced the need for an alternative to the institutional options available to the mentally ill. Today, we carry on that mission to better the lives of those individuals dealing with mental illness in our community.\r\n\r\nWe are a registered, not for profit charity. We partner with the two Regional Health Authorities, Social Development, as well as other community agencies such as CMHA.\r\n\r\nOur  mission is to provide a continuum of community-based housing and support services, with a recovery-oriented focus, providing individualized and client-centered services by working in collaboration with our partners in the addiction and mental health field.\"', 'Alternative Residences Alternatives', NULL, NULL, 'en'),
(170, 85, 'Alternative Residences Alternatives', 'Alternative Residences Alternatives Inc. was first incorporated under the New Brunswick Companies Act in August of 1984 and today acts as the largest charitable organization in Greater Moncton that provides shelter, support services and amenities for those individuals dealing with mental illness.\r\n\r\nThe very existence of the organization is the result of numerous hours of volunteer work by dedicated Mental Health professionals and concerned citizens who voiced the need for an alternative to the institutional options available to the mentally ill. Today, we carry on that mission to better the lives of those individuals dealing with mental illness in our community.\r\n\r\nWe are a registered, not for profit charity. We partner with the two Regional Health Authorities, Social Development, as well as other community agencies such as CMHA.\r\n\r\nOur  mission is to provide a continuum of community-based housing and support services, with a recovery-oriented focus, providing individualized and client-centered services by working in collaboration with our partners in the addiction and mental health field.\"', 'Alternative Residences Alternatives', NULL, NULL, 'fr'),
(171, 86, 'The Briarlea on Ryan level 2', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan level 2', NULL, NULL, 'en'),
(172, 86, 'The Briarlea on Ryan level 2', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan level 2', NULL, NULL, 'fr'),
(173, 87, 'The Briarlea on Ryan 3B', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan 3B', NULL, NULL, 'en'),
(174, 87, 'The Briarlea on Ryan 3B', 'The Briarlea offers progressive care levels; 10 level 2 rooms, 6 level 3B rooms, and 18 level 3G rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea on Ryan 3B', NULL, NULL, 'fr'),
(175, 88, 'The Briarlea off Gorge Level 2', 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea off Gorge Level 2', NULL, NULL, 'en'),
(176, 88, 'The Briarlea off Gorge Level 2', 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea off Gorge Level 2', NULL, NULL, 'fr'),
(177, 89, 'The Briarlea off Gorge Level 3B', 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea off Gorge Level 3B', NULL, NULL, 'en'),
(178, 89, 'The Briarlea off Gorge Level 3B', 'The Briarlea offers progressive care levels; 8 assisted-living apartments, 24 level 2 rooms, and 12 level 3B rooms, as well as palliative care services.  Doctor Pierre Beaulieu owns The Briarlea and will gladly take on all residents as his patients. A full time Activity Coordinator, Certified Chefs, an LPN, and highly qualified caregivers and other service providers all work together to ensure a higher level of care to our seniors.', 'The Briarlea off Gorge Level 3B', NULL, NULL, 'fr'),
(179, 90, 'Residence Collette', 'Residence Collette is located in downtown Moncton close to bus routes and all amenities. Our eighteen bed fully licensed facility is a very quiet home despite in the downtown core. We offer home cooked meal that are tailored to you (diabetic, low salt, etc)\r\n\r\nWe have a cozy common area that has comfortable couches and a TV – each bedroom has a TV, cable and internet access. Residence Collette also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nResidence Collette is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', 'Residence Collette', NULL, NULL, 'en'),
(180, 90, 'Residence Collette', 'Residence Collette is located in downtown Moncton close to bus routes and all amenities. Our eighteen bed fully licensed facility is a very quiet home despite in the downtown core. We offer home cooked meal that are tailored to you (diabetic, low salt, etc)\r\n\r\nWe have a cozy common area that has comfortable couches and a TV – each bedroom has a TV, cable and internet access. Residence Collette also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nResidence Collette is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health', 'Residence Collette', NULL, NULL, 'fr'),
(181, 91, 'DALY\'S HOME CARE INC.', 'Daly’s Special Care Home is located on a quiet crescent in Riverview close to a bus route and amenities. Our fully licensed ten bed facility has a very large back yard with a swing to read your favourite book on. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable couches and TV – each bedroom has a TV, cable and internet access. Daley Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nDaley’s Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', 'DALY\'S HOME CARE INC.', NULL, NULL, 'en'),
(182, 91, 'DALY\'S HOME CARE INC.', 'Daly’s Special Care Home is located on a quiet crescent in Riverview close to a bus route and amenities. Our fully licensed ten bed facility has a very large back yard with a swing to read your favourite book on. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable couches and TV – each bedroom has a TV, cable and internet access. Daley Special Care Home also offers personal care services such as laundry services, personal care, medication and diabetic management.\r\n\r\nDaley’s Special Care Home is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', 'DALY\'S HOME CARE INC.', NULL, NULL, 'fr'),
(183, 92, 'Residence Adventure', 'Residence Aventure Inc is located in beautiful Irishtown just outside the Moncton City limits not far from the Irishtown Nature Park. Our thirty bed fully licensed facility has wheelchair accessibility and lots of green space, vegetables gardens and a farm just around the corner. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TV, cable, internet access. They also have safety measures such as an emergency bell and grip bars.\r\n\r\nResidence Aventure Inc also offers personal care services such as laundry services, personal care, medication and diabetic management.  Residence Aventure is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', 'Residence Adventure', NULL, NULL, 'en'),
(184, 92, 'Residence Adventure', 'Residence Aventure Inc is located in beautiful Irishtown just outside the Moncton City limits not far from the Irishtown Nature Park. Our thirty bed fully licensed facility has wheelchair accessibility and lots of green space, vegetables gardens and a farm just around the corner. We offer home cooked meals that are tailored to you (diabetic, low salt, etc).\r\n\r\nWe have a cozy common area that has comfortable chairs and a TV – each bedroom has a TV, cable, internet access. They also have safety measures such as an emergency bell and grip bars.\r\n\r\nResidence Aventure Inc also offers personal care services such as laundry services, personal care, medication and diabetic management.  Residence Aventure is inspected yearly by the Department of Social Development as well as the Fire Inspector and the Department of Health.', 'Residence Adventure', NULL, NULL, 'fr'),
(185, 93, '69 Beardsley Road', 'A facility that provides level 4 care to clients referred from Departments of Social Development and Mental Health.', '69 Beardsley Road', NULL, NULL, 'en'),
(186, 93, '69 Beardsley Road', 'A facility that provides level 4 care to clients referred from Departments of Social Development and Mental Health.', '69 Beardsley Road', NULL, NULL, 'fr'),
(187, 94, '119 Broadway', 'A facility that provides level 4 care to clients referred from the Departments of Social Development and Mental Health.', '119 Broadway', NULL, NULL, 'en'),
(188, 94, '119 Broadway', 'A facility that provides level 4 care to clients referred from the Departments of Social Development and Mental Health.', '119 Broadway', NULL, NULL, 'fr'),
(189, 95, '117 Broadway', '117 is a level 4 facility providing care to clients referred from the Departments of Social Development and Mental Health.', '117 Broadway', NULL, NULL, 'en'),
(190, 95, '117 Broadway', '117 is a level 4 facility providing care to clients referred from the Departments of Social Development and Mental Health.', '117 Broadway', NULL, NULL, 'fr'),
(191, 96, 'MacLeods Too Inc', 'We are a level 4 home located in the heart of Hartland.  We provide ourselves on the level of care we provide to our residents.  Please reach out to us if you are looking for a placement for your loved one.  We would be happy to hear from you.', 'MacLeods Too Inc', NULL, NULL, 'en'),
(192, 96, 'MacLeods Too Inc', 'We are a level 4 home located in the heart of Hartland.  We provide ourselves on the level of care we provide to our residents.  Please reach out to us if you are looking for a placement for your loved one.  We would be happy to hear from you.', 'MacLeods Too Inc', NULL, NULL, 'fr'),
(193, 97, 'Country Lane Estates NB Inc', 'We are a level 2 home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Country Lane Estates NB Inc', NULL, NULL, 'en'),
(194, 97, 'Country Lane Estates NB Inc', 'We are a level 2 home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Country Lane Estates NB Inc', NULL, NULL, 'fr'),
(195, 98, 'Country Lane Estates NB Inc', 'We are a level 3B home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Country Lane Estates NB Inc', NULL, NULL, 'en'),
(196, 98, 'Country Lane Estates NB Inc', 'We are a level 3B home located in the heart of Burton. We are under new ownership and likewise to our other facilities, we provide ourselves on the level of care we provide to our residents. Please reach out to us if you are looking for a placement for your loved one. We would be happy to hear from you.', 'Country Lane Estates NB Inc', NULL, NULL, 'fr'),
(197, 99, 'Goguen Residence 621090NB INC', '-', 'Goguen Residence 621090NB INC', NULL, NULL, 'en'),
(198, 99, 'Goguen Residence 621090NB INC', '-', 'Goguen Residence 621090NB INC', NULL, NULL, 'fr'),
(199, 100, 'Goguen Residence Inc', '-', 'Goguen Residence Inc', NULL, NULL, 'en'),
(200, 100, 'Goguen Residence Inc', '-', 'Goguen Residence Inc', NULL, NULL, 'fr'),
(201, 101, 'McNair Manor Level 3G, Moncton', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor Level 3G, Moncton', NULL, NULL, 'en'),
(202, 101, 'McNair Manor Level 3G, Moncton', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor Level 3G, Moncton', NULL, NULL, 'fr'),
(203, 102, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor Level 3B, Riverview', NULL, NULL, 'en'),
(204, 102, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', 'McNair Manor Level 3B, Riverview', NULL, NULL, 'fr'),
(205, 103, 'Green Meadows Special Care Home - Berwick', 'Relaxing country living close to town. Berwick offers our residents raised garden beds, a pond to relax by and the efficiency of being close to town.', 'Green Meadows Special Care Home - Berwick', NULL, NULL, 'en'),
(206, 103, 'Green Meadows Special Care Home - Berwick', 'Relaxing country living close to town. Berwick offers our residents raised garden beds, a pond to relax by and the efficiency of being close to town.', 'Green Meadows Special Care Home - Berwick', NULL, NULL, 'fr'),
(207, 104, 'Green Meadows Special Care Home - Belleisle', 'Scenic and spacious, Belleisle is a beautiful place to call home. With large rooms, a gazebo and front garden, Belleisle has much to offer you or your loved ones.', 'Green Meadows Special Care Home - Belleisle', NULL, NULL, 'en'),
(208, 104, 'Green Meadows Special Care Home - Belleisle', 'Scenic and spacious, Belleisle is a beautiful place to call home. With large rooms, a gazebo and front garden, Belleisle has much to offer you or your loved ones.', 'Green Meadows Special Care Home - Belleisle', NULL, NULL, 'fr'),
(209, 105, 'Open Arms Special Care Home', NULL, 'Open Arms Special Care Home', NULL, NULL, 'en'),
(210, 105, 'Open Arms Special Care Home', NULL, 'Open Arms Special Care Home', NULL, NULL, 'fr'),
(211, 106, 'Silver Fox Estate', 'Silver Fox Estate is a retirement living home offering 24 hour care for residents requiring Level 1 & 2 care needs. Our facility offers a home-like environment in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care and spiritual services. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, floor curling, iPad training, etc.', 'Silver Fox Estate', NULL, NULL, 'en'),
(212, 106, 'Silver Fox Estate', 'Silver Fox Estate is a retirement living home offering 24 hour care for residents requiring Level 1 & 2 care needs. Our facility offers a home-like environment in a quiet country setting. Our services include specialized meals for residents needs, transportation to medical appointments, administering of medication, in house hair care, nail care, foot care and spiritual services. A wide range of activities include musical entertainment, crafting, card making, movie nights, bingo, outings, BBQ\'s, outdoor games, floor curling, iPad training, etc.', 'Silver Fox Estate', NULL, NULL, 'fr'),
(213, 107, 'Paradise Villa', 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping, churches, bus route, and a short drive to downtown Fredericton. Our new state of the art assisted living Senior Residence Complex truly defines what seniors living should be. Thoughtfully designed and beautifully executed, this well-appointed residence offers 78 single first-class suites, and 4 of the 78 can be converted into suites for couples or siblings. This complex cares for level 2 and 3b residents. This property is very well-managed with experienced and committed staff.', 'Paradise Villa', NULL, NULL, 'en'),
(214, 107, 'Paradise Villa', 'Paradise Villa Inc. is nestled in a country-like setting conveniently located near shopping, churches, bus route, and a short drive to downtown Fredericton. Our new state of the art assisted living Senior Residence Complex truly defines what seniors living should be. Thoughtfully designed and beautifully executed, this well-appointed residence offers 78 single first-class suites, and 4 of the 78 can be converted into suites for couples or siblings. This complex cares for level 2 and 3b residents. This property is very well-managed with experienced and committed staff.', 'Paradise Villa', NULL, NULL, 'fr'),
(215, 108, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(216, 108, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(217, 109, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(218, 109, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(219, 110, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(220, 110, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(221, 111, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(222, 111, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(223, 112, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(224, 112, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(225, 113, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(226, 113, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(227, 114, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(228, 114, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr'),
(229, 115, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(230, 115, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr');
INSERT INTO `residences_desc` (`desc_id`, `residence_id`, `name`, `description`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(231, 116, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'en'),
(232, 116, 'McNair Manor Level 3B, Riverview', 'Compassion, Dignity and Care -- Leaders in Long-term Care for 25 Years\r\nCare Attendants, 24 hours/day\r\nSkilled Nursing and Medical Case Management\r\nHair Care\r\nFootcare\r\nHousekeeping\r\nHome Cooked Meals\r\nActivities Program \r\nDoctor Appointments\r\nCare Levels 2, 3B, 3G \r\nProvincial Transitional Bed Program\r\nShort-term Relief Care', NULL, NULL, NULL, 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `title` varchar(300) NOT NULL,
  `settingkey` varchar(300) NOT NULL,
  `settingtype` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `parent`, `title`, `settingkey`, `settingtype`, `sort_order`, `status`) VALUES
(1, 14, 'Site Name', 'SITE_NAME', 'text', 0, 'Y'),
(2, 14, 'Admin Email', 'ADMIN_EMAIL', 'text', 0, 'Y'),
(3, 14, 'From Mail Address', 'FROM_MAIL', 'text', 0, 'Y'),
(4, 14, 'Support Phone', 'SUPPORT_PHONE', 'text', 0, 'Y'),
(5, 15, 'Meta Title', 'DEFAULT_META_TITLE', 'text', 0, 'Y'),
(6, 15, 'Meta Desc', 'DEFAULT_META_DESCRIPTION', 'textarea', 0, 'Y'),
(7, 15, 'Meta Keywords', 'DEFAULT_META_KEYWORDS', 'textarea', 0, 'Y'),
(8, 16, 'Mailer Protocol', 'MAILER_PROTOCOL', 'text', 0, 'Y'),
(9, 16, 'Mailer Host', 'MAILER_HOST', 'text', 0, 'Y'),
(10, 16, 'Mailer User', 'MAILER_USER', 'text', 0, 'Y'),
(11, 16, 'Mailer Password', 'MAILER_PASSWORD', 'text', 0, 'Y'),
(12, 16, 'Mailer Port', 'MAILER_PORT', 'text', 0, 'Y'),
(13, 16, 'Mailer Transport', 'MAILER_TRANSPORT', 'text', 0, 'Y'),
(14, 0, 'General', '', 'group', 1, 'Y'),
(15, 0, 'SEO', '', 'group', 2, 'Y'),
(16, 0, 'Mail', '', 'group', 3, 'Y'),
(17, 0, 'Theme', 'theme_group', 'group', 4, 'Y'),
(18, 17, 'Home Page', 'HOME_PAGE_ID', 'pages', 0, 'Y'),
(19, 17, '404 Error Page', 'ERROR_PAGE_ID', 'pages', 1, 'Y'),
(39, 17, 'Register Page', 'REGISTER_PAGE_ID', 'pages', 2, 'Y'),
(40, 0, 'Security', 'SECURITY_SETTINGS', 'group', 10, 'Y'),
(41, 40, 'reCpatcha Site Key', 'RECAPTCHA_SITE_KEY', 'text', 1, 'Y'),
(42, 40, 'reCpatcha Secret Key', 'RECAPTCHA_SECRET_KEY', 'text', 2, 'Y'),
(44, 17, 'Residence Page', 'RESIDENCE_PAGE_ID', 'pages', 4, 'Y'),
(45, 17, 'Board Member Page', 'BOARD_PAGE_ID', 'pages', 5, 'Y'),
(46, 17, 'News Details Page', 'NEWS_PAGE_ID', 'pages', 6, 'Y'),
(47, 0, 'Contact Info', 'CONTACT_INFO', 'group', 10, 'Y'),
(48, 47, 'Footer Mission', 'FOOTER_MISSION', 'textarea', 1, 'Y'),
(49, 47, 'Contact Phone', 'CONTACT_PHONE', 'text', 2, 'Y'),
(50, 47, 'Contact Email', 'CONTACT_EMAIL', 'text', 3, 'Y'),
(51, 47, 'Contact Address', 'CONTACT_ADDRESS', 'textarea', 5, 'Y'),
(52, 47, 'Get In Touch', 'CONTACT_GETINTOUCH', 'textarea', 3, 'Y'),
(53, 0, 'Payment Settings', 'PAYMENT_SETTINGS', 'group', 10, 'Y'),
(54, 53, 'Cash or Cheque Message', 'CASH_CHEQUE_MESSAGE', 'text', 1, 'Y'),
(55, 53, 'eTransfer Message', 'ETRANSFER_MESSAGE', 'text', 2, 'Y'),
(56, 53, 'Payment Info', 'PAYMENT_INFO', 'text', 5, 'Y'),
(57, 14, 'Working Hours', 'WORKING_HOURS', 'text', 6, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `settings_desc`
--

CREATE TABLE `settings_desc` (
  `desc_id` int(11) NOT NULL,
  `setting_id` int(11) NOT NULL,
  `settingvalue` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings_desc`
--

INSERT INTO `settings_desc` (`desc_id`, `setting_id`, `settingvalue`, `language`) VALUES
(1, 1, 'The New Burnswick Special Care Home Association English', 'en'),
(2, 2, 'varunvictor007@gmail.com', 'en'),
(3, 3, 'admin@celiums.com', 'en'),
(4, 4, '1234567891', 'en'),
(5, 5, 'The New Burnswick Special Care Home Association', 'en'),
(6, 6, 'The New Burnswick Special Care Home Association', 'en'),
(7, 7, 'The New Burnswick Special Care Home Association', 'en'),
(8, 8, 'off', 'en'),
(9, 9, '', 'en'),
(10, 10, '', 'en'),
(11, 11, '', 'en'),
(12, 12, '', 'en'),
(13, 13, '', 'en'),
(14, 14, NULL, 'en'),
(15, 15, NULL, 'en'),
(16, 16, NULL, 'en'),
(17, 17, NULL, 'en'),
(18, 18, '1', 'en'),
(19, 19, '2', 'en'),
(20, 1, 'The New Burnswick Special Care Home Association French', 'fr'),
(21, 2, 'varunvictor007@gmail.com', 'fr'),
(22, 3, 'admin@celiums.com', 'fr'),
(23, 4, '1234567892', 'fr'),
(24, 5, 'The New Burnswick Special Care Home Association', 'fr'),
(25, 6, 'The New Burnswick Special Care Home Association', 'fr'),
(26, 7, 'The New Burnswick Special Care Home Association', 'fr'),
(27, 8, 'off', 'fr'),
(28, 9, '', 'fr'),
(29, 10, '', 'fr'),
(30, 11, '', 'fr'),
(31, 12, '', 'fr'),
(32, 13, '', 'fr'),
(33, 14, NULL, 'fr'),
(34, 15, NULL, 'fr'),
(35, 16, NULL, 'fr'),
(36, 17, NULL, 'fr'),
(37, 18, '1', 'fr'),
(38, 19, '2', 'fr'),
(39, 39, '3', 'en'),
(40, 39, '1', 'fr'),
(41, 40, '1', 'en'),
(42, 40, '1', 'fr'),
(43, 41, '6Le2JOYeAAAAAE-1NpTkW6Th8lv_W4OwbpZJtjcB', 'en'),
(44, 41, '6Le2JOYeAAAAAE-1NpTkW6Th8lv_W4OwbpZJtjcB', 'fr'),
(45, 42, '6Le2JOYeAAAAAHpIrWo6q4l0A86LWdcMXM7V9PC_', 'en'),
(46, 42, '6Le2JOYeAAAAAHpIrWo6q4l0A86LWdcMXM7V9PC_', 'fr'),
(49, 44, '12', 'en'),
(50, 44, '', 'fr'),
(51, 45, '11', 'en'),
(52, 45, '', 'fr'),
(53, 46, '10', 'en'),
(54, 46, '10', 'fr'),
(55, 47, '1', 'en'),
(56, 47, '1', 'fr'),
(57, 48, 'The New Brunswick Special Care Home Association Inc. aims to assist members in providing quality, cost effective services for seniors, mental health residents, and adults with disabilities in cooperation with the Department of Social Development.', 'en'),
(58, 48, 'The New Brunswick Special Care Home Association Inc. aims to assist members in providing quality, cost effective services for seniors, mental health residents, and adults with disabilities in cooperation with the Department of Social Development.', 'fr'),
(59, 49, '(506) 639-4478', 'en'),
(60, 49, '(506) 639-4478', 'fr'),
(61, 50, 'info@nbscha.com', 'en'),
(62, 50, 'info@nbscha.com', 'fr'),
(63, 51, '527 Dundonald Street, Suite 176 Fredericton, New Brunswick E3B 1X5', 'en'),
(64, 51, '527 Dundonald Street, Suite 176 Fredericton, New Brunswick E3B 1X5', 'fr'),
(65, 52, 'We’re here to help and answer any question you might have. Fill out the form below or message us on one of our social media platforms and we\'ll be in touch with you as soon as possible. We look forward to hearing from you.', 'en'),
(66, 52, 'We’re here to help and answer any question you might have. Fill out the form below or message us on one of our social media platforms and we\'ll be in touch with you as soon as possible. We look forward to hearing from you.', 'fr'),
(67, 53, '1', 'en'),
(68, 53, '1', 'fr'),
(69, 54, 'Mail to: NBSCHA, Amy McNair, 384 Smythe Street, Fredericton, N.B., E3B 3E4 ', 'en'),
(70, 54, 'Mail to: NBSCHA, Amy McNair, 384 Smythe Street, Fredericton, N.B., E3B 3E4 ', 'fr'),
(71, 55, 'Send to: treasurer@nbscha.ca', 'en'),
(72, 55, 'Send to: treasurer@nbscha.ca', 'fr'),
(73, 57, 'Monday - Saturday 8AM -7PM', 'en'),
(74, 57, 'Monday - Saturday 8AM -7PM', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `video` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `image`, `video`, `sort_order`, `status`) VALUES
(1, '', '', 0, 1),
(2, '', '', 0, 1),
(3, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sliders_desc`
--

CREATE TABLE `sliders_desc` (
  `desc_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders_desc`
--

INSERT INTO `sliders_desc` (`desc_id`, `slider_id`, `title`, `subtitle`, `summary`, `link_url`, `link_title`, `language`) VALUES
(1, 1, 'When you are not able. let us be of assistance', 'Welcome to the NBSCHA', '<p>\r\n	<b>Providing the right services for special care to welcome<br />\r\n	the residents to their new homes.</b></p>\r\n', '', '', 'en'),
(2, 2, 'Become a Member', 'Join Our Network', '<p>\r\n	<b>Get listed on our website and access membership<br />\r\n	benefits by registering your home.</b></p>\r\n', '', '', 'en'),
(3, 3, 'Browse our homes', 'New Brunswick Special Care Homes', '<p>\r\n	If you are interested in reserving a home,<br />\r\n	please contact the owner directly by phone or email.</p>\r\n', '', '', 'en'),
(4, 1, 'When you are not able. let us be of assistance', 'Welcome to the NBSCHA', '<p>\r\n	<b>Providing the right services for special care to welcome<br />\r\n	the residents to their new homes.</b></p>\r\n', '', '', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `sponsors`
--

CREATE TABLE `sponsors` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sponsors`
--

INSERT INTO `sponsors` (`id`, `image`, `sort_order`, `status`, `delete_status`) VALUES
(1, '1603827992-15f987918b613b.jpg', 0, 1, 0),
(2, '1603828043-15f98794b438e9.jpg', 0, 1, 0),
(3, '1603828345-15f987a79abf03.jpg', 0, 1, 0),
(4, 'Cosman.jpg', 0, 1, 0),
(5, 'Tara_Specialists.jpg', 0, 1, 0),
(6, 'Cooke_Insurance_Group.jpg', 0, 1, 0),
(7, 'Cindy_Lidster,_RN,_BScN,_BA,_FCNEd,_CCC.jpg', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sponsors_desc`
--

CREATE TABLE `sponsors_desc` (
  `desc_id` int(11) NOT NULL,
  `sponsor_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `website` varchar(400) DEFAULT NULL,
  `description` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sponsors_desc`
--

INSERT INTO `sponsors_desc` (`desc_id`, `sponsor_id`, `title`, `website`, `description`, `language`) VALUES
(1, 1, 'TD Bank', 'https://www.td.com/ca/en/about-td/', '<p>\r\n	TD Canada Trust is the commercial banking operation of the Toronto-Dominion Bank in Canada. TD Canada Trust offers a range of financial services and products.</p>\r\n', 'en'),
(2, 2, 'Lawton\'s Drugs', 'https://lawtons.ca/', 'Lawtons is a Canadian drug store chain owned by the Sobeys Group of Stellarton, Nova Scotia with a head office located in Dartmouth, Nova Scotia.', 'en'),
(3, 3, 'Beacon Clinical Group', 'https://beaconclinicalgroup.com/', 'Beacon Clinical Group offers consultation to new and existing health care facilities during transitional periods or with special projects/new builds', 'en'),
(4, 4, 'Cosman', 'https://www.cosmanbenefits.ca/', 'GROUP HEALTH INSURANCE! We are effectively managing our clients Benefits, Pension, HR, Insurance and Financial Planning needs by identifying critical areas within their arrangements and managing these areas to ensure best outcomes.', 'en'),
(5, 5, 'Tara Specialists', 'http://www.taraspecialists.com/', '<p>\r\n	Building affordable housing units is getting more and more complex. Our team will help you acquire land, manage the drawings, design and revision phase, and get the project through the proof of concept and approval stages.</p>\r\n', 'en'),
(6, 6, 'Cooke Insurance Group', 'https://cooke.ca/', 'With over 40 years of experience, we focus on delivering comprehensive products and services. In addition to insurance, our in-house claims experts are on hand should one of your claims need independent advice.', 'en'),
(7, 7, 'Cindy Lidster, RN, BScN, BA, FCNEd, CCC', 'https://www.acahs.ca/', 'Atlantic College of Applied Health Sciences The Atlantic College of Applied Health Sciences (ACAHS) recognizes the need for and value of post-secondary education and training. ACAHS is committed to providing a quality education that is focused on providing the learner and employer with a program that meets their short and long term goals. The ACAHS’s primary vision is to provide graduates who are educated, skilled and accountable to delivering quality healthcare support.', 'en'),
(8, 1, 'TD Bank', 'https://www.td.com/ca/en/about-td/', '<p>\r\n	TD Canada Trust is the commercial banking operation of the Toronto-Dominion Bank in Canada. TD Canada Trust offers a range of financial services and products.</p>\r\n', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `icon_class` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statistics`
--

INSERT INTO `statistics` (`id`, `icon_class`, `icon`, `number`, `sort_order`, `status`) VALUES
(1, 'fa fa-home mt-5 text-white', '', '369', 0, 1),
(2, 'fa fa-home mt-5 text-white', '', '35', 0, 1),
(3, 'fa fa-smile-o mt-5 text-white', '', '5000', 0, 1),
(4, 'fa  fa-users mt-5 text-white', '', '6905', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `statistics_desc`
--

CREATE TABLE `statistics_desc` (
  `desc_id` int(11) NOT NULL,
  `statistics_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statistics_desc`
--

INSERT INTO `statistics_desc` (`desc_id`, `statistics_id`, `name`, `language`) VALUES
(1, 1, 'Level 2 Homes', 'en'),
(2, 2, 'Level 3B3G Homes', 'en'),
(3, 3, 'Employees', 'en'),
(4, 4, 'Clients', 'en'),
(5, 1, 'Level 2 Homes', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `date`, `status`) VALUES
(1, '2022-03-21 18:30:00', 1),
(2, '2022-03-22 05:00:00', 1),
(3, '2022-03-22 05:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials_desc`
--

CREATE TABLE `testimonials_desc` (
  `desc_id` int(11) NOT NULL,
  `testimonials_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials_desc`
--

INSERT INTO `testimonials_desc` (`desc_id`, `testimonials_id`, `message`, `author`, `language`) VALUES
(1, 1, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>My sister has been living in the same Special Care Home in Saint John, NB for 20 years. This is her home and the residents are her family. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>She has been given excellent care over the years. Her health, medications and diet have been given wonderful attention and our family feels comfort in her care and knows she will be looked after properly. She has had many urgent episodes over the years and all the staff know her problems and what to look for, and when to call for emergency help. This has literally saved her life many times during the recent years of her failing health. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>We, her family, appreciate the loving care of the management and staff and would not hesitate to recommend anyone to this home </em></p>\r\n', 'Admin 1', 'en'),
(2, 2, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>I have a family member in Special Care Home. My first experience with special care homes was when a friend of mine was looking for a fitting special care home for his brother in law, about 5 years ago. I visited his brother in law often &amp; was quite impressed at the love, support &amp; care he received. So when my friend&#39;s time came that she was no longer able to live on her own, the first place I reached out to was the same establishment. I knew it would be a safe for her. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>I was already aware &amp; comfortable with the friendly staff &amp; the compassion &amp; patients they exhibited for the Residents in their care, even when the Resident was having a difficult day (or many difficult days). </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The owner &amp; staff are very approachable &amp; easily answer any &amp; all concerns I have in regards to me friend. It certainly puts my mind at ease to know she is in such a loving, caring environment, in which all Residents are considered Family. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>COVID has been trying to say the least this past year but my friend was in the best of hands. Owner &amp; staff have been very informative with each phase of this virus &amp; I was updated with emails &amp; phone calls. I am Grateful to have my Friend (chosen sister) in this forever home where she feels content &amp; safe. I have already told the staff to put &#39;my name&#39; on their list for when my time comes, I want to feel safe &amp; a part of a family also </em></p>\r\n', 'Admin 2', 'en'),
(3, 3, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>My daughter has been living in a care home since she was 19 years old. She is now 29 years old. She has cerebral palsy and she is nonverbal. Her condition had progressed in the last few years, she is now on a purred diet due to a choking issue with swallowing and her movement disorder has increased ongoing problems. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The care she has received is amazing and as her mom I am very pleased with the care home she lives in. The owner and staff know my daughters needs very well and communicate with me on any issues that come up. I trust their experience and knowledge of my daughter as I would my own. She is lucky to live in such a great place as I know not all of the care homes are so great. The one my daughter lives in is her home and she feels like family there. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The owner and staff are well trained and have done an amazing job in dealing with the covid situation. The home is clean and all precautions were taken to keep clients safe and as happy as possible. All regulations surrounding covid were sent out to family and we were updated on any changes in the new color zones. I commend the staff and owner for a job well done during such a difficult time of covid. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>I myself work with people with disabilities every day but I cannot lift due to injuries so that is why my daughter cannot live with me. I feel she is well cared for and her health and wellbeing are always in the best interest of her care home. I work under the same covid rules myself and I know the care home my daughter is in follows them well. I have had a very good experience with the care home my daughter lives in. Placing your loved one under someone else&#39;s care is a difficult and scary decision but I am happy with the choice we made for our daughter and the main thing is she is happy too. </em></p>\r\n', 'Admin 3', 'en'),
(4, 1, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>My sister has been living in the same Special Care Home in Saint John, NB for 20 years. This is her home and the residents are her family. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>She has been given excellent care over the years. Her health, medications and diet have been given wonderful attention and our family feels comfort in her care and knows she will be looked after properly. She has had many urgent episodes over the years and all the staff know her problems and what to look for, and when to call for emergency help. This has literally saved her life many times during the recent years of her failing health. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>We, her family, appreciate the loving care of the management and staff and would not hesitate to recommend anyone to this home </em></p>\r\n', 'Admin 1', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `widget_type` varchar(255) NOT NULL,
  `widget_template` varchar(255) DEFAULT NULL,
  `block_category` int(11) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `background` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `gallery` varchar(255) DEFAULT NULL,
  `widgets` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `name`, `widget_type`, `widget_template`, `block_category`, `class`, `background`, `image`, `video`, `gallery`, `widgets`, `status`) VALUES
(1, 'Page Content', 'page_content_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(2, 'About Intro', 'about_intro_widget', NULL, 2, NULL, NULL, 'about-page-img-new.jpg', NULL, '', '0,0', 1),
(3, 'About Mission', 'about_mission_widget', NULL, 3, NULL, NULL, NULL, 'nbcsha-quality.mp4', '', '0,0', 1),
(4, 'Home About', 'home_about_widget', NULL, NULL, NULL, NULL, NULL, NULL, 'front_12.jpg,front_22.jpg,front_32.jpg', '0,0', 1),
(5, 'Home Blocks', 'home_blocks_widget', NULL, 1, NULL, NULL, NULL, NULL, '', '0,0', 1),
(6, 'Home How it Works', 'home_works_widget', NULL, NULL, NULL, NULL, NULL, 'nbcsha-quality.mp4', '', '0,0', 1),
(7, 'Board Members', 'board_members_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(8, 'FAQs', 'faqs_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(9, 'Latest News', 'latest_news_widget', NULL, NULL, NULL, NULL, NULL, NULL, '', '0,0', 1),
(10, 'News', 'news_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(11, 'Residences', 'residences_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(12, 'Sponsors', 'sponsors_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(13, 'Statistics', 'statistics_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(14, 'Testimonials', 'testimonials_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(15, 'Contact Widget', 'contact_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `widgets_desc`
--

CREATE TABLE `widgets_desc` (
  `desc_id` int(11) NOT NULL,
  `widget_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `inset_title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `primary_link_url` varchar(255) NOT NULL,
  `primary_link_title` varchar(255) NOT NULL,
  `secondary_link_url` varchar(255) NOT NULL,
  `secondary_link_title` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `attachment_link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `widgets_desc`
--

INSERT INTO `widgets_desc` (`desc_id`, `widget_id`, `title`, `subtitle`, `inset_title`, `content`, `primary_link_url`, `primary_link_title`, `secondary_link_url`, `secondary_link_title`, `attachment`, `attachment_link_title`, `language`) VALUES
(1, 1, '', '', '', '', '', '', '', '', '', '', 'en'),
(2, 2, '', '', '', '<h2 class=\"text-uppercase mt-0\">\r\n	Welcome to New Brunswick Special<span class=\"text-theme-color-2\"> Care Home </span> Association Inc</h2>\r\n<p class=\"lead pt-10\">\r\n	Providing quality, cost effective services for seniors and adults with disabilities in cooperation with the Department of Social Development. We strive to promote and develop awareness throughout New Brunswick of the great service our special care homes provide. We are operators too, and therefore understand the immense dedication and commitment involved in running a home. We are here to offer ideas to help you provide the best possible environment for your residents and staff, while help you succeed with your business.</p>\r\n', '', '', '', '', '', '', 'en'),
(3, 3, 'Why Choose Us?', '', '', '', '', '', '', '', '', '', 'en'),
(4, 4, '', '', '', '<h2 class=\"text-uppercase mt-0\">\r\n	Welcome to the New Brunswick Special <span class=\"text-theme-color-2\">Care Home</span>&nbsp;Association Inc.</h2>\r\n<p class=\"lead\">\r\n	We promote and develop awareness throughout New Brunswick of the great service our special care homes provide</p>\r\n<p>\r\n	The New Brunswick Special Care Home Association is here to assist licensed members in providing quality, cost-effective services for seniors and adults with special needs who require 24-hour care and supervision, in cooperation with the Department of Social Development. We advocate for this vital sector on a regular basis to bring key issues to the forefront. Our Board of Directors is committed to improving our association services and partnerships with key stakeholders and other partners in Long Term Care. Our website also provides an opportunity for the public, discharge planners, social workers and others to access details about our members&rsquo; homes and their unique services.</p>\r\n', '', '', '', '', '', '', 'en'),
(5, 5, '', '', '', '', '', '', '', '', '', '', 'en'),
(6, 6, '', '', '', '<h3 class=\"text-white text-uppercase font-30 font-weight-600 mt-0 mb-20\">\r\n	How NBSCHA works for you?</h3>\r\n<p class=\"text-white lead p-5 pl-0 text-left\">\r\n	The association does for its members what they cannot easily do for themselves. The Group Benefit program has been helpful to many and has potential to improve and expand. Working with government on wage, per diem, and issues of standards is a very important role that no individual home can do.</p>\r\n<p class=\"text-white lead text-left\">\r\n	The re-branding as illustrated in these videos is yet another major element of service. The new corporate structure of the association represents a commitment to strengthen its organization in its drive to become increasingly strong as a support to individual homes. Enhanced and expanded education, group purchasing, collaboration with government and other associations is yet another role. The association becomes stronger as more service providers get involved.</p>\r\n', '', '', '', '', '', '', 'en'),
(7, 7, '', '', '', '', '', '', '', '', '', '', 'en'),
(8, 8, '', '', '', '', '', '', '', '', '', '', 'en'),
(9, 9, '', '', '', '', '', '', '', '', '', '', 'en'),
(10, 10, '', '', '', '', '', '', '', '', '', '', 'en'),
(11, 11, '', '', '', '', '', '', '', '', '', '', 'en'),
(12, 12, '', '', '', '', '', '', '', '', '', '', 'en'),
(13, 13, '', '', '', '', '', '', '', '', '', '', 'en'),
(14, 14, '', '', '', '', '', '', '', '', '', '', 'en'),
(15, 1, '', '', '', '', '', '', '', '', '', '', 'fr'),
(16, 2, '', '', '', '', '', '', '', '', '', '', 'fr'),
(17, 3, '', '', '', '', '', '', '', '', '', '', 'fr'),
(18, 4, '', '', '', '', '', '', '', '', '', '', 'fr'),
(19, 5, '', '', '', '', '', '', '', '', '', '', 'fr'),
(20, 6, '', '', '', '', '', '', '', '', '', '', 'fr'),
(21, 7, '', '', '', '', '', '', '', '', '', '', 'fr'),
(22, 8, '', '', '', '', '', '', '', '', '', '', 'fr'),
(23, 9, 'Recent', 'News', '', '<p>\r\n	Please see below the latest news and articles our association regards as very important information to our staff and clients. We will be updating frequently. Keep checking back for more updates!</p>\r\n', '', '', '', '', '', '', 'fr'),
(24, 10, '', '', '', '', '', '', '', '', '', '', 'fr'),
(25, 11, '', '', '', '', '', '', '', '', '', '', 'fr'),
(26, 12, '', '', '', '', '', '', '', '', '', '', 'fr'),
(27, 13, '', '', '', '', '', '', '', '', '', '', 'fr'),
(28, 14, '', '', '', '', '', '', '', '', '', '', 'fr'),
(29, 15, '', '', '', '', '', '', '', '', '', '', 'en'),
(30, 15, '', '', '', '', '', '', '', '', '', '', 'fr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `admins_login_history`
--
ALTER TABLE `admins_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_function`
--
ALTER TABLE `admin_function`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_function_permission`
--
ALTER TABLE `admin_function_permission`
  ADD UNIQUE KEY `role_function_id` (`function_id`,`role_id`);

--
-- Indexes for table `admin_menu`
--
ALTER TABLE `admin_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_reset`
--
ALTER TABLE `admin_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blocks_desc`
--
ALTER TABLE `blocks_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `block_categories`
--
ALTER TABLE `block_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `board_members`
--
ALTER TABLE `board_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `board_members_desc`
--
ALTER TABLE `board_members_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `carelevels`
--
ALTER TABLE `carelevels`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `carelevels_desc`
--
ALTER TABLE `carelevels_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate_templates_desc`
--
ALTER TABLE `certificate_templates_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `database_updates`
--
ALTER TABLE `database_updates`
  ADD PRIMARY KEY (`update_id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `facilities_desc`
--
ALTER TABLE `facilities_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs_desc`
--
ALTER TABLE `faqs_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `features_desc`
--
ALTER TABLE `features_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms_desc`
--
ALTER TABLE `forms_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `home_languages`
--
ALTER TABLE `home_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links_desc`
--
ALTER TABLE `links_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `live_members`
--
ALTER TABLE `live_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `localization`
--
ALTER TABLE `localization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manuals`
--
ALTER TABLE `manuals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manuals_desc`
--
ALTER TABLE `manuals_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `manual_policies`
--
ALTER TABLE `manual_policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manual_policies_desc`
--
ALTER TABLE `manual_policies_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `manual_policy_categories`
--
ALTER TABLE `manual_policy_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manual_sections`
--
ALTER TABLE `manual_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manual_section_categories`
--
ALTER TABLE `manual_section_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_packages`
--
ALTER TABLE `membership_packages`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `membership_packages_desc`
--
ALTER TABLE `membership_packages_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members_login_history`
--
ALTER TABLE `members_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_homes`
--
ALTER TABLE `member_homes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `spch_member_id` (`spch_member_id`);

--
-- Indexes for table `member_menu`
--
ALTER TABLE `member_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_reset`
--
ALTER TABLE `member_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuitems`
--
ALTER TABLE `menuitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuitems_desc`
--
ALTER TABLE `menuitems_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_categories`
--
ALTER TABLE `news_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_categories_desc`
--
ALTER TABLE `news_categories_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `news_desc`
--
ALTER TABLE `news_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages_desc`
--
ALTER TABLE `pages_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_widgets`
--
ALTER TABLE `page_widgets`
  ADD UNIQUE KEY `page_widget_id` (`page_id`,`widget_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `regions_desc`
--
ALTER TABLE `regions_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residences`
--
ALTER TABLE `residences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residences_desc`
--
ALTER TABLE `residences_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings_desc`
--
ALTER TABLE `settings_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders_desc`
--
ALTER TABLE `sliders_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `sponsors`
--
ALTER TABLE `sponsors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsors_desc`
--
ALTER TABLE `sponsors_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statistics_desc`
--
ALTER TABLE `statistics_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials_desc`
--
ALTER TABLE `testimonials_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widgets_desc`
--
ALTER TABLE `widgets_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admins_login_history`
--
ALTER TABLE `admins_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `admin_function`
--
ALTER TABLE `admin_function`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_menu`
--
ALTER TABLE `admin_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `admin_reset`
--
ALTER TABLE `admin_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `blocks_desc`
--
ALTER TABLE `blocks_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `block_categories`
--
ALTER TABLE `block_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `board_members`
--
ALTER TABLE `board_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `board_members_desc`
--
ALTER TABLE `board_members_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `carelevels`
--
ALTER TABLE `carelevels`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `carelevels_desc`
--
ALTER TABLE `carelevels_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `certificate_templates_desc`
--
ALTER TABLE `certificate_templates_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `database_updates`
--
ALTER TABLE `database_updates`
  MODIFY `update_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `facilities_desc`
--
ALTER TABLE `facilities_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faqs_desc`
--
ALTER TABLE `faqs_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `features_desc`
--
ALTER TABLE `features_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `forms_desc`
--
ALTER TABLE `forms_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `home_languages`
--
ALTER TABLE `home_languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `links_desc`
--
ALTER TABLE `links_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `live_members`
--
ALTER TABLE `live_members`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `localization`
--
ALTER TABLE `localization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `manuals`
--
ALTER TABLE `manuals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manuals_desc`
--
ALTER TABLE `manuals_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_policies`
--
ALTER TABLE `manual_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manual_policies_desc`
--
ALTER TABLE `manual_policies_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `manual_policy_categories`
--
ALTER TABLE `manual_policy_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_sections`
--
ALTER TABLE `manual_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_section_categories`
--
ALTER TABLE `manual_section_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `membership_packages`
--
ALTER TABLE `membership_packages`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `membership_packages_desc`
--
ALTER TABLE `membership_packages_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `membership_requests`
--
ALTER TABLE `membership_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members_login_history`
--
ALTER TABLE `members_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `member_homes`
--
ALTER TABLE `member_homes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `member_menu`
--
ALTER TABLE `member_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `member_reset`
--
ALTER TABLE `member_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menuitems`
--
ALTER TABLE `menuitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `menuitems_desc`
--
ALTER TABLE `menuitems_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news_categories`
--
ALTER TABLE `news_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news_categories_desc`
--
ALTER TABLE `news_categories_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `news_desc`
--
ALTER TABLE `news_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pages_desc`
--
ALTER TABLE `pages_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `regions_desc`
--
ALTER TABLE `regions_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `residences`
--
ALTER TABLE `residences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `residences_desc`
--
ALTER TABLE `residences_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `settings_desc`
--
ALTER TABLE `settings_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sliders_desc`
--
ALTER TABLE `sliders_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sponsors`
--
ALTER TABLE `sponsors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sponsors_desc`
--
ALTER TABLE `sponsors_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `statistics_desc`
--
ALTER TABLE `statistics_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `testimonials_desc`
--
ALTER TABLE `testimonials_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `widgets_desc`
--
ALTER TABLE `widgets_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
