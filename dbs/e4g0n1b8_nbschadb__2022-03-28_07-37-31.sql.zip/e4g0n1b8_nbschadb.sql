-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 28, 2022 at 10:35 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e4g0n1b8_nbschadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `uid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`uid`, `fullname`, `username`, `password`, `salt`, `email`, `phone`, `role`, `status`, `created`) VALUES
(1, 'Super Administrator', 'superadmin', '15c362dc8fd059b0386008927bc4105673455d20', 'celiums', 'admin@celiums.com', '984698551', 1, 1, '2021-10-06 18:40:02'),
(2, 'Loai Jaouni', 'loai', 'dffa88b5bf8ee2cb56c053025e112196ac16128f', '3Xl0Jj', 'loai.jaouni@gmail.com', '123456789', 1, 1, '2022-03-03 05:41:40');

-- --------------------------------------------------------

--
-- Table structure for table `admins_login_history`
--

CREATE TABLE `admins_login_history` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins_login_history`
--

INSERT INTO `admins_login_history` (`id`, `uid`, `ipaddress`, `timestamp`) VALUES
(1, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(2, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(3, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(4, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(5, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(6, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(7, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(8, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(9, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(10, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(11, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(12, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(13, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(14, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(15, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(16, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(17, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(18, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(19, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(20, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(21, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(22, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(23, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(24, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(25, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(26, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(27, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(28, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(29, 1, '127.0.0.1', '0000-00-00 00:00:00'),
(30, 1, '178.153.50.253', '0000-00-00 00:00:00'),
(31, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(32, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(33, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(34, 1, '61.3.191.131', '0000-00-00 00:00:00'),
(35, 1, '61.3.191.131', '0000-00-00 00:00:00'),
(36, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(37, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(38, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(39, 2, '159.2.217.178', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admin_function`
--

CREATE TABLE `admin_function` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `controller` varchar(255) NOT NULL,
  `function` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_function_permission`
--

CREATE TABLE `admin_function_permission` (
  `function_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu`
--

CREATE TABLE `admin_menu` (
  `id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  `display` int(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_menu`
--

INSERT INTO `admin_menu` (`id`, `class`, `name`, `link`, `parent_id`, `status`, `display`, `sort_order`) VALUES
(1, 'fa-dashboard', 'Dashboard', '', 0, 'Y', 1, 0),
(2, 'fa-user', 'Manage Users', '', 0, 'Y', 1, 20),
(3, '', 'Users', 'users/overview', 2, 'Y', 1, 1),
(4, '', 'Add User', 'users/add', 2, 'Y', 1, 2),
(9, '', 'Settings', 'home/settings', 1, 'Y', 1, 1),
(10, '', 'Clear Cache', 'home/clearcache', 1, 'Y', 1, 2),
(11, '', 'Update Database', 'home/updatedb', 1, 'Y', 1, 3),
(25, '', 'Dashboard', 'home/dashboard', 1, 'Y', 1, 0),
(30, 'fa-file', 'Manage Pages', '', 0, 'Y', 1, 18),
(31, '', 'Pages', 'pages/overview', 30, 'Y', 1, 1),
(32, '', 'Add Page', 'pages/add', 30, 'Y', 1, 2),
(50, 'fa-bars', 'Manage Menu', '', 0, 'Y', 1, 16),
(51, '', 'Menus', 'menus/overview', 50, 'Y', 1, 1),
(52, '', 'Add Menu', 'menus/add', 50, 'Y', 1, 2),
(60, 'fa-cubes', 'Manage Widgets', '', 0, 'Y', 1, 19),
(61, '', 'Widgets', 'widgets/overview', 60, 'Y', 1, 1),
(70, 'fa-file-code-o', 'Manage Content', '', 0, 'Y', 1, 17),
(78, 'fa-wpforms', 'Manage Enquiries', '', 0, 'Y', 1, 4),
(79, '', 'Enquiries', 'enquiries/overview', 78, 'Y', 1, 5),
(83, '', 'Home Sliders', 'sliders/overview', 70, 'Y', 1, 1),
(84, '', 'Blocks', 'blocks/overview', 70, 'Y', 1, 2),
(85, '', 'Block Categories', 'blocks/categories', 70, 'Y', 1, 3),
(86, '', 'Languages', 'languages/overview', 1, 'Y', 1, 1),
(89, 'fa-home', 'Manage Residences', '', 0, 'Y', 1, 2),
(90, '', 'Members', 'members', 89, 'Y', 1, 0),
(91, 'fa-file-text-o', 'Manage Masters', '', 0, 'Y', 1, 3),
(92, '', 'Packages(Beds)', 'packages', 91, 'Y', 1, 0),
(93, '', 'Localization', 'home/localization', 1, 'Y', 1, 1),
(94, '', 'Regions', 'regions', 91, 'Y', 1, 2),
(95, '', 'Level Of Care', 'carelevels', 91, 'Y', 1, 4),
(96, '', 'Facilities', 'facilities', 91, 'Y', 1, 3),
(97, '', 'Features', 'features', 91, 'Y', 1, 6),
(99, '', 'Certificate Templates', 'certificatetemplates', 91, 'Y', 1, 7),
(100, '', 'Sponsors', 'sponsors', 70, 'Y', 1, 0),
(101, '', 'Board Members', 'teams', 70, 'Y', 1, 0),
(102, '', 'Links', 'links', 70, 'Y', 1, 0),
(103, '', 'Forms', 'forms', 70, 'Y', 1, 0),
(104, '', 'Testimonials', 'testimonials', 70, 'Y', 1, 0),
(105, '', 'Statistics', 'statistics', 70, 'Y', 1, 0),
(106, '', 'Faqs', 'faqs', 70, 'Y', 1, 0),
(107, '', 'News', 'news', 70, 'Y', 1, 0),
(108, '', 'News Categories', 'news/categories', 70, 'Y', 1, 0),
(109, '', 'Requests', 'requests', 89, 'Y', 1, 1),
(110, '', 'Residences', 'residences', 89, 'Y', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu_permission`
--

CREATE TABLE `admin_menu_permission` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_reset`
--

CREATE TABLE `admin_reset` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_key` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `rid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`rid`, `name`, `status`) VALUES
(1, 'Super Administrator', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `category` int(11) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `category`, `icon`, `image`, `sort_order`, `status`) VALUES
(1, 1, '', '', 0, 1),
(2, 1, '', '', 0, 1),
(3, 1, '', '', 0, 1),
(4, 1, '', '', 0, 1),
(5, 2, '', '', 0, 1),
(6, 2, '', '', 0, 1),
(7, 2, '', '', 0, 1),
(8, 2, '', '', 0, 1),
(9, 3, '', '', 0, 1),
(10, 3, '', '', 0, 1),
(11, 3, '', '', 0, 1),
(12, 3, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `blocks_desc`
--

CREATE TABLE `blocks_desc` (
  `desc_id` int(11) NOT NULL,
  `block_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `caption_title` varchar(255) NOT NULL,
  `caption_subtitle` varchar(255) NOT NULL,
  `icon_class` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks_desc`
--

INSERT INTO `blocks_desc` (`desc_id`, `block_id`, `title`, `summary`, `caption_title`, `caption_subtitle`, `icon_class`, `link_url`, `link_title`, `language`) VALUES
(1, 1, 'Membership', '', 'Owners/Operators join our network of special care homes', '', 'fa fa-user text-white font-64 pb-10', '/register', 'Join Us Now', 'en'),
(2, 2, 'Questions?', '', 'Considering a special care home? Here is a good place to start', '', 'fa fa-comments-o text-white font-64 pb-10', '/faq', 'Get help', 'en'),
(3, 3, 'Residences', '', 'Explore key information on our homes and available vacancies', '', 'fa fa-book fa-fw text-white font-64 pb-10', '/residences', 'Find Us Now', 'en'),
(4, 4, 'Member Login', '', 'Are you a member? Login to get your latest updates.', '', 'fa fa-mobile text-white font-64 pb-10', '/member/login', 'Find Us Now', 'en'),
(5, 5, 'Our Residences', '', 'Browse our residences for special care homes in your area.', '', 'fa fa-home', '/residences', '', 'en'),
(6, 6, 'Membership', '', 'Join our membership of special care homes in New Brunswick.', '', 'fa fa-user', '/register', '', 'en'),
(7, 7, 'Sponsors', '', 'We are so grateful to our sponsors. With their support we thrive.', '', 'fa fa-heartbeat', '/sponsors', '', 'en'),
(8, 8, 'Board Members', '', 'Meet our board members who aim to improve the lives of special care home workers.', '', 'fa fa-users', '/board', '', 'en'),
(9, 9, 'ADVOCATE', '', 'We are dedicated to protecting the rights of our workers and advocate for equitable wages and benefits for our workers.', '', 'fa fa-wheelchair text-white font-60', '#', '', 'en'),
(10, 10, 'EDUCATE', '', 'We aim to provide standardized education and training that is in line with the needs and demands of our industry.', '', 'fa fa-user text-white font-60', '#', '', 'en'),
(11, 11, 'IMPROVE', '', 'We work with the government and other stakeholders on special projects in order to improve the sector as a whole.', '', 'fa fa-money text-white font-60', '#', '', 'en'),
(12, 12, 'INFORM', '', 'We work with various government departments to ensure appropriate standards and regulations are implemented while communicating directly with the sector.', '', 'fa fa-pencil fa-fw text-white font-60', '#', '', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `block_categories`
--

CREATE TABLE `block_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_categories`
--

INSERT INTO `block_categories` (`id`, `name`, `status`) VALUES
(1, 'Home Callouts', 1),
(2, 'Useful Links', 1),
(3, 'Why Chose Us', 1);

-- --------------------------------------------------------

--
-- Table structure for table `board_members`
--

CREATE TABLE `board_members` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `board_members`
--

INSERT INTO `board_members` (`id`, `slug`, `email`, `phone`, `photo`, `facebook`, `twitter`, `linkedin`, `skype`, `sort_order`, `status`) VALUES
(1, 'jan-seely', 'jan.seely@rogers.com', '(506) 639-4478', 'bm_jan_d.jpg', '#', '#', '#', '#', 0, 1),
(3, 'john-grass', 'jgrass1213@rogers.com', '506-872-3340', 'John_Grass.jpg', '', '', '', '', 0, 1),
(4, 'leonard-gervais', 'treasurer@nbscha.com', '(506) 447-1076', 'Leonard_Gervais.jpg', '', '', '', '', 0, 1),
(5, 'danielle-gallant', 'secretary@nbscha.ca', '(506) 650-8706', 'Danielle_Gallant.jpg', '', '', '', '', 0, 1),
(6, 'derek-green', 'dgreen@shannex.com', '506-381-3914', 'Derek_Green.jpg', '', '', '', '', 0, 1),
(7, 'crystal-powell', 'kathleen11251@gmail.com', '', 'Crystal_Powell.jpg', '', '', '', '', 0, 1),
(8, 'collette-doucette', 'collette.obs@rogers.com', '(506)533-8088', 'Collette_Doucette.jpg', '', '', '', '', 0, 1),
(9, 'jason-lee', 'ceo@peiseniorshomes.com', '902 626 7720', 'Jason_Lee.jpg', '', '', '', '', 0, 1),
(10, 'christine-saunders', 'paradisevilla.cs@gmail.com', '', 'Christine_Saunders.jpg', '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `board_members_desc`
--

CREATE TABLE `board_members_desc` (
  `desc_id` int(11) NOT NULL,
  `board_member_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `bio` text,
  `location` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `board_members_desc`
--

INSERT INTO `board_members_desc` (`desc_id`, `board_member_id`, `name`, `position`, `bio`, `location`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Jan Seely', 'President', '<p>\r\n	Jan has been the President of the NB Special Care Home Association for many years. She is a strong advocate for community based services. Jan works hard to forge productive relationships with government, and other community partners, to strengthen the sector overall. Her and her husband own and operate a small Special Care Home in Saint John. The past 25 years in this occupation has given her a comprehensive knowledge base of the challenges faced by operators and their employees as they strive to deliver quality services to clients.</p>\r\n', NULL, NULL, NULL, NULL, 'en'),
(3, 3, 'John Grass', 'Vice President', 'John has been a resident of Riverview for the past 46 years and graduated Riverview High School in 1980. He then obtained his Bachelor of Science in 1984 and his Bachelor of Business in 1986 both from Mount Allison University, He spent 12 years with the Irving group of companies before buying his first Special Care Home in 1988. Buying a piece of vacant land in 1999 and built the Finish Line Car Wash in 2005. Finish Line has 2 touchless automatic bays and 2 self-serve bays and is located in Riverview. While still operating those businesses, John and his wife Lynn build their second home in 2019. Combined, they offer level 2 and 3G levels of care for 60 seniors.', 'Riverview, NB', NULL, NULL, NULL, 'en'),
(4, 4, 'Leonard Gervais', 'Treasurer', 'Leonard has been in the care home business since 1997 and has been a member with the New Brunswick Special Care Home Association since 1998. Leonard was first introduced to the board in 2008 and was re-elected in 2012.', 'Fredericton, NB', NULL, NULL, NULL, 'en'),
(5, 5, 'Danielle Gallant', 'Secretary', '<p>\r\n	My name is Danielle Gallant. I&rsquo;ve been operating our family business for that last 20 years and was a pharmacy technician for seven years. I&#39;ve been the Secretary of the New Brunswick Special Care Home Association for the last 6 years. In the late summer of 2019, I was also part of the working group that was created to restructure the Special Care home Standards and Regulations.</p>\r\n<p>\r\n	My passion is to advocate for excellent quality services be provided in all homes in New Brunswick. I believe change is needed in out sector and I&rsquo;m ecstatic to be part of it!</p>\r\n', 'Saint John, NB', NULL, NULL, NULL, 'en'),
(6, 6, 'Derek Green', 'Board Member', 'Derek joined Shannex in 2018 as Vice President, New Brunswick Operations where he supports our Parkland Retirement Living Campuses and Shannex Nursing Homes throughout NB. Derek’s focus is to support the company’s current and expanding operations in NB to ensure Residents continue to receive top quality accommodations and services from engaged employees. Originally from a small town on the Southwest Miramichi - Boiestown, Derek now resides in Riverview, NB. He and his wife Jill have been married for 25 years and they have 3 children. Prior to joining Shannex, Derek had a distinguished 23-year career as a senior leader with Medavie Blue Cross, accountable for implementation and management of their federal government contracts with Veterans Affairs Canada, CAF, RCMP and Immigration, Refugees and Citizenship Canada. Prior to that he served as an Artillery Officer with the Canadian Armed Forces for 8 years, stationed in Quebec, Ontario, and Chatham, NB. Derek holds a Bachelor of Commerce from the Royal Military College of Canada.', 'Riverview, NB', NULL, NULL, NULL, 'en'),
(7, 7, 'Crystal Powell', 'Board Member', 'Crystal has been a PSW certified by Compu College for 17 years now. She has also attended NBCC for one year where she took office administration and received her certification. She has a nursing home background of 9 years and has done homecare both privately and through a homecare company dealing mainly with seniors and palliative care clients. She has experience working with high functioning mental health clients from employment in a level 2 special care home, prior to owning and operating Maritime Manor Special Care home since 2014. Crystal finds it gratifying dealing in senior care, geriatric clients have taught her so much and she still has so much to learn from them! She love the outdoors, hunting ,fishing, camping and spending as much time as possible with her two children and her husband. Making time for friends and family is important to her. Crystal’s work is her passion and she is so grateful she took the opportunity when it arose to become a Special Care Home Owner, aside from her children it is one of her greatest accomplishments.', 'Saint John, NB', NULL, NULL, NULL, 'en'),
(8, 8, 'Collette Doucette', 'Board Member', 'At a very early age Collette developed a commitment to serving the elderly. From 1986 to 1994 she worked as a Nurse-Aid at Villa Providence in Shediac, a 198 beds Nursing Home. In 1994 her dream came true and became the Owner and Operator of a 45 beds Special Care Home for 17 years. After selling her home, she took on the role in 2017 of managing the day to day operation of a 130 beds Special Care Home Residence O Bons Soins in Shediac NB. Married with Donald Doucette in 1986, her high school sweetheart they have 2 boys and 2 grandchildren.', 'Shediac, NB', NULL, NULL, NULL, 'en'),
(9, 9, 'Jason Lee', 'Board Member', 'I am the CEO of the 435 member team with PEI Seniors Homes and Enhanced Living Special Care Homes, a group of nursing homes, community care facilities and specialized care homes across Prince Edward Island and New Brunswick, Canada. We provide care and homes for 385 of our countries seniors. Pleased to be a board and executive member with the Canadian Association for Long Term Care, the leading group in Canada for the support and growth of seniors care facilities across the country. Volunteer board member of the New Brunswick Special Care Home Association and a proud member of the Wallace McCain Institute through the University of New Brunswick. A lifelong resident of Prince Edward Island in Charlottetown, three-time graduate from UPEI and live on Spring Park Road with my amazing wife and two smart talented kids.', 'Charlottetown, PEI', NULL, NULL, NULL, 'en'),
(10, 10, 'Christine Saunders', 'Board Member', 'Christine Saunders is co-owner and CEO of Paradise Villa Inc. a 78-bed licensed Special Care Home that includes 18 Memory Care Beds in Fredericton NB. She is a Licensed Practical Nurse and has worked in long term care for a number of years. Also, she works in her other family-owned businesses in the Moncton area. When she is not working, she enjoys spending time with her family, especially her two kids.', 'Moncton, NB', NULL, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `carelevels`
--

CREATE TABLE `carelevels` (
  `cid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `carelevels`
--

INSERT INTO `carelevels` (`cid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 0, 1),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0),
(5, 0, 1, 0),
(6, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `carelevels_desc`
--

CREATE TABLE `carelevels_desc` (
  `desc_id` int(11) NOT NULL,
  `carelevel_id` int(11) NOT NULL,
  `carelevel_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `carelevels_desc`
--

INSERT INTO `carelevels_desc` (`desc_id`, `carelevel_id`, `carelevel_title`, `language`) VALUES
(1, 1, 'Care Level 1', 'en'),
(2, 1, 'Care Level 1 Fr', 'fr'),
(3, 2, 'Level-2', 'en'),
(4, 3, 'Level-3', 'en'),
(5, 4, 'Level-3B', 'en'),
(6, 5, 'Level-3G', 'en'),
(7, 6, 'Level-4', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_templates`
--

CREATE TABLE `certificate_templates` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `c_key` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `background` varchar(255) DEFAULT NULL,
  `wallet_bg` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificate_templates`
--

INSERT INTO `certificate_templates` (`id`, `title`, `c_key`, `image`, `background`, `wallet_bg`, `signature`, `status`, `sort_order`, `delete_status`) VALUES
(1, 'Membership Certificate', 'membership', '', '', '', 'signature.png', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `certificate_templates_desc`
--

CREATE TABLE `certificate_templates_desc` (
  `desc_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `template` text NOT NULL,
  `wallet_template` text,
  `signatory` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL DEFAULT 'en'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificate_templates_desc`
--

INSERT INTO `certificate_templates_desc` (`desc_id`, `template_id`, `template`, `wallet_template`, `signatory`, `language`) VALUES
(1, 1, '<div style=\"width: 700px;\r\n    margin: 0px;\r\n    padding: 30px;\r\n    color: #000;\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    text-align: center;\">\r\n	<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" width=\"100%\">\r\n		<tbody>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<img src=\"https://nbscha.celiums.com/public/common/images/certificate_header.jpg\" width=\"100%\" /></td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<h2 style=\"color:red;text-transform:uppercase;font-size:30px;font-weight:bolder\">\r\n						{{residence}}</h2>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<p>\r\n						IS A SPECIAL CARE HOME WITH FULL MEMBERSHIP STATUS IN THE NEW BRUNSWICK SPECIAL CARE HOME ASSOCIATION AND APPLICABLE REGIONAL SPECIAL CARE HOME ASSOCIATION</p>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"30%\">\r\n					<span style=\"font-size:12px;\">NBSCHA MEMBERSHIP</span><br />\r\n					<span style=\"font-size:13px;\">{{identifier}}</span></td>\r\n				<td width=\"40%\">\r\n					{{signature}}<br />\r\n					{{signatory}}</td>\r\n				<td width=\"30%\">\r\n					{{expiry}}<br />\r\n					<span style=\"font-size:12px;text-decoration:underline\">EXPIRY DATE</span></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '<div style=\"width: 700px;\r\n    margin: 0px;\r\n    padding: 30px;\r\n    color: #000;\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    text-align: center;\">\r\n	<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" width=\"100%\">\r\n		<tbody>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<img src=\"http://nbscha.com/public/common/images/certificate_header.jpg\" width=\"100%\" /></td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<h2 style=\"color:red;text-transform:uppercase;font-size:30px;font-weight:bolder\">\r\n						{{residence}}</h2>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<p>\r\n						IS A SPECIAL CARE HOME WITH FULL MEMBERSHIP STATUS IN THE NEW BRUNSWICK SPECIAL CARE HOME ASSOCIATION AND APPLICABLE REGIONAL SPECIAL CARE HOME ASSOCIATION</p>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"30%\">\r\n					<span style=\"font-size:12px;\">NBSCHA MEMBERSHIP</span><br />\r\n					<span style=\"font-size:13px;\">{{identifier}}</span></td>\r\n				<td width=\"40%\">\r\n					{{signature}}<br />\r\n					{{signatory}}</td>\r\n				<td width=\"30%\">\r\n					{{expiry}}<br />\r\n					<span style=\"font-size:12px;text-decoration:underline\">EXPIRY DATE</span></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'Jan seely / President of NBSCHA', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `database_updates`
--

CREATE TABLE `database_updates` (
  `update_id` int(11) NOT NULL,
  `update_name` varchar(255) NOT NULL,
  `update_status` varchar(255) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `database_updates`
--

INSERT INTO `database_updates` (`update_id`, `update_name`, `update_status`, `update_time`) VALUES
(1, 'saleel2022031401.txt', '1', '2022-03-14 05:53:15'),
(2, 'saleel2022031402.txt', '1', '2022-03-14 05:55:20'),
(3, 'saleel2022031501.txt', '1', '2022-03-15 08:51:15');

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `board_member_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `home_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `type`, `board_member_id`, `member_id`, `home_id`, `name`, `email`, `phone`, `subject`, `message`, `created`) VALUES
(1, 'residence', 0, 4, 2, 'Saleel VA', 'saleelva@gmail.com', '09846985511', 'Test Suject', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2022-03-26 13:47:46'),
(2, 'board_member', 1, 0, 0, 'Martin Luther', 'martinluther@gmail.com', '', 'Test Suject', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2022-03-26 13:49:03'),
(3, 'contact', 0, 0, 0, 'Lionel Messi', 'messi@gmail.com', '09846985511', 'Lorem ipsum dolor sit amet', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. ', '2022-03-26 13:50:09');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `fid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`fid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 1, 0),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `facilities_desc`
--

CREATE TABLE `facilities_desc` (
  `desc_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  `facility_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities_desc`
--

INSERT INTO `facilities_desc` (`desc_id`, `facility_id`, `facility_title`, `language`) VALUES
(1, 1, 'Seniors', 'en'),
(2, 2, 'Mental Health', 'en'),
(3, 3, 'Intellectual and Developmental', 'en'),
(4, 4, 'Blended Facility', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `sort_order`, `status`) VALUES
(1, 0, 1),
(2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faqs_desc`
--

CREATE TABLE `faqs_desc` (
  `desc_id` int(11) NOT NULL,
  `faq_id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faqs_desc`
--

INSERT INTO `faqs_desc` (`desc_id`, `faq_id`, `question`, `answer`, `language`) VALUES
(1, 1, 'What questions should I ask operators when enquiring about a placement?', '<p class=\"mb-5\">\r\n	When enquiring about a placement, always make sure to ask essential questions before deciding. Here are some questions you should consider:</p>\r\n<p>\r\n	How will you help build life skills?</p>\r\n<p>\r\n	Do I have access to a telephone where I can speak in private?</p>\r\n<p>\r\n	Do I have access to the internet?</p>\r\n<p>\r\n	Are you able to provide me with a menu?</p>\r\n<p>\r\n	Will you be able to accommodate my special diet?</p>\r\n<p>\r\n	What time do you provide meals?</p>\r\n<p>\r\n	Do you have a bedtime or a quiet time?</p>\r\n<p>\r\n	What training does your staff have?</p>\r\n<p>\r\n	What activities do you offer?</p>\r\n<p>\r\n	When experiencing challenging behaviours from residents, how would operator/staff handle the situation?</p>\r\n<p>\r\n	How do you transport clients?</p>\r\n<p>\r\n	Is there local transportation handy to your home? Example: handi bus, transit buses or taxi</p>\r\n<p>\r\n	Will you transport to religious venues?</p>\r\n<p>\r\n	Do you have visiting hours or open door policy?</p>\r\n<p>\r\n	Can I visit my loved one privately in their room or only inn open common areas?</p>\r\n<p>\r\n	Will it be a single room or shared room?</p>\r\n<p>\r\n	Do you charge more than the government rate?</p>\r\n<p>\r\n	Do you provide cable in the bedrooms?</p>\r\n<p>\r\n	Do you have stairs in your building that I will have to use?</p>\r\n<p>\r\n	Can I bring my own personal belongings?</p>\r\n<p>\r\n	Can I put up my own pictures on the walls?</p>\r\n<p>\r\n	What furniture is provided in the bedroom?</p>\r\n<p>\r\n	Am i expected to purchase over the counter medications? Example: Tylenol for a headache?</p>\r\n', 'en'),
(2, 2, 'What are your next steps?', '<p class=\"mb-5\">\r\n	To access a full Long Term Care Assessment through Social Development, please gather your personal information together (address, medicare number, date of birth, etc.). Also, Call Social Development- 1-833-733-7835. Choose the option that says &quot;apply for long term care&quot;. Your information will be collected and the call will take approximately 10-15 minutes.</p>\r\n<p>\r\n	Within 5-10 days you should be contacted for an appointment and they will require additional financial information in order to complete your assessment and appoint you a Social Worker.</p>\r\n<p>\r\n	You will also be given a list of special care homes to call but our new website NBSCHA has a quick search method for the public. ( * PLEASE NOTE THESE HOMES ARE ALL MEMBERS OF OUR ASSOCIATION)</p>\r\n<p>\r\n	<b>Other Options:</b> You may already have an idea of which Special Care Home you would like to choose. If so, feel free to reach out to the operator for assistance with the assessment process. Our province also offers a <b>&quot;Private Pay&quot;</b> option for those persons who prefer not to access assistance through the Department of Social Development, but rather choose to pay for the care themselves. Additionally, your care needs may be temporary in nature, therefore you can reach out to your preferred facility and check the availability for a Relief/Respite and Convalescent Care bed. If you have a Social Worker already, this option can be as inexpensive as $10/day and you can stay for up to 30 days at a time or 90 days in a calendar year.</p>\r\n', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `fid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`fid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 1, 1, 0),
(2, 16, 1, 0),
(3, 2, 1, 0),
(4, 17, 1, 0),
(5, 3, 1, 0),
(6, 18, 1, 0),
(7, 4, 1, 0),
(8, 19, 1, 0),
(9, 5, 1, 0),
(10, 6, 1, 0),
(11, 7, 1, 0),
(12, 8, 1, 0),
(13, 9, 1, 0),
(14, 10, 1, 0),
(15, 11, 1, 0),
(16, 12, 1, 0),
(17, 13, 1, 0),
(18, 14, 1, 0),
(19, 15, 1, 0),
(20, 20, 1, 0),
(21, 21, 1, 0),
(22, 22, 1, 0),
(23, 23, 1, 0),
(24, 24, 1, 0),
(25, 25, 1, 0),
(26, 26, 1, 0),
(27, 27, 1, 0),
(28, 28, 1, 0),
(29, 29, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `features_desc`
--

CREATE TABLE `features_desc` (
  `desc_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `feature_title` varchar(400) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `features_desc`
--

INSERT INTO `features_desc` (`desc_id`, `feature_id`, `feature_title`, `language`) VALUES
(1, 1, 'Can a resident bring their pet to live with them?', 'en'),
(2, 2, 'Do you allow residents to bring their own furniture?', 'en'),
(3, 3, 'Do you look after managing their comfort and clothing money?', 'en'),
(4, 4, 'Do you have in home hairdressing?', 'en'),
(5, 5, 'Do you have in home foot care?', 'en'),
(6, 6, 'Do staff have training in Diabetes and insulin management?', 'en'),
(7, 7, 'Do staff have training in Oxygen Therapy?', 'en'),
(8, 8, 'Do staff have training in Colostomy Care?', 'en'),
(9, 9, 'Do staff have training in Wound Care?', 'en'),
(10, 10, 'Do you accept residents that are incontinent of urine and/or bowels?', 'en'),
(11, 11, 'Do you accept clients that are MRSA positive?', 'en'),
(12, 12, 'Can clients keep their own family physicians?', 'en'),
(13, 13, 'Do you have a working relationship with extra mural nursing?', 'en'),
(14, 14, 'Do you provide excursions for your residents?', 'en'),
(15, 15, 'Do any of your residents work in the community?', 'en'),
(16, 16, 'Do you have an accessible shower or tub for persons in a wheelchair?', 'en'),
(17, 17, 'Do you provide references from your existing clients and/or their families?', 'en'),
(18, 18, 'Do you provide transportation to and from medical visits?', 'en'),
(19, 19, 'Does staff administering medications have the required training?', 'en'),
(20, 20, 'Do staff have training in Dementia Care?', 'en'),
(21, 21, 'Do you have a monitoring system on the doors?', 'en'),
(22, 22, 'Do you have experience with clients suffering from addictions?', 'en'),
(23, 23, 'Do you have a doctor/nurse practitioner assigned to all residents?', 'en'),
(24, 24, 'Do you provide adaptive equipment for your residents?', 'en'),
(25, 25, 'Do any of your residents attend outreach programs?', 'en'),
(26, 26, 'Do you accommodate special diets i.e. gluten free, diabetic, etc.?', 'en'),
(27, 27, 'Do you have an outdoor area for sitting, walking, gardening, etc.?', 'en'),
(28, 28, 'Do You Accept Smokers And Provide A Designated Smoking Area?', 'en'),
(29, 29, 'Do you accept residents who are incontinent?', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `type`, `attachment`, `publish_date`, `status`) VALUES
(1, 'member', '', '2022-03-23 05:00:00', 1),
(2, 'member', '', '2022-03-23 05:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `forms_desc`
--

CREATE TABLE `forms_desc` (
  `desc_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forms_desc`
--

INSERT INTO `forms_desc` (`desc_id`, `form_id`, `name`, `language`) VALUES
(1, 1, 'Social Development Check Form for Staff', 'en'),
(2, 2, 'Oath of Confidentiality', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `label` varchar(100) NOT NULL,
  `class` varchar(300) NOT NULL,
  `code` varchar(10) NOT NULL,
  `default_language` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `label`, `class`, `code`, `default_language`, `status`) VALUES
(1, 'English', 'ENG', '', 'en', 1, 1),
(2, 'French', 'FRA', '', 'fr', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `type`, `image`, `sort_order`, `status`) VALUES
(1, 'public', '', 0, 1),
(2, 'public', '', 0, 1),
(3, 'public', '', 0, 1),
(4, 'public', 'index4.png', 0, 1),
(5, 'member', '', 0, 1),
(6, 'member', '', 0, 1),
(7, 'member', '', 0, 1),
(8, 'member', '', 0, 1),
(9, 'member', '', 0, 1),
(10, 'member', '', 0, 1),
(11, 'member', '', 0, 1),
(12, 'member', '', 0, 1),
(13, 'member', '', 0, 1),
(14, 'member', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `links_desc`
--

CREATE TABLE `links_desc` (
  `desc_id` int(11) NOT NULL,
  `link_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `summary` text,
  `link_url` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links_desc`
--

INSERT INTO `links_desc` (`desc_id`, `link_id`, `name`, `summary`, `link_url`, `language`) VALUES
(1, 1, 'Department of Social Development', '<p>\r\n	Great resource for youth, families, seniors and persons w/disabilities.&nbsp;</p>\r\n', 'https://www.gnb.ca/socialdevelopment', 'en'),
(2, 2, 'Government of New Brunswick', '<p>\r\n	Find out the latest news, information and links pertaining to the New Brunswick Government.</p>\r\n', 'https://www.gnb.ca/', 'en'),
(3, 3, 'Workplace Health and Safety', '<p>\r\n	A great resource for workers and employers from Workplace health &amp;amp; Safety. As well as all the latest news and updates.</p>\r\n', 'https://www.worksafenb.ca/', 'en'),
(4, 4, 'Pay Equity Act', '<p>\r\n	Full Pay Equity Act publication posted by the Justice and Office of the Attorney General.</p>\r\n', 'http://laws.gnb.ca/en/showfulldoc/cs/P-5.05//20210114', 'en'),
(5, 5, 'Infirm Persons Act', '<p>\r\n	Infirm Persons Act</p>\r\n', 'https://www.canlii.org/en/nb/laws/stat/rsnb-1973-c-i-8/latest/rsnb-1973-c-i-8.html', 'en'),
(6, 6, 'Family Income Security Act and Reg', '<p>\r\n	Family Income Security Act and Reg</p>\r\n', 'https://www.canlii.org/en/nb/laws/stat/snb-1994-c-f-2.01/latest/snb-1994-c-f-2.01.html', 'en'),
(7, 7, 'Smoke Free Places Act', '<p>\r\n	Smoke Free Places Act</p>\r\n', 'https://www.gnb.ca/legis/bill/editform-e.asp?ID=296&legi=55&num=1', 'en'),
(8, 8, 'Human Rights Act	', 'Human Rights Act', 'https://www2.gnb.ca/content/gnb/en/departments/nbhrc.html', 'en'),
(9, 9, 'Occupational Health and Safety Act and Regulation	', '<p>\r\n	Occupational Health and Safety Act and Regulation</p>\r\n', 'http://laws.gnb.ca/en/ShowPdf/cs/O-0.2.pdf', 'en'),
(10, 10, 'Employment standards Act', '<p>\r\n	Employment standards Act</p>\r\n', 'http://laws.gnb.ca/en/ShowTdm/cs/E-7.2//', 'en'),
(11, 11, 'Adult Residential Facility Standards', '<p>\r\n	Adult Residential Facility Standards</p>\r\n', 'https://www2.gnb.ca/content/dam/gnb/Departments/sd-ds/pdf/Standards/AdultResidential-e.pdf', 'en'),
(12, 12, 'Mental Health Act', '<p>\r\n	Mental Health Act</p>\r\n', 'https://https//www.canlii.org/en/nb/laws/stat/rsnb-1973-c-m-10/latest/rsnb-1973-c-m-10.html/en/nb/laws/stat/rsnb-1973-c-m-10/latest/rsnb-1973-c-m-10.html', 'en'),
(13, 13, 'Fire Prevention Act', '<p>\r\n	Fire Prevention Act</p>\r\n', 'https://www.canlii.org/en/nb/laws/regu/nb-reg-82-20/latest/nb-reg-82-20.html', 'en'),
(14, 14, 'Health Act', '<p>\r\n	Health Act</p>\r\n', 'https://www.canada.ca/en/health-canada/services/health-care-system/canada-health-care-system-medicare/canada-health-act.html', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `localization`
--

CREATE TABLE `localization` (
  `id` int(11) NOT NULL,
  `lang_key` text NOT NULL,
  `lang_value` text NOT NULL,
  `language` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `localization`
--

INSERT INTO `localization` (`id`, `lang_key`, `lang_value`, `language`) VALUES
(1, 'SITE_NAME', 'The New Brunswick Special Care Home Association Title English 3', 'en'),
(2, 'SITE_NAME', 'The New Brunswick Special Care Home Association Title French 1', 'fr'),
(3, 'SITE_SOLGAN', 'The New Brunswick Special Care Home Association Slogan English 4 Such', 'en'),
(4, 'SITE_SOLGAN', 'The New Brunswick Special Care Home Association Slogan French 2', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `mid` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`mid`, `first_name`, `last_name`, `password`, `salt`, `email`, `phone`, `status`, `created`, `delete_status`) VALUES
(4, 'Saleel', 'VA', 'f1cad15d22f6d137b310184ba286c65bd85f7ca0', 'tEqpOx', 'saleel@celiums.com', '09846985511', 1, '2022-03-26 11:50:32', 0);

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `residence_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `certificate` text,
  `wallet_certificate` text,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `identifier`, `member_id`, `residence_id`, `package_id`, `issue_date`, `expiry_date`, `certificate`, `wallet_certificate`, `status`) VALUES
(2, '2203260002', 4, 2, 2, '2022-03-26', '2023-03-31', 'a:2:{s:11:\"certificate\";s:1290:\"<div style=\"width: 700px;\r\n    margin: 0px;\r\n    padding: 30px;\r\n    color: #000;\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    text-align: center;\">\r\n	<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" width=\"100%\">\r\n		<tbody>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<img src=\"http://nbscha.com/public/common/images/certificate_header.jpg\" width=\"100%\" /></td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<h2 style=\"color:red;text-transform:uppercase;font-size:30px;font-weight:bolder\">\r\n						Test residence</h2>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<p>\r\n						IS A SPECIAL CARE HOME WITH FULL MEMBERSHIP STATUS IN THE NEW BRUNSWICK SPECIAL CARE HOME ASSOCIATION AND APPLICABLE REGIONAL SPECIAL CARE HOME ASSOCIATION</p>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"30%\">\r\n					<span style=\"font-size:12px;\">NBSCHA MEMBERSHIP</span><br />\r\n					<span style=\"font-size:13px;\"></span></td>\r\n				<td width=\"40%\">\r\n					<img src=\"https://nbscha.celiums.com/public/uploads/certificates/signature.png\" style=\"max-width:100%\" /><br />\r\n					Jan seely / President of NBSCHA</td>\r\n				<td width=\"30%\">\r\n					2023-03-31<br />\r\n					<span style=\"font-size:12px;text-decoration:underline\">EXPIRY DATE</span></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n\";s:10:\"background\";s:0:\"\";}', 'a:2:{s:11:\"certificate\";s:1290:\"<div style=\"width: 700px;\r\n    margin: 0px;\r\n    padding: 30px;\r\n    color: #000;\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    text-align: center;\">\r\n	<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" width=\"100%\">\r\n		<tbody>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<img src=\"http://nbscha.com/public/common/images/certificate_header.jpg\" width=\"100%\" /></td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<h2 style=\"color:red;text-transform:uppercase;font-size:30px;font-weight:bolder\">\r\n						Test residence</h2>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td colspan=\"3\">\r\n					<p>\r\n						IS A SPECIAL CARE HOME WITH FULL MEMBERSHIP STATUS IN THE NEW BRUNSWICK SPECIAL CARE HOME ASSOCIATION AND APPLICABLE REGIONAL SPECIAL CARE HOME ASSOCIATION</p>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"30%\">\r\n					<span style=\"font-size:12px;\">NBSCHA MEMBERSHIP</span><br />\r\n					<span style=\"font-size:13px;\"></span></td>\r\n				<td width=\"40%\">\r\n					<img src=\"https://nbscha.celiums.com/public/uploads/certificates/signature.png\" style=\"max-width:100%\" /><br />\r\n					Jan seely / President of NBSCHA</td>\r\n				<td width=\"30%\">\r\n					2023-03-31<br />\r\n					<span style=\"font-size:12px;text-decoration:underline\">EXPIRY DATE</span></td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n\";s:10:\"background\";s:0:\"\";}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `membership_packages`
--

CREATE TABLE `membership_packages` (
  `pid` int(11) NOT NULL,
  `bed_count` int(11) NOT NULL DEFAULT '0',
  `bed_unlimited` tinyint(1) NOT NULL DEFAULT '0',
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `certificate_template` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_packages`
--

INSERT INTO `membership_packages` (`pid`, `bed_count`, `bed_unlimited`, `price`, `certificate_template`, `sort_order`, `status`, `delete_status`) VALUES
(1, 20, 0, 100.00, 1, 0, 1, 0),
(2, 40, 0, 400.00, 1, 0, 1, 0),
(3, 60, 0, 500.00, 1, 0, 1, 0),
(4, 0, 1, 850.00, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_packages_desc`
--

CREATE TABLE `membership_packages_desc` (
  `desc_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_packages_desc`
--

INSERT INTO `membership_packages_desc` (`desc_id`, `package_id`, `title`, `description`, `language`) VALUES
(1, 1, '1-20', '', 'en'),
(2, 2, '20-40', '', 'en'),
(3, 3, '40-60', '', 'en'),
(4, 4, '60+', '', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `membership_requests`
--

CREATE TABLE `membership_requests` (
  `id` int(11) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `home_name` varchar(255) NOT NULL,
  `home_address` varchar(255) NOT NULL,
  `home_postalcode` varchar(255) NOT NULL,
  `home_contact_name` varchar(255) NOT NULL,
  `home_email` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `home_fax` varchar(255) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `home_level` int(11) NOT NULL,
  `pharmacy_name` varchar(255) NOT NULL,
  `facilities` varchar(255) NOT NULL,
  `region_id` int(11) NOT NULL,
  `description` text,
  `comments` text,
  `mainimage` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `image4` varchar(255) DEFAULT NULL,
  `image5` varchar(255) DEFAULT NULL,
  `image6` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `features` text NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(255) NOT NULL,
  `payment_info` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_requests`
--

INSERT INTO `membership_requests` (`id`, `identifier`, `first_name`, `last_name`, `email`, `phone`, `password`, `salt`, `home_name`, `home_address`, `home_postalcode`, `home_contact_name`, `home_email`, `home_phone`, `home_fax`, `package_id`, `home_level`, `pharmacy_name`, `facilities`, `region_id`, `description`, `comments`, `mainimage`, `image2`, `image3`, `image4`, `image5`, `image6`, `facebook`, `instagram`, `twitter`, `youtube`, `linkedin`, `website`, `features`, `amount`, `payment_method`, `payment_info`, `transaction_id`, `payment_status`, `created`, `status`, `processed_by`, `processed_date`) VALUES
(3, '22030003', 'Saleel', 'VA', 'saleel@celiums.com', '09846985511', 'f1cad15d22f6d137b310184ba286c65bd85f7ca0', 'tEqpOx', 'Test residence', 'TestAddr1, TestAddr2', '435656', 'Saleel VA', 'saleelva@gmail.com', '09846985511', '', 2, 4, 'Test Pharmacy', '2,4', 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', '2c6606a52da3eea611e1a0afa3072979.jpeg', '98449ea8c2ffbe706245f142d19c3c38.png', '', 'eae7b7f80e90922ab18c90c8098bd588.png', '1ed0a042fa78f5b0439aadeefb6869b0.png', '1702e4d541e4696bc46483dd22932ddb.png', 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.twitter.com', 'https://www.youtube.com', 'https://www.linkedin.com', 'http://www.celiumsolutions.com', 'a:14:{i:1;s:1:\"1\";i:3;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:16;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:29;s:1:\"1\";}', 400.00, 'eTransfer', 'Test5673454837', '', 0, '2022-03-26 11:48:06', 'approved', 1, '2022-03-26 11:50:32');

-- --------------------------------------------------------

--
-- Table structure for table `members_login_history`
--

CREATE TABLE `members_login_history` (
  `id` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members_login_history`
--

INSERT INTO `members_login_history` (`id`, `mid`, `ipaddress`, `timestamp`) VALUES
(1, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(2, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(3, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(4, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(5, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(6, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(7, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(8, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(9, 2, '127.0.0.1', '0000-00-00 00:00:00'),
(10, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(11, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(12, 2, '159.2.217.178', '0000-00-00 00:00:00'),
(13, 3, '61.3.191.131', '0000-00-00 00:00:00'),
(14, 4, '61.3.191.131', '0000-00-00 00:00:00'),
(15, 4, '159.2.217.178', '0000-00-00 00:00:00'),
(16, 4, '61.3.191.131', '0000-00-00 00:00:00'),
(17, 4, '159.2.217.178', '0000-00-00 00:00:00'),
(18, 4, '50.65.45.110', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `member_menu`
--

CREATE TABLE `member_menu` (
  `id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N',
  `display` int(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member_menu`
--

INSERT INTO `member_menu` (`id`, `class`, `name`, `link`, `parent_id`, `status`, `display`, `sort_order`) VALUES
(1, 'fa-dashboard', 'Dashboard', '', 0, 'Y', 1, 0),
(2, '', 'Dashboard', 'home/dashboard', 1, 'Y', 1, 0),
(3, 'fa-cubes', 'Resources', '', 0, 'Y', 1, 0),
(4, '', 'News', 'resources/news', 3, 'Y', 1, 0),
(5, '', 'Forms', 'resources/forms', 3, 'Y', 1, 1),
(6, '', 'Links', 'resources/links', 3, 'Y', 1, 2),
(7, '', 'Membership', 'membership', 1, 'Y', 1, 1),
(8, '', 'Residence', 'residences', 1, 'Y', 1, 2),
(9, '', 'Enquires', 'enquiries/overview', 1, 'Y', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `member_reset`
--

CREATE TABLE `member_reset` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_key` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member_reset`
--

INSERT INTO `member_reset` (`id`, `user_id`, `user_key`) VALUES
(1, 2, 'zaVAiWGZUJxD3ELy');

-- --------------------------------------------------------

--
-- Table structure for table `menuitems`
--

CREATE TABLE `menuitems` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `link_type` varchar(255) NOT NULL,
  `link_object` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `show_subitems` tinyint(1) NOT NULL DEFAULT '1',
  `target_type` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuitems`
--

INSERT INTO `menuitems` (`id`, `menu_id`, `parent_id`, `link_type`, `link_object`, `class`, `attachment`, `show_subitems`, `target_type`, `sort_order`, `status`) VALUES
(1, 1, 0, 'internal', '', '', NULL, 1, '_self', 1, 1),
(2, 1, 0, 'internal', '', '', NULL, 1, '_self', 1, 1),
(3, 1, 0, 'pages', '4', '', NULL, 1, '', 2, 1),
(4, 2, 0, 'internal', '', '', NULL, 1, '', 1, 1),
(6, 1, 0, 'pages', '5', '', NULL, 1, '', 3, 1),
(7, 1, 0, 'pages', '6', '', NULL, 1, '', 4, 1),
(8, 1, 0, 'pages', '7', '', NULL, 1, '', 5, 1),
(9, 1, 0, 'pages', '8', '', NULL, 1, '', 6, 1),
(10, 1, 0, 'pages', '9', '', NULL, 1, '', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menuitems_desc`
--

CREATE TABLE `menuitems_desc` (
  `desc_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuitems_desc`
--

INSERT INTO `menuitems_desc` (`desc_id`, `menuitem_id`, `name`, `link`, `language`) VALUES
(1, 2, 'Home', '/', 'en'),
(2, 2, 'Home', '/', 'fr'),
(3, 3, 'About', '/', 'en'),
(4, 3, 'About', '/', 'fr'),
(5, 4, 'Covid-19 Statement', '/', 'en'),
(6, 4, 'Covid-19 Statement', '/', 'fr'),
(9, 6, 'Residences', '', 'en'),
(10, 6, 'Residences', '', 'fr'),
(11, 7, 'Board', '', 'en'),
(12, 7, 'Board', '', 'fr'),
(13, 8, 'Sponsors', '', 'en'),
(14, 8, 'Sponsors', '', 'fr'),
(15, 9, 'News', '', 'en'),
(16, 9, 'News', '', 'fr'),
(17, 10, 'Contact', '', 'en'),
(18, 10, 'Contact', 'contact', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `class`, `code`, `status`) VALUES
(1, 'Main Menu', '', 'main_menu', 1),
(2, 'Top Menu', '', 'top_menu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `type`, `slug`, `category`, `author`, `image`, `publish_date`, `sort_order`, `status`) VALUES
(1, 'member', 'nbscha-affordable-quality-now', 4, 'NBSCHA', 'mqdefault.jpg', '2021-03-31 05:00:00', 0, 1),
(2, 'public', 'nbscha-affordable-quality-now-220323060856', 4, 'NBSCHA', 'NBSCHA_Affordable_Quality_Now.jpg', '2021-03-31 05:00:00', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_categories`
--

CREATE TABLE `news_categories` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_categories`
--

INSERT INTO `news_categories` (`id`, `slug`, `sort_order`, `status`) VALUES
(1, 'training', 0, 1),
(2, 'agm', 0, 1),
(3, 'community', 0, 1),
(4, 'special-care-week', 0, 1),
(5, 'committees', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_categories_desc`
--

CREATE TABLE `news_categories_desc` (
  `desc_id` int(11) NOT NULL,
  `news_category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_categories_desc`
--

INSERT INTO `news_categories_desc` (`desc_id`, `news_category_id`, `name`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Training', NULL, NULL, NULL, 'en'),
(2, 2, 'AGM', NULL, NULL, NULL, 'en'),
(3, 3, 'Community', NULL, NULL, NULL, 'en'),
(4, 4, 'Special Care Week', NULL, NULL, NULL, 'en'),
(5, 5, 'Committees', NULL, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `news_desc`
--

CREATE TABLE `news_desc` (
  `desc_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text,
  `body` text,
  `video` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_desc`
--

INSERT INTO `news_desc` (`desc_id`, `news_id`, `title`, `summary`, `body`, `video`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'NBSCHA Affordable. Quality. Now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '', NULL, NULL, NULL, 'en'),
(2, 2, 'NBSCHA Affordable. Quality. Now.', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '<p>\r\n	New Brunswick Special Care Home Association offers over 400 homes with up to 1000 available beds. Affordable quality health care available right now.</p>\r\n', '', NULL, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `banner_video` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `slug`, `banner_image`, `banner_video`, `status`) VALUES
(1, '', NULL, NULL, 1),
(2, '', NULL, NULL, 1),
(3, '', NULL, NULL, 1),
(4, 'about', NULL, NULL, 1),
(5, 'residences', '', '', 1),
(6, 'board', '', '', 1),
(7, 'sponsors', '', '', 1),
(8, 'news', '', '', 1),
(9, 'contact', '', '', 1),
(10, 'news-details', '', '', 1),
(11, 'board-member-page', '', '', 1),
(12, 'residence-page', '', '', 1),
(13, 'faq', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pages_desc`
--

CREATE TABLE `pages_desc` (
  `desc_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages_desc`
--

INSERT INTO `pages_desc` (`desc_id`, `page_id`, `title`, `subtitle`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Home', NULL, 'Home', NULL, NULL, 'en'),
(2, 2, 'Page not found', NULL, 'Page not found', NULL, NULL, 'en'),
(3, 1, 'Home', NULL, 'Home', NULL, NULL, 'fr'),
(4, 2, 'Page not found', NULL, 'Page not found', NULL, NULL, 'fr'),
(5, 3, 'Register', NULL, 'Register', NULL, NULL, 'en'),
(6, 3, 'Register', NULL, 'Register', NULL, NULL, 'fr'),
(7, 4, 'About Us', NULL, 'About Us', NULL, NULL, 'en'),
(8, 4, 'About Us', NULL, 'About Us', NULL, NULL, 'fr'),
(9, 5, 'Residences', '', 'Residences', NULL, NULL, 'en'),
(10, 6, 'Board', '', 'Board', NULL, NULL, 'en'),
(11, 7, 'Sponsors', '', 'Sponsors', NULL, NULL, 'en'),
(12, 8, 'News', '', 'News', NULL, NULL, 'en'),
(13, 9, 'Contact', '', 'Contact', NULL, NULL, 'en'),
(14, 10, 'News Details', '', 'News Details', NULL, NULL, 'en'),
(15, 11, 'Board Member Page', '', 'Board Member Page', NULL, NULL, 'en'),
(16, 12, 'Residence Page', '', 'Residence Page', NULL, NULL, 'en'),
(17, 13, 'FAQ', '', 'FAQ', NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_type` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `content` text,
  `gallery` text,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `page_widgets`
--

CREATE TABLE `page_widgets` (
  `page_id` int(11) NOT NULL,
  `widget_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_widgets`
--

INSERT INTO `page_widgets` (`page_id`, `widget_id`, `sort_order`) VALUES
(1, 4, 2),
(1, 5, 1),
(1, 6, 3),
(1, 9, 4),
(4, 2, 1),
(4, 3, 3),
(4, 13, 2),
(4, 14, 4),
(5, 11, 1),
(6, 7, 1),
(7, 12, 1),
(8, 10, 1),
(9, 15, 1),
(13, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `rid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`rid`, `sort_order`, `status`, `delete_status`) VALUES
(1, 0, 1, 0),
(2, 0, 1, 0),
(3, 0, 1, 0),
(4, 0, 1, 0),
(5, 0, 1, 0),
(6, 0, 1, 0),
(7, 0, 1, 0),
(8, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `regions_desc`
--

CREATE TABLE `regions_desc` (
  `desc_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `region_name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regions_desc`
--

INSERT INTO `regions_desc` (`desc_id`, `region_id`, `region_name`, `language`) VALUES
(1, 1, 'Region 1: Moncton', 'en'),
(2, 2, 'Region 2: Saint John', 'en'),
(3, 3, 'Region 3: Fredericton', 'en'),
(4, 4, 'Region 4: Edmundston', 'en'),
(5, 5, 'Region 5: Restigouche', 'en'),
(6, 6, 'Region 6: Chaleur', 'en'),
(7, 7, 'Region 7: Miramichi', 'en'),
(8, 8, 'Region 8: Acadian Peninsula', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `residences`
--

CREATE TABLE `residences` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postalcode` varchar(255) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `pharmacy_name` varchar(255) NOT NULL,
  `facilities` varchar(255) NOT NULL,
  `region_id` int(11) NOT NULL,
  `mainimage` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `image4` varchar(255) DEFAULT NULL,
  `image5` varchar(255) DEFAULT NULL,
  `image6` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `features` text NOT NULL,
  `beds_count` int(11) NOT NULL,
  `vacancy` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `residences`
--

INSERT INTO `residences` (`id`, `slug`, `member_id`, `address`, `postalcode`, `contact_name`, `email`, `phone`, `fax`, `package_id`, `level_id`, `pharmacy_name`, `facilities`, `region_id`, `mainimage`, `image2`, `image3`, `image4`, `image5`, `image6`, `facebook`, `instagram`, `twitter`, `youtube`, `linkedin`, `website`, `features`, `beds_count`, `vacancy`, `created`, `status`) VALUES
(2, 'test-residence', 4, 'TestAddr1, TestAddr2', '435656', 'Saleel VA', 'saleelva@gmail.com', '09846985511', '', 2, 4, 'Test Pharmacy', '2,4', 2, '2c6606a52da3eea611e1a0afa3072979.jpeg', '98449ea8c2ffbe706245f142d19c3c38.png', '', 'eae7b7f80e90922ab18c90c8098bd588.png', '1ed0a042fa78f5b0439aadeefb6869b0.png', '1702e4d541e4696bc46483dd22932ddb.png', 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.twitter.com', 'https://www.youtube.com', 'https://www.linkedin.com', 'http://www.celiumsolutions.com', 'a:14:{i:1;s:1:\"1\";i:3;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:16;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:29;s:1:\"1\";}', 40, 10, '2022-03-26 11:50:32', 1),
(3, '', 0, 'TestAddr1, TestAddr2', '435656', 'Saleel VA', 'saleelva@gmail.com', '09846985511', '', 2, 4, 'Test Pharmacy', '2,4', 2, NULL, NULL, NULL, NULL, NULL, NULL, 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.twitter.com', 'https://www.youtube.com', 'https://www.linkedin.com', 'http://www.celiumsolutions.com', 'a:14:{i:1;s:1:\"1\";i:3;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:16;s:1:\"1\";i:19;s:1:\"1\";i:2;s:1:\"1\";i:8;s:1:\"1\";i:20;s:1:\"1\";i:21;s:1:\"1\";i:24;s:1:\"1\";i:25;s:1:\"1\";i:26;s:1:\"1\";i:29;s:1:\"1\";}', 0, 0, '2022-03-26 15:30:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `residences_desc`
--

CREATE TABLE `residences_desc` (
  `desc_id` int(11) NOT NULL,
  `residence_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_desc` text,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `residences_desc`
--

INSERT INTO `residences_desc` (`desc_id`, `residence_id`, `name`, `description`, `meta_title`, `meta_desc`, `meta_keywords`, `language`) VALUES
(1, 1, 'Test', 'Test', NULL, NULL, NULL, 'en'),
(2, 2, 'Test residence1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test residence', NULL, NULL, 'en'),
(3, 3, 'Test residence1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', NULL, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `title` varchar(300) NOT NULL,
  `settingkey` varchar(300) NOT NULL,
  `settingtype` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `parent`, `title`, `settingkey`, `settingtype`, `sort_order`, `status`) VALUES
(1, 14, 'Site Name', 'SITE_NAME', 'text', 0, 'Y'),
(2, 14, 'Admin Email', 'ADMIN_EMAIL', 'text', 0, 'Y'),
(3, 14, 'From Mail Address', 'FROM_MAIL', 'text', 0, 'Y'),
(4, 14, 'Support Phone', 'SUPPORT_PHONE', 'text', 0, 'Y'),
(5, 15, 'Meta Title', 'DEFAULT_META_TITLE', 'text', 0, 'Y'),
(6, 15, 'Meta Desc', 'DEFAULT_META_DESCRIPTION', 'textarea', 0, 'Y'),
(7, 15, 'Meta Keywords', 'DEFAULT_META_KEYWORDS', 'textarea', 0, 'Y'),
(8, 16, 'Mailer Protocol', 'MAILER_PROTOCOL', 'text', 0, 'Y'),
(9, 16, 'Mailer Host', 'MAILER_HOST', 'text', 0, 'Y'),
(10, 16, 'Mailer User', 'MAILER_USER', 'text', 0, 'Y'),
(11, 16, 'Mailer Password', 'MAILER_PASSWORD', 'text', 0, 'Y'),
(12, 16, 'Mailer Port', 'MAILER_PORT', 'text', 0, 'Y'),
(13, 16, 'Mailer Transport', 'MAILER_TRANSPORT', 'text', 0, 'Y'),
(14, 0, 'General', '', 'group', 1, 'Y'),
(15, 0, 'SEO', '', 'group', 2, 'Y'),
(16, 0, 'Mail', '', 'group', 3, 'Y'),
(17, 0, 'Theme', 'theme_group', 'group', 4, 'Y'),
(18, 17, 'Home Page', 'HOME_PAGE_ID', 'pages', 0, 'Y'),
(19, 17, '404 Error Page', 'ERROR_PAGE_ID', 'pages', 1, 'Y'),
(39, 17, 'Register Page', 'REGISTER_PAGE_ID', 'pages', 2, 'Y'),
(40, 0, 'Security', 'SECURITY_SETTINGS', 'group', 10, 'Y'),
(41, 40, 'reCpatcha Site Key', 'RECAPTCHA_SITE_KEY', 'text', 1, 'Y'),
(42, 40, 'reCpatcha Secret Key', 'RECAPTCHA_SECRET_KEY', 'text', 2, 'Y'),
(44, 17, 'Residence Page', 'RESIDENCE_PAGE_ID', 'pages', 4, 'Y'),
(45, 17, 'Board Member Page', 'BOARD_PAGE_ID', 'pages', 5, 'Y'),
(46, 17, 'News Details Page', 'NEWS_PAGE_ID', 'pages', 6, 'Y'),
(47, 0, 'Contact Info', 'CONTACT_INFO', 'group', 10, 'Y'),
(48, 47, 'Footer Mission', 'FOOTER_MISSION', 'textarea', 1, 'Y'),
(49, 47, 'Contact Phone', 'CONTACT_PHONE', 'text', 2, 'Y'),
(50, 47, 'Contact Email', 'CONTACT_EMAIL', 'text', 3, 'Y'),
(51, 47, 'Contact Address', 'CONTACT_ADDRESS', 'textarea', 5, 'Y'),
(52, 47, 'Get In Touch', 'CONTACT_GETINTOUCH', 'textarea', 3, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `settings_desc`
--

CREATE TABLE `settings_desc` (
  `desc_id` int(11) NOT NULL,
  `setting_id` int(11) NOT NULL,
  `settingvalue` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings_desc`
--

INSERT INTO `settings_desc` (`desc_id`, `setting_id`, `settingvalue`, `language`) VALUES
(1, 1, 'The New Burnswick Special Care Home Association English', 'en'),
(2, 2, 'varunvictor007@gmail.com', 'en'),
(3, 3, 'admin@celiums.com', 'en'),
(4, 4, '1234567890', 'en'),
(5, 5, 'The New Burnswick Special Care Home Association', 'en'),
(6, 6, 'The New Burnswick Special Care Home Association', 'en'),
(7, 7, 'The New Burnswick Special Care Home Association', 'en'),
(8, 8, 'off', 'en'),
(9, 9, '', 'en'),
(10, 10, '', 'en'),
(11, 11, '', 'en'),
(12, 12, '', 'en'),
(13, 13, '', 'en'),
(14, 14, NULL, 'en'),
(15, 15, NULL, 'en'),
(16, 16, NULL, 'en'),
(17, 17, NULL, 'en'),
(18, 18, '1', 'en'),
(19, 19, '2', 'en'),
(20, 1, 'The New Burnswick Special Care Home Association French', 'fr'),
(21, 2, 'varunvictor007@gmail.com', 'fr'),
(22, 3, 'admin@celiums.com', 'fr'),
(23, 4, '1234567890', 'fr'),
(24, 5, 'The New Burnswick Special Care Home Association', 'fr'),
(25, 6, 'The New Burnswick Special Care Home Association', 'fr'),
(26, 7, 'The New Burnswick Special Care Home Association', 'fr'),
(27, 8, 'off', 'fr'),
(28, 9, '', 'fr'),
(29, 10, '', 'fr'),
(30, 11, '', 'fr'),
(31, 12, '', 'fr'),
(32, 13, '', 'fr'),
(33, 14, NULL, 'fr'),
(34, 15, NULL, 'fr'),
(35, 16, NULL, 'fr'),
(36, 17, NULL, 'fr'),
(37, 18, '1', 'fr'),
(38, 19, '2', 'fr'),
(39, 39, '3', 'en'),
(40, 39, '1', 'fr'),
(41, 40, '1', 'en'),
(42, 40, '1', 'fr'),
(43, 41, '6Le2JOYeAAAAAE-1NpTkW6Th8lv_W4OwbpZJtjcB', 'en'),
(44, 41, '6Le2JOYeAAAAAE-1NpTkW6Th8lv_W4OwbpZJtjcB', 'fr'),
(45, 42, '6Le2JOYeAAAAAHpIrWo6q4l0A86LWdcMXM7V9PC_', 'en'),
(46, 42, '6Le2JOYeAAAAAHpIrWo6q4l0A86LWdcMXM7V9PC_', 'fr'),
(49, 44, '12', 'en'),
(50, 44, '12', 'fr'),
(51, 45, '11', 'en'),
(52, 45, '11', 'fr'),
(53, 46, '10', 'en'),
(54, 46, '10', 'fr'),
(55, 47, '1', 'en'),
(56, 47, '1', 'fr'),
(57, 48, 'The New Brunswick Special Care Home Association Inc. aims to assist members in providing quality, cost effective services for seniors, mental health residents, and adults with disabilities in cooperation with the Department of Social Development.', 'en'),
(58, 48, 'The New Brunswick Special Care Home Association Inc. aims to assist members in providing quality, cost effective services for seniors, mental health residents, and adults with disabilities in cooperation with the Department of Social Development.', 'fr'),
(59, 49, '(506) 639-4478', 'en'),
(60, 49, '(506) 639-4478', 'fr'),
(61, 50, 'info@nbscha.com', 'en'),
(62, 50, 'info@nbscha.com', 'fr'),
(63, 51, '527 Dundonald Street, Suite 176 Fredericton, New Brunswick E3B 1X5', 'en'),
(64, 51, '527 Dundonald Street, Suite 176 Fredericton, New Brunswick E3B 1X5', 'fr'),
(65, 52, 'We’re here to help and answer any question you might have. Fill out the form below or message us on one of our social media platforms and we\'ll be in touch with you as soon as possible. We look forward to hearing from you.', 'en'),
(66, 52, 'We’re here to help and answer any question you might have. Fill out the form below or message us on one of our social media platforms and we\'ll be in touch with you as soon as possible. We look forward to hearing from you.', 'fr');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `video` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `image`, `video`, `sort_order`, `status`) VALUES
(1, '', '', 0, 1),
(2, '', '', 0, 1),
(3, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sliders_desc`
--

CREATE TABLE `sliders_desc` (
  `desc_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders_desc`
--

INSERT INTO `sliders_desc` (`desc_id`, `slider_id`, `title`, `subtitle`, `summary`, `link_url`, `link_title`, `language`) VALUES
(1, 1, 'When you are not able. let us be of assistance', 'Welcome to the NBSCHA', '<p>\r\n	<b>Providing the right services for special care to welcome<br />\r\n	the residents to their new homes.</b></p>\r\n', '', '', 'en'),
(2, 2, 'Become a Member', 'Join Our Network', '<p>\r\n	<b>Get listed on our website and access membership<br />\r\n	benefits by registering your home.</b></p>\r\n', '', '', 'en'),
(3, 3, 'Browse our homes', 'New Brunswick Special Care Homes', '<p>\r\n	If you are interested in reserving a home,<br />\r\n	please contact the owner directly by phone or email.</p>\r\n', '', '', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `sponsors`
--

CREATE TABLE `sponsors` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sponsors`
--

INSERT INTO `sponsors` (`id`, `image`, `sort_order`, `status`, `delete_status`) VALUES
(1, '1603827992-15f987918b613b.jpg', 0, 1, 0),
(2, '1603828043-15f98794b438e9.jpg', 0, 1, 0),
(3, '1603828345-15f987a79abf03.jpg', 0, 1, 0),
(4, 'Cosman.jpg', 0, 1, 0),
(5, 'Tara_Specialists.jpg', 0, 1, 0),
(6, 'Cooke_Insurance_Group.jpg', 0, 1, 0),
(7, 'Cindy_Lidster,_RN,_BScN,_BA,_FCNEd,_CCC.jpg', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sponsors_desc`
--

CREATE TABLE `sponsors_desc` (
  `desc_id` int(11) NOT NULL,
  `sponsor_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `website` varchar(400) DEFAULT NULL,
  `description` text,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sponsors_desc`
--

INSERT INTO `sponsors_desc` (`desc_id`, `sponsor_id`, `title`, `website`, `description`, `language`) VALUES
(1, 1, 'TD Bank', 'https://www.td.com/ca/en/about-td/', '<p>\r\n	TD Canada Trust is the commercial banking operation of the Toronto-Dominion Bank in Canada. TD Canada Trust offers a range of financial services and products.</p>\r\n', 'en'),
(2, 2, 'Lawton\'s Drugs', 'https://lawtons.ca/', 'Lawtons is a Canadian drug store chain owned by the Sobeys Group of Stellarton, Nova Scotia with a head office located in Dartmouth, Nova Scotia.', 'en'),
(3, 3, 'Beacon Clinical Group', 'https://beaconclinicalgroup.com/', 'Beacon Clinical Group offers consultation to new and existing health care facilities during transitional periods or with special projects/new builds', 'en'),
(4, 4, 'Cosman', 'https://www.cosmanbenefits.ca/', 'GROUP HEALTH INSURANCE! We are effectively managing our clients Benefits, Pension, HR, Insurance and Financial Planning needs by identifying critical areas within their arrangements and managing these areas to ensure best outcomes.', 'en'),
(5, 5, 'Tara Specialists', 'http://www.taraspecialists.com/', '<p>\r\n	Building affordable housing units is getting more and more complex. Our team will help you acquire land, manage the drawings, design and revision phase, and get the project through the proof of concept and approval stages.</p>\r\n', 'en'),
(6, 6, 'Cooke Insurance Group', 'https://cooke.ca/', 'With over 40 years of experience, we focus on delivering comprehensive products and services. In addition to insurance, our in-house claims experts are on hand should one of your claims need independent advice.', 'en'),
(7, 7, 'Cindy Lidster, RN, BScN, BA, FCNEd, CCC', 'https://www.acahs.ca/', 'Atlantic College of Applied Health Sciences The Atlantic College of Applied Health Sciences (ACAHS) recognizes the need for and value of post-secondary education and training. ACAHS is committed to providing a quality education that is focused on providing the learner and employer with a program that meets their short and long term goals. The ACAHS’s primary vision is to provide graduates who are educated, skilled and accountable to delivering quality healthcare support.', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `statistics`
--

CREATE TABLE `statistics` (
  `id` int(11) NOT NULL,
  `icon_class` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statistics`
--

INSERT INTO `statistics` (`id`, `icon_class`, `icon`, `number`, `sort_order`, `status`) VALUES
(1, 'fa fa-home mt-5 text-white', '', '369', 0, 1),
(2, 'fa fa-home mt-5 text-white', '', '35', 0, 1),
(3, 'fa fa-smile-o mt-5 text-white', '', '5000', 0, 1),
(4, 'fa  fa-users mt-5 text-white', '', '6905', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `statistics_desc`
--

CREATE TABLE `statistics_desc` (
  `desc_id` int(11) NOT NULL,
  `statistics_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statistics_desc`
--

INSERT INTO `statistics_desc` (`desc_id`, `statistics_id`, `name`, `language`) VALUES
(1, 1, 'Level 2 Homes', 'en'),
(2, 2, 'Level 3B3G Homes', 'en'),
(3, 3, 'Employees', 'en'),
(4, 4, 'Clients', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `date`, `status`) VALUES
(1, '2022-03-22 05:00:00', 1),
(2, '2022-03-22 05:00:00', 1),
(3, '2022-03-22 05:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials_desc`
--

CREATE TABLE `testimonials_desc` (
  `desc_id` int(11) NOT NULL,
  `testimonials_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials_desc`
--

INSERT INTO `testimonials_desc` (`desc_id`, `testimonials_id`, `message`, `author`, `language`) VALUES
(1, 1, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>My sister has been living in the same Special Care Home in Saint John, NB for 20 years. This is her home and the residents are her family. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>She has been given excellent care over the years. Her health, medications and diet have been given wonderful attention and our family feels comfort in her care and knows she will be looked after properly. She has had many urgent episodes over the years and all the staff know her problems and what to look for, and when to call for emergency help. This has literally saved her life many times during the recent years of her failing health. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>We, her family, appreciate the loving care of the management and staff and would not hesitate to recommend anyone to this home </em></p>\r\n', 'Admin 1', 'en'),
(2, 2, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>I have a family member in Special Care Home. My first experience with special care homes was when a friend of mine was looking for a fitting special care home for his brother in law, about 5 years ago. I visited his brother in law often &amp; was quite impressed at the love, support &amp; care he received. So when my friend&#39;s time came that she was no longer able to live on her own, the first place I reached out to was the same establishment. I knew it would be a safe for her. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>I was already aware &amp; comfortable with the friendly staff &amp; the compassion &amp; patients they exhibited for the Residents in their care, even when the Resident was having a difficult day (or many difficult days). </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The owner &amp; staff are very approachable &amp; easily answer any &amp; all concerns I have in regards to me friend. It certainly puts my mind at ease to know she is in such a loving, caring environment, in which all Residents are considered Family. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>COVID has been trying to say the least this past year but my friend was in the best of hands. Owner &amp; staff have been very informative with each phase of this virus &amp; I was updated with emails &amp; phone calls. I am Grateful to have my Friend (chosen sister) in this forever home where she feels content &amp; safe. I have already told the staff to put &#39;my name&#39; on their list for when my time comes, I want to feel safe &amp; a part of a family also </em></p>\r\n', 'Admin 2', 'en'),
(3, 3, '<p class=\"font-15 pl-0 text-white\">\r\n	<em>My daughter has been living in a care home since she was 19 years old. She is now 29 years old. She has cerebral palsy and she is nonverbal. Her condition had progressed in the last few years, she is now on a purred diet due to a choking issue with swallowing and her movement disorder has increased ongoing problems. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The care she has received is amazing and as her mom I am very pleased with the care home she lives in. The owner and staff know my daughters needs very well and communicate with me on any issues that come up. I trust their experience and knowledge of my daughter as I would my own. She is lucky to live in such a great place as I know not all of the care homes are so great. The one my daughter lives in is her home and she feels like family there. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>The owner and staff are well trained and have done an amazing job in dealing with the covid situation. The home is clean and all precautions were taken to keep clients safe and as happy as possible. All regulations surrounding covid were sent out to family and we were updated on any changes in the new color zones. I commend the staff and owner for a job well done during such a difficult time of covid. </em></p>\r\n<p class=\"font-15 pl-0 text-white\">\r\n	<em>I myself work with people with disabilities every day but I cannot lift due to injuries so that is why my daughter cannot live with me. I feel she is well cared for and her health and wellbeing are always in the best interest of her care home. I work under the same covid rules myself and I know the care home my daughter is in follows them well. I have had a very good experience with the care home my daughter lives in. Placing your loved one under someone else&#39;s care is a difficult and scary decision but I am happy with the choice we made for our daughter and the main thing is she is happy too. </em></p>\r\n', 'Admin 3', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `widget_type` varchar(255) NOT NULL,
  `widget_template` varchar(255) DEFAULT NULL,
  `block_category` int(11) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `background` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `gallery` varchar(255) DEFAULT NULL,
  `widgets` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `name`, `widget_type`, `widget_template`, `block_category`, `class`, `background`, `image`, `video`, `gallery`, `widgets`, `status`) VALUES
(1, 'Page Content', 'page_content_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(2, 'About Intro', 'about_intro_widget', NULL, 2, NULL, NULL, 'about-page-img-new.jpg', NULL, '', '0,0', 1),
(3, 'About Mission', 'about_mission_widget', NULL, 3, NULL, NULL, NULL, 'nbcsha-quality.mp4', '', '0,0', 1),
(4, 'Home About', 'home_about_widget', NULL, NULL, NULL, NULL, NULL, NULL, 'front_12.jpg,front_22.jpg,front_32.jpg', '0,0', 1),
(5, 'Home Blocks', 'home_blocks_widget', NULL, 1, NULL, NULL, NULL, NULL, '', '0,0', 1),
(6, 'Home How it Works', 'home_works_widget', NULL, NULL, NULL, NULL, NULL, 'nbcsha-quality.mp4', '', '0,0', 1),
(7, 'Board Members', 'board_members_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(8, 'FAQs', 'faqs_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(9, 'Latest News', 'latest_news_widget', NULL, NULL, NULL, NULL, NULL, NULL, '', '0,0', 1),
(10, 'News', 'news_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(11, 'Residences', 'residences_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(12, 'Sponsors', 'sponsors_list_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(13, 'Statistics', 'statistics_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(14, 'Testimonials', 'testimonials_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(15, 'Contact Widget', 'contact_widget', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `widgets_desc`
--

CREATE TABLE `widgets_desc` (
  `desc_id` int(11) NOT NULL,
  `widget_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `inset_title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `primary_link_url` varchar(255) NOT NULL,
  `primary_link_title` varchar(255) NOT NULL,
  `secondary_link_url` varchar(255) NOT NULL,
  `secondary_link_title` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `attachment_link_title` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `widgets_desc`
--

INSERT INTO `widgets_desc` (`desc_id`, `widget_id`, `title`, `subtitle`, `inset_title`, `content`, `primary_link_url`, `primary_link_title`, `secondary_link_url`, `secondary_link_title`, `attachment`, `attachment_link_title`, `language`) VALUES
(1, 1, '', '', '', '', '', '', '', '', '', '', 'en'),
(2, 2, '', '', '', '<h2 class=\"text-uppercase mt-0\">\r\n	Welcome to New Brunswick Special<span class=\"text-theme-color-2\"> Care Home </span> Association Inc</h2>\r\n<p class=\"lead pt-10\">\r\n	Providing quality, cost effective services for seniors and adults with disabilities in cooperation with the Department of Social Development. We strive to promote and develop awareness throughout New Brunswick of the great service our special care homes provide. We are operators too, and therefore understand the immense dedication and commitment involved in running a home. We are here to offer ideas to help you provide the best possible environment for your residents and staff, while help you succeed with your business.</p>\r\n', '', '', '', '', '', '', 'en'),
(3, 3, 'Why Choose Us?', '', '', '', '', '', '', '', '', '', 'en'),
(4, 4, '', '', '', '<h2 class=\"text-uppercase mt-0\">\r\n	Welcome to the New Brunswick Special <span class=\"text-theme-color-2\">Care Home</span>&nbsp;Association Inc.</h2>\r\n<p class=\"lead\">\r\n	We promote and develop awareness throughout New Brunswick of the great service our special care homes provide</p>\r\n<p>\r\n	The New Brunswick Special Care Home Association is here to assist licensed members in providing quality, cost-effective services for seniors and adults with special needs who require 24-hour care and supervision, in cooperation with the Department of Social Development. We advocate for this vital sector on a regular basis to bring key issues to the forefront. Our Board of Directors is committed to improving our association services and partnerships with key stakeholders and other partners in Long Term Care. Our website also provides an opportunity for the public, discharge planners, social workers and others to access details about our members&rsquo; homes and their unique services.</p>\r\n', '', '', '', '', '', '', 'en'),
(5, 5, '', '', '', '', '', '', '', '', '', '', 'en'),
(6, 6, '', '', '', '<h3 class=\"text-white text-uppercase font-30 font-weight-600 mt-0 mb-20\">\r\n	How NBSCHA works for you?</h3>\r\n<p class=\"text-white lead p-5 pl-0 text-left\">\r\n	The association does for its members what they cannot easily do for themselves. The Group Benefit program has been helpful to many and has potential to improve and expand. Working with government on wage, per diem, and issues of standards is a very important role that no individual home can do.</p>\r\n<p class=\"text-white lead text-left\">\r\n	The re-branding as illustrated in these videos is yet another major element of service. The new corporate structure of the association represents a commitment to strengthen its organization in its drive to become increasingly strong as a support to individual homes. Enhanced and expanded education, group purchasing, collaboration with government and other associations is yet another role. The association becomes stronger as more service providers get involved.</p>\r\n', '', '', '', '', '', '', 'en'),
(7, 7, '', '', '', '', '', '', '', '', '', '', 'en'),
(8, 8, '', '', '', '', '', '', '', '', '', '', 'en'),
(9, 9, '', '', '', '', '', '', '', '', '', '', 'en'),
(10, 10, '', '', '', '', '', '', '', '', '', '', 'en'),
(11, 11, '', '', '', '', '', '', '', '', '', '', 'en'),
(12, 12, '', '', '', '', '', '', '', '', '', '', 'en'),
(13, 13, '', '', '', '', '', '', '', '', '', '', 'en'),
(14, 14, '', '', '', '', '', '', '', '', '', '', 'en'),
(15, 1, '', '', '', '', '', '', '', '', '', '', 'fr'),
(16, 2, '', '', '', '', '', '', '', '', '', '', 'fr'),
(17, 3, '', '', '', '', '', '', '', '', '', '', 'fr'),
(18, 4, '', '', '', '', '', '', '', '', '', '', 'fr'),
(19, 5, '', '', '', '', '', '', '', '', '', '', 'fr'),
(20, 6, '', '', '', '', '', '', '', '', '', '', 'fr'),
(21, 7, '', '', '', '', '', '', '', '', '', '', 'fr'),
(22, 8, '', '', '', '', '', '', '', '', '', '', 'fr'),
(23, 9, 'Recent', 'News', '', '<p>\r\n	Please see below the latest news and articles our association regards as very important information to our staff and clients. We will be updating frequently. Keep checking back for more updates!</p>\r\n', '', '', '', '', '', '', 'fr'),
(24, 10, '', '', '', '', '', '', '', '', '', '', 'fr'),
(25, 11, '', '', '', '', '', '', '', '', '', '', 'fr'),
(26, 12, '', '', '', '', '', '', '', '', '', '', 'fr'),
(27, 13, '', '', '', '', '', '', '', '', '', '', 'fr'),
(28, 14, '', '', '', '', '', '', '', '', '', '', 'fr'),
(29, 15, '', '', '', '', '', '', '', '', '', '', 'en'),
(30, 15, '', '', '', '', '', '', '', '', '', '', 'fr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `admins_login_history`
--
ALTER TABLE `admins_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_function`
--
ALTER TABLE `admin_function`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_function_permission`
--
ALTER TABLE `admin_function_permission`
  ADD UNIQUE KEY `role_function_id` (`function_id`,`role_id`);

--
-- Indexes for table `admin_menu`
--
ALTER TABLE `admin_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_reset`
--
ALTER TABLE `admin_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blocks_desc`
--
ALTER TABLE `blocks_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `block_categories`
--
ALTER TABLE `block_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `board_members`
--
ALTER TABLE `board_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `board_members_desc`
--
ALTER TABLE `board_members_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `carelevels`
--
ALTER TABLE `carelevels`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `carelevels_desc`
--
ALTER TABLE `carelevels_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate_templates_desc`
--
ALTER TABLE `certificate_templates_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `database_updates`
--
ALTER TABLE `database_updates`
  ADD PRIMARY KEY (`update_id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `facilities_desc`
--
ALTER TABLE `facilities_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs_desc`
--
ALTER TABLE `faqs_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `features_desc`
--
ALTER TABLE `features_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms_desc`
--
ALTER TABLE `forms_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links_desc`
--
ALTER TABLE `links_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `localization`
--
ALTER TABLE `localization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membership_packages`
--
ALTER TABLE `membership_packages`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `membership_packages_desc`
--
ALTER TABLE `membership_packages_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members_login_history`
--
ALTER TABLE `members_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_menu`
--
ALTER TABLE `member_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_reset`
--
ALTER TABLE `member_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuitems`
--
ALTER TABLE `menuitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuitems_desc`
--
ALTER TABLE `menuitems_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_categories`
--
ALTER TABLE `news_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_categories_desc`
--
ALTER TABLE `news_categories_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `news_desc`
--
ALTER TABLE `news_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages_desc`
--
ALTER TABLE `pages_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_widgets`
--
ALTER TABLE `page_widgets`
  ADD UNIQUE KEY `page_widget_id` (`page_id`,`widget_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `regions_desc`
--
ALTER TABLE `regions_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `residences`
--
ALTER TABLE `residences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residences_desc`
--
ALTER TABLE `residences_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings_desc`
--
ALTER TABLE `settings_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders_desc`
--
ALTER TABLE `sliders_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `sponsors`
--
ALTER TABLE `sponsors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsors_desc`
--
ALTER TABLE `sponsors_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `statistics`
--
ALTER TABLE `statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statistics_desc`
--
ALTER TABLE `statistics_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials_desc`
--
ALTER TABLE `testimonials_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widgets_desc`
--
ALTER TABLE `widgets_desc`
  ADD PRIMARY KEY (`desc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admins_login_history`
--
ALTER TABLE `admins_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `admin_function`
--
ALTER TABLE `admin_function`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_menu`
--
ALTER TABLE `admin_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `admin_reset`
--
ALTER TABLE `admin_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `blocks_desc`
--
ALTER TABLE `blocks_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `block_categories`
--
ALTER TABLE `block_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `board_members`
--
ALTER TABLE `board_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `board_members_desc`
--
ALTER TABLE `board_members_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `carelevels`
--
ALTER TABLE `carelevels`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `carelevels_desc`
--
ALTER TABLE `carelevels_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `certificate_templates_desc`
--
ALTER TABLE `certificate_templates_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `database_updates`
--
ALTER TABLE `database_updates`
  MODIFY `update_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `facilities_desc`
--
ALTER TABLE `facilities_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faqs_desc`
--
ALTER TABLE `faqs_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `features_desc`
--
ALTER TABLE `features_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `forms_desc`
--
ALTER TABLE `forms_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `links_desc`
--
ALTER TABLE `links_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `localization`
--
ALTER TABLE `localization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `membership_packages`
--
ALTER TABLE `membership_packages`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `membership_packages_desc`
--
ALTER TABLE `membership_packages_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `membership_requests`
--
ALTER TABLE `membership_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `members_login_history`
--
ALTER TABLE `members_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `member_menu`
--
ALTER TABLE `member_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `member_reset`
--
ALTER TABLE `member_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menuitems`
--
ALTER TABLE `menuitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `menuitems_desc`
--
ALTER TABLE `menuitems_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news_categories`
--
ALTER TABLE `news_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news_categories_desc`
--
ALTER TABLE `news_categories_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news_desc`
--
ALTER TABLE `news_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `pages_desc`
--
ALTER TABLE `pages_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `regions_desc`
--
ALTER TABLE `regions_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `residences`
--
ALTER TABLE `residences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `residences_desc`
--
ALTER TABLE `residences_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `settings_desc`
--
ALTER TABLE `settings_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sliders_desc`
--
ALTER TABLE `sliders_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sponsors`
--
ALTER TABLE `sponsors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sponsors_desc`
--
ALTER TABLE `sponsors_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `statistics`
--
ALTER TABLE `statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `statistics_desc`
--
ALTER TABLE `statistics_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `testimonials_desc`
--
ALTER TABLE `testimonials_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `widgets_desc`
--
ALTER TABLE `widgets_desc`
  MODIFY `desc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
